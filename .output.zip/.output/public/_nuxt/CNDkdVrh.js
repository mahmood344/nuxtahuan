import"./B-dnRHyi.js";const s=globalThis.setInterval;export{s};
