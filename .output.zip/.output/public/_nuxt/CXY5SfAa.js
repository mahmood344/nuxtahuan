import"./B9wA6S15.js";const s=globalThis.setInterval;export{s};
