import"./xcej-vWP.js";const s=globalThis.setInterval;export{s};
