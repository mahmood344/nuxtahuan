import"./Dh0uC7Ht.js";const s=globalThis.setInterval;export{s};
