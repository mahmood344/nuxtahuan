import"./DWsW1mAt.js";const s=globalThis.setInterval;export{s};
