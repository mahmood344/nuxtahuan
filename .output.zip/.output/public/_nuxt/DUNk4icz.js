import"./D0NaZY3m.js";const s=globalThis.setInterval;export{s};
