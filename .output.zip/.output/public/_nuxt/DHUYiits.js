import"./Dm8xfVyO.js";const s=globalThis.setInterval;export{s};
