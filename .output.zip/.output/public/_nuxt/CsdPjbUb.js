import{_ as Z,E as u,C as D,o as s,c as i,a as m,n as g,i as R,e as k,x as B,j as ee,D as te,V as le,F as ae,r as re,T as oe,f as v,G as P}from"./D0NaZY3m.js";const ne=["dir"],ue={class:"relative flex items-center w-full"},se=["innerHTML"],ie=["value","placeholder","disabled","dir","aria-expanded","aria-activedescendant"],ce=["title"],ve=["innerHTML"],de={key:0,class:"flex items-center justify-center py-4"},fe={key:1,role:"listbox"},pe=["id","data-option-index","aria-selected","onMouseenter","onMousedown"],ge={key:2,class:"px-4 py-3 text-sm text-[var(--color-gray-500)]"},ye={key:0,class:"mt-1 text-sm text-[var(--color-red-500)]"},he={__name:"BaseAutocomplete",props:{modelValue:{type:[String,Number,Object,null],default:null},items:{type:Array,required:!0,default:()=>[]},itemText:{type:String,default:"label"},itemValue:{type:String,default:"value"},label:{type:String,default:""},placeholder:{type:String,default:""},icon:{type:String,default:""},iconPosition:{type:String,default:"left"},loading:{type:Boolean,default:!1},error:{type:String,default:""},disabled:{type:Boolean,default:!1},clearable:{type:Boolean,default:!0},menuProps:{type:Object,default:()=>({})},rtl:{type:Boolean,default:!0}},emits:["update:modelValue","update:items","update:loading","update:error","input","change","blur","focus"],setup(r,{emit:$}){const a=r,d=$,n=u(a.modelValue),c=u(""),o=u(!1),y=u(!1),w=u(a.items),f=u(null),A=u(null),T=u(null),E=u(null),p=u(!1),l=u(-1),N=v(()=>["relative",a.rtl?"dir-rtl":"dir-ltr"]),I=e=>String(typeof e=="object"&&e!==null?e?.[a.itemText]??"":e??""),x=e=>typeof e=="object"&&e!==null?e?.[a.itemValue]:e,L=v(()=>f.value!==null?I(f.value):typeof n.value=="string"||typeof n.value=="number"?String(n.value):""),O=v(()=>(y.value||o.value)&&p.value?c.value:L.value),C=v(()=>{if(!p.value||!c.value.trim())return w.value;const e=c.value.toLowerCase();return w.value.filter(t=>I(t).toLowerCase().includes(e))}),_=v(()=>f.value!==null||String(L.value).trim()!==""),M=v(()=>a.clearable&&_.value&&!a.loading),j=v(()=>a.loading?`
      <svg
        class="animate-spin h-5 w-5 text-[var(--color-primary)]"
        xmlns="http://www.w3.org/2000/svg"
        fill="none"
        viewBox="0 0 24 24"
      >
        <circle
          class="opacity-25"
          cx="12"
          cy="12"
          r="10"
          stroke="currentColor"
          stroke-width="2"
        ></circle>
        <path
          class="opacity-75"
          fill="currentColor"
          d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"
        ></path>
      </svg>
    `:M.value?`
      <svg
        xmlns="http://www.w3.org/2000/svg"
        viewBox="0 0 24 24"
        fill="none"
        class="w-5 h-5"
      >
        <path
          d="M6 6L18 18M18 6L6 18"
          stroke="currentColor"
          stroke-width="2"
          stroke-linecap="round"
          stroke-linejoin="round"
        />
      </svg>
    `:`
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 20 20"
      fill="currentColor"
      class="w-5 h-5 transition-transform duration-200 ${o.value?"rotate-180":""}"
    >
      <path
        fill-rule="evenodd"
        d="M5.23 7.21a.75.75 0 011.06.02L10 10.93l3.71-3.7a.75.75 0 111.06 1.06l-4.24 4.24a.75.75 0 01-1.06 0L5.21 8.29a.75.75 0 01.02-1.08z"
        clip-rule="evenodd"
      />
    </svg>
  `),q=v(()=>{const e=["peer w-full h-[54px] py-3 px-4 rounded-[12px] bg-white transition-all duration-300 outline-none border text-[var(--color-gray-700)] placeholder:text-[var(--color-gray-400)]",a.error?"border-[var(--color-red-500)] focus:ring-1 focus:ring-[var(--color-red-300)]":"border-[var(--color-gray-300)] focus:ring-1 focus:ring-[var(--color-primary)] focus:border-[var(--color-primary-dark)] focus:shadow-md"];return a.disabled&&e.push("bg-[var(--color-gray-100)] text-[var(--color-gray-500)] cursor-not-allowed"),a.icon&&e.push(a.iconPosition==="left"?"pl-10":"pr-10"),j.value&&e.push(a.rtl?"pl-10":"pr-10"),e}),h=()=>{o.value=!1,l.value=-1,p.value=!1,c.value=""},V=async()=>{a.disabled||(o.value=!0,y.value=!0,p.value=!1,c.value="",l.value=-1,await P(),A.value?.focus())},z=e=>{f.value=e,n.value=x(e),h(),d("update:modelValue",n.value),d("change",n.value)},K=()=>{f.value=null,n.value=null,h(),d("update:modelValue",null),d("change",null)},U=async()=>{a.disabled||(o.value?h():await V())},G=()=>{y.value=!0,d("focus")},Y=e=>{const t=e?.relatedTarget;t&&E.value?.contains(t)||(h(),y.value=!1,d("blur"))},J=e=>{c.value=e.target.value,p.value=!0,o.value=!0,l.value=-1,d("input",c.value)},F=async()=>{if(await P(),l.value<0||!T.value)return;T.value.querySelector(`[data-option-index="${l.value}"]`)?.scrollIntoView({block:"nearest"})},Q=async e=>{if(a.disabled||a.loading)return;const t=C.value;switch(e.key){case"ArrowDown":{if(e.preventDefault(),o.value||await V(),!t.length)return;l.value=l.value<0?0:(l.value+1)%t.length,await F();break}case"ArrowUp":{if(e.preventDefault(),o.value||await V(),!t.length)return;l.value=l.value<0?t.length-1:(l.value-1+t.length)%t.length,await F();break}case"Enter":{if(!o.value)return;e.preventDefault(),l.value>=0&&l.value<t.length?z(t[l.value]):t.length===1&&z(t[0]);break}case"Escape":{if(!o.value)return;e.preventDefault(),h();break}case"Tab":{h();break}}},W=(e,t)=>{e.preventDefault(),z(t)},X=()=>{M.value?K():U()};return D(()=>a.modelValue,e=>{n.value=e,f.value=w.value.find(t=>x(t)===e)??null,y.value||(c.value="",p.value=!1)},{immediate:!0}),D(()=>a.items,e=>{w.value=e,f.value=w.value.find(t=>x(t)===n.value)??null,l.value=-1,y.value||(c.value="",p.value=!1)},{immediate:!0}),D(C,()=>{l.value=-1}),(e,t)=>(s(),i("div",{ref_key:"wrapperRef",ref:E,class:g(N.value),dir:r.rtl?"rtl":"ltr"},[m("div",ue,[r.label?(s(),i("label",{key:0,class:g(["absolute -top-3 z-20 bg-white px-2 text-[11px]",[r.rtl?"right-4":"left-4",r.error?"text-[var(--color-red-500)]":"text-[var(--color-gray-400)]"]])},R(r.label),3)):k("",!0),r.icon?(s(),i("span",{key:1,class:g(["pointer-events-none absolute top-1/2 z-10 -translate-y-1/2 text-[var(--color-gray-400)]",r.iconPosition==="left"?"left-3":"right-3"]),innerHTML:r.icon},null,10,se)):k("",!0),m("input",{ref_key:"inputRef",ref:A,value:O.value,placeholder:r.placeholder,disabled:r.disabled,class:g(q.value),dir:r.rtl?"rtl":"ltr",role:"combobox","aria-autocomplete":"list","aria-haspopup":"listbox","aria-expanded":o.value,"aria-activedescendant":o.value&&l.value>=0?`autocomplete-option-${l.value}`:void 0,autocomplete:"off",onClick:B(V,["stop"]),onFocus:G,onBlur:Y,onInput:J,onKeydown:Q},null,42,ie),j.value?(s(),i("button",{key:2,type:"button",class:g(["absolute inset-y-0 z-10 flex items-center justify-center px-3 transition-colors",[r.rtl?"left-2":"right-2",M.value?"text-[var(--color-gray-400)] hover:text-[var(--color-red-500)]":"text-[var(--color-gray-400)] hover:text-[var(--color-primary)]"]]),title:M.value?"پاک کردن":"باز کردن لیست",onClick:B(X,["stop"])},[m("span",{class:"flex items-center justify-center",innerHTML:j.value},null,8,ve)],10,ce)):k("",!0)]),ee(oe,{name:"autocomplete-menu"},{default:te(()=>[o.value?(s(),i("div",{key:0,ref_key:"menuRef",ref:T,class:g(["absolute z-[100] mt-2 w-full rounded-lg border border-[var(--color-gray-200)] bg-white py-2 shadow-lg",r.rtl?"right-0":"left-0"]),style:le({maxHeight:"220px",overflowY:"auto",...r.menuProps}),onMousedown:t[0]||(t[0]=B(()=>{},["prevent"]))},[r.loading?(s(),i("div",de,[...t[1]||(t[1]=[m("svg",{class:"h-6 w-6 animate-spin text-[var(--color-primary)]",xmlns:"http://www.w3.org/2000/svg",fill:"none",viewBox:"0 0 24 24"},[m("circle",{class:"opacity-25",cx:"12",cy:"12",r:"10",stroke:"currentColor","stroke-width":"2"}),m("path",{class:"opacity-75",fill:"currentColor",d:"M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"})],-1)])])):C.value.length>0?(s(),i("ul",fe,[(s(!0),i(ae,null,re(C.value,(S,b)=>(s(),i("li",{id:`autocomplete-option-${b}`,key:b,"data-option-index":b,role:"option","aria-selected":x(S)===n.value,class:g(["cursor-pointer border-b border-[var(--color-gray-100)] py-3 pe-2 ps-4 text-sm transition-colors last:border-b-0",[b===l.value||x(S)===n.value?"bg-[var(--color-primary-light)] text-[var(--color-primary)]":"text-[var(--color-gray-700)] hover:bg-[var(--color-primary-light)]"]]),onMouseenter:H=>l.value=b,onMousedown:B(H=>W(H,S),["stop"])},R(I(S)),43,pe))),128))])):(s(),i("div",ge," موردی یافت نشد. "))],38)):k("",!0)]),_:1}),r.error?(s(),i("p",ye,R(r.error),1)):k("",!0)],10,ne))}},we=Z(he,[["__scopeId","data-v-a94f4807"]]);export{we as _};
