import"./Dz-GNLbr.js";const s=globalThis.setInterval;export{s};
