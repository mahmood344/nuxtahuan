import"./BOW7rMzB.js";const s=globalThis.setInterval;export{s};
