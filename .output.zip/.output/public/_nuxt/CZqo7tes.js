import"./iX7HlyE7.js";const s=globalThis.setInterval;export{s};
