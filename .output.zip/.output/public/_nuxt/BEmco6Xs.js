import"./DW7rT75S.js";const s=globalThis.setInterval;export{s};
