import{_ as q,E as c,C as z,o as a,c as o,a as y,n as g,i as M,e as h,x as w,j as G,D as U,V as Y,F as J,r as K,T as Q,f as d,G as W}from"./Dm8xfVyO.js";const X=["dir"],Z={class:"relative flex items-center w-full"},ee=["innerHTML"],te=["value","placeholder","disabled","dir"],le=["title"],re=["innerHTML"],ae={key:0,class:"flex items-center justify-center py-4"},oe={key:1},se=["onClick"],ne={key:2,class:"px-4 py-3 text-sm text-[var(--color-gray-500)]"},ue={key:0,class:"mt-1 text-sm text-[var(--color-red-500)]"},ie={__name:"BaseAutocomplete",props:{modelValue:{type:[String,Number,Object,null],default:null},items:{type:Array,required:!0,default:()=>[]},itemText:{type:String,default:"label"},itemValue:{type:String,default:"value"},label:{type:String,default:""},placeholder:{type:String,default:""},icon:{type:String,default:""},iconPosition:{type:String,default:"left"},loading:{type:Boolean,default:!1},error:{type:String,default:""},disabled:{type:Boolean,default:!1},clearable:{type:Boolean,default:!0},menuProps:{type:Object,default:()=>({})},rtl:{type:Boolean,default:!0}},emits:["update:modelValue","update:items","update:loading","update:error","input","change","blur","focus"],setup(t,{emit:F}){const l=t,f=F,s=c(l.modelValue),r=c(""),n=c(!1),v=c(!1),m=c(l.items),p=c(null),B=c(null),T=c(null),i=c(!1),H=d(()=>["relative",l.rtl?"dir-rtl":"dir-ltr"]),k=e=>String(typeof e=="object"&&e!==null?e?.[l.itemText]??"":e??""),x=e=>typeof e=="object"&&e!==null?e?.[l.itemValue]:e,C=d(()=>p.value?k(p.value):typeof s.value=="string"||typeof s.value=="number"?String(s.value):""),O=d(()=>(v.value||n.value)&&i.value?r.value:C.value),I=d(()=>{if(!i.value||!r.value.trim())return m.value;const e=r.value.toLowerCase();return m.value.filter(u=>k(u).toLowerCase().includes(e))}),P=d(()=>p.value!==null||String(C.value).trim()!==""),b=d(()=>l.clearable&&P.value&&!l.loading),V=d(()=>l.loading?`
      <svg
        class="animate-spin h-5 w-5 text-[var(--color-primary)]"
        xmlns="http://www.w3.org/2000/svg"
        fill="none"
        viewBox="0 0 24 24"
      >
        <circle
          class="opacity-25"
          cx="12"
          cy="12"
          r="10"
          stroke="currentColor"
          stroke-width="2"
        ></circle>
        <path
          class="opacity-75"
          fill="currentColor"
          d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"
        ></path>
      </svg>
    `:b.value?`
      <svg
        xmlns="http://www.w3.org/2000/svg"
        viewBox="0 0 24 24"
        fill="none"
        class="w-5 h-5"
      >
        <path
          d="M6 6L18 18M18 6L6 18"
          stroke="currentColor"
          stroke-width="2"
          stroke-linecap="round"
          stroke-linejoin="round"
        />
      </svg>
    `:`
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 20 20"
      fill="currentColor"
      class="w-5 h-5 transition-transform duration-200 ${n.value?"rotate-180":""}"
    >
      <path
        fill-rule="evenodd"
        d="M5.23 7.21a.75.75 0 011.06.02L10 10.93l3.71-3.7a.75.75 0 111.06 1.06l-4.24 4.24a.75.75 0 01-1.06 0L5.21 8.29a.75.75 0 01.02-1.08z"
        clip-rule="evenodd"
      />
    </svg>
  `),N=d(()=>{const e=["peer w-full h-[54px] py-3 px-4 rounded-[12px] bg-white transition-all duration-300 outline-none border text-[var(--color-gray-700)] placeholder:text-[var(--color-gray-400)]",l.error?"border-[var(--color-red-500)] focus:ring-1 focus:ring-[var(--color-red-300)]":"border-[var(--color-gray-300)] focus:ring-1 focus:ring-[var(--color-primary)] focus:border-[var(--color-primary-dark)] focus:shadow-md"];return l.disabled&&e.push("bg-[var(--color-gray-100)] text-[var(--color-gray-500)] cursor-not-allowed"),l.icon&&e.push(l.iconPosition==="left"?"pl-10":"pr-10"),V.value&&e.push(l.rtl?"pl-10":"pr-10"),e}),R=e=>{p.value=e,s.value=x(e),r.value="",i.value=!1,n.value=!1,v.value=!1,f("update:modelValue",s.value),f("change",s.value)},_=()=>{p.value=null,s.value=null,r.value="",i.value=!1,n.value=!1,v.value=!1,f("update:modelValue",null),f("change",null)},L=async()=>{l.disabled||(n.value=!n.value,n.value?(v.value=!0,i.value=!1,r.value="",await W(),B.value?.focus()):j())},A=()=>{v.value=!0,f("focus")},j=()=>{setTimeout(()=>{T.value?.matches(":hover")||(n.value=!1,v.value=!1,i.value=!1,r.value="",f("blur"))},150)},D=e=>{r.value=e.target.value,i.value=!0,n.value=!0,f("input",r.value)},E=()=>{b.value?_():L()};return z(()=>l.modelValue,e=>{s.value=e,p.value=m.value.find(u=>x(u)===e)||null,v.value||(r.value="",i.value=!1)},{immediate:!0}),z(()=>l.items,e=>{m.value=e,p.value=m.value.find(u=>x(u)===s.value)||null,v.value||(r.value="",i.value=!1)},{immediate:!0}),(e,u)=>(a(),o("div",{class:g(H.value),dir:t.rtl?"rtl":"ltr",onClick:w(L,["stop"])},[y("div",Z,[t.label?(a(),o("label",{key:0,class:g(["absolute -top-3 z-20 bg-white px-2 text-[11px]",[t.rtl?"right-4":"left-4",t.error?"text-[var(--color-red-500)]":"text-[var(--color-gray-400)]"]])},M(t.label),3)):h("",!0),t.icon?(a(),o("span",{key:1,class:g(["pointer-events-none absolute top-1/2 z-10 -translate-y-1/2 text-[var(--color-gray-400)]",t.iconPosition==="left"?"left-3":"right-3"]),innerHTML:t.icon},null,10,ee)):h("",!0),y("input",{ref_key:"inputRef",ref:B,value:O.value,placeholder:t.placeholder,disabled:t.disabled,class:g(N.value),dir:t.rtl?"rtl":"ltr",onFocus:A,onBlur:j,onInput:D},null,42,te),V.value?(a(),o("button",{key:2,type:"button",class:g(["absolute inset-y-0 z-10 flex items-center justify-center px-3 transition-colors",[t.rtl?"left-2":"right-2",b.value?"text-[var(--color-gray-400)] hover:text-[var(--color-red-500)]":"text-[var(--color-gray-400)] hover:text-[var(--color-primary)]"]]),title:b.value?"پاک کردن":"باز کردن لیست",onClick:w(E,["stop"])},[y("span",{class:"flex items-center justify-center",innerHTML:V.value},null,8,re)],10,le)):h("",!0)]),G(Q,{name:"autocomplete-menu"},{default:U(()=>[n.value?(a(),o("div",{key:0,ref_key:"menuRef",ref:T,class:g(["absolute z-[100] mt-2 w-full rounded-lg border border-[var(--color-gray-200)] bg-white py-2 shadow-lg",t.rtl?"right-0":"left-0"]),style:Y({maxHeight:"220px",overflowY:"auto",...t.menuProps}),onClick:u[0]||(u[0]=w(()=>{},["stop"]))},[t.loading?(a(),o("div",ae,[...u[1]||(u[1]=[y("svg",{class:"h-6 w-6 animate-spin text-[var(--color-primary)]",xmlns:"http://www.w3.org/2000/svg",fill:"none",viewBox:"0 0 24 24"},[y("circle",{class:"opacity-25",cx:"12",cy:"12",r:"10",stroke:"currentColor","stroke-width":"2"}),y("path",{class:"opacity-75",fill:"currentColor",d:"M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"})],-1)])])):I.value.length>0?(a(),o("ul",oe,[(a(!0),o(J,null,K(I.value,(S,$)=>(a(),o("li",{key:$,class:g(["cursor-pointer border-b border-[var(--color-gray-100)] py-3 pe-2 ps-4 text-sm transition-colors last:border-b-0 hover:bg-[var(--color-primary-light)] hover:text-[var(--color-primary)]",x(S)===s.value?"bg-[var(--color-primary-light)] text-[var(--color-primary)]":"text-[var(--color-gray-700)]"]),onClick:w(ce=>R(S),["stop"])},M(k(S)),11,se))),128))])):(a(),o("div",ne," موردی یافت نشد. "))],6)):h("",!0)]),_:1}),t.error?(a(),o("p",ue,M(t.error),1)):h("",!0)],10,X))}},de=q(ie,[["__scopeId","data-v-5d6cd32b"]]);export{de as _};
