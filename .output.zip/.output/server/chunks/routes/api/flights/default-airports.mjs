import { c as defineEventHandler, u as useRuntimeConfig } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';

const defaultAirports = defineEventHandler(async (event) => {
  const { baseUrl } = useRuntimeConfig();
  console.log(baseUrl, "baseUrl");
  try {
    const response = await $fetch(`https://api.ahuan.ir/api/BasicInfo/default-airports`, {
      headers: {
        accept: "application/json"
      }
    });
    return response;
  } catch (error) {
    console.error("default airports error:", error);
    return {
      error: true,
      message: "fetch airports failed"
    };
  }
});

export { defaultAirports as default };
//# sourceMappingURL=default-airports.mjs.map
