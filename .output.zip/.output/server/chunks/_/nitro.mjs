import process from 'node:process';globalThis._importMeta_=globalThis._importMeta_||{url:"file:///_entry.js",env:process.env};import http from 'node:http';
import https from 'node:https';
import { EventEmitter } from 'node:events';
import { Buffer as Buffer$1 } from 'node:buffer';
import { promises, existsSync } from 'node:fs';
import { resolve as resolve$1, dirname as dirname$1, join } from 'node:path';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';

const suspectProtoRx = /"(?:_|\\u0{2}5[Ff]){2}(?:p|\\u0{2}70)(?:r|\\u0{2}72)(?:o|\\u0{2}6[Ff])(?:t|\\u0{2}74)(?:o|\\u0{2}6[Ff])(?:_|\\u0{2}5[Ff]){2}"\s*:/;
const suspectConstructorRx = /"(?:c|\\u0063)(?:o|\\u006[Ff])(?:n|\\u006[Ee])(?:s|\\u0073)(?:t|\\u0074)(?:r|\\u0072)(?:u|\\u0075)(?:c|\\u0063)(?:t|\\u0074)(?:o|\\u006[Ff])(?:r|\\u0072)"\s*:/;
const JsonSigRx = /^\s*["[{]|^\s*-?\d{1,16}(\.\d{1,17})?([Ee][+-]?\d+)?\s*$/;
function jsonParseTransform(key, value) {
  if (key === "__proto__" || key === "constructor" && value && typeof value === "object" && "prototype" in value) {
    warnKeyDropped(key);
    return;
  }
  return value;
}
function warnKeyDropped(key) {
  console.warn(`[destr] Dropping "${key}" key to prevent prototype pollution.`);
}
function destr(value, options = {}) {
  if (typeof value !== "string") {
    return value;
  }
  if (value[0] === '"' && value[value.length - 1] === '"' && value.indexOf("\\") === -1) {
    return value.slice(1, -1);
  }
  const _value = value.trim();
  if (_value.length <= 9) {
    switch (_value.toLowerCase()) {
      case "true": {
        return true;
      }
      case "false": {
        return false;
      }
      case "undefined": {
        return void 0;
      }
      case "null": {
        return null;
      }
      case "nan": {
        return Number.NaN;
      }
      case "infinity": {
        return Number.POSITIVE_INFINITY;
      }
      case "-infinity": {
        return Number.NEGATIVE_INFINITY;
      }
    }
  }
  if (!JsonSigRx.test(value)) {
    if (options.strict) {
      throw new SyntaxError("[destr] Invalid JSON");
    }
    return value;
  }
  try {
    if (suspectProtoRx.test(value) || suspectConstructorRx.test(value)) {
      if (options.strict) {
        throw new Error("[destr] Possible prototype pollution");
      }
      return JSON.parse(value, jsonParseTransform);
    }
    return JSON.parse(value);
  } catch (error) {
    if (options.strict) {
      throw error;
    }
    return value;
  }
}

const HASH_RE = /#/g;
const AMPERSAND_RE = /&/g;
const SLASH_RE = /\//g;
const EQUAL_RE = /=/g;
const IM_RE = /\?/g;
const PLUS_RE = /\+/g;
const ENC_CARET_RE = /%5e/gi;
const ENC_BACKTICK_RE = /%60/gi;
const ENC_PIPE_RE = /%7c/gi;
const ENC_SPACE_RE = /%20/gi;
const ENC_SLASH_RE = /%2f/gi;
const ENC_ENC_SLASH_RE = /%252f/gi;
function encode(text) {
  return encodeURI("" + text).replace(ENC_PIPE_RE, "|");
}
function encodeQueryValue(input) {
  return encode(typeof input === "string" ? input : JSON.stringify(input)).replace(PLUS_RE, "%2B").replace(ENC_SPACE_RE, "+").replace(HASH_RE, "%23").replace(AMPERSAND_RE, "%26").replace(ENC_BACKTICK_RE, "`").replace(ENC_CARET_RE, "^").replace(SLASH_RE, "%2F");
}
function encodeQueryKey(text) {
  return encodeQueryValue(text).replace(EQUAL_RE, "%3D");
}
function encodePath(text) {
  return encode(text).replace(HASH_RE, "%23").replace(IM_RE, "%3F").replace(ENC_ENC_SLASH_RE, "%2F").replace(AMPERSAND_RE, "%26").replace(PLUS_RE, "%2B");
}
function decode$2(text = "") {
  try {
    return decodeURIComponent("" + text);
  } catch {
    return "" + text;
  }
}
function decodePath(text) {
  return decode$2(text.replace(ENC_SLASH_RE, "%252F"));
}
function decodeQueryKey(text) {
  return decode$2(text.replace(PLUS_RE, " "));
}
function decodeQueryValue(text) {
  return decode$2(text.replace(PLUS_RE, " "));
}

function parseQuery(parametersString = "") {
  const object = /* @__PURE__ */ Object.create(null);
  if (parametersString[0] === "?") {
    parametersString = parametersString.slice(1);
  }
  for (const parameter of parametersString.split("&")) {
    const s = parameter.match(/([^=]+)=?(.*)/) || [];
    if (s.length < 2) {
      continue;
    }
    const key = decodeQueryKey(s[1]);
    if (key === "__proto__" || key === "constructor") {
      continue;
    }
    const value = decodeQueryValue(s[2] || "");
    if (object[key] === void 0) {
      object[key] = value;
    } else if (Array.isArray(object[key])) {
      object[key].push(value);
    } else {
      object[key] = [object[key], value];
    }
  }
  return object;
}
function encodeQueryItem(key, value) {
  if (typeof value === "number" || typeof value === "boolean") {
    value = String(value);
  }
  if (!value) {
    return encodeQueryKey(key);
  }
  if (Array.isArray(value)) {
    return value.map(
      (_value) => `${encodeQueryKey(key)}=${encodeQueryValue(_value)}`
    ).join("&");
  }
  return `${encodeQueryKey(key)}=${encodeQueryValue(value)}`;
}
function stringifyQuery(query) {
  return Object.keys(query).filter((k) => query[k] !== void 0).map((k) => encodeQueryItem(k, query[k])).filter(Boolean).join("&");
}

const PROTOCOL_STRICT_REGEX = /^[\s\w\0+.-]{2,}:([/\\]{1,2})/;
const PROTOCOL_REGEX = /^[\s\w\0+.-]{2,}:([/\\]{2})?/;
const PROTOCOL_RELATIVE_REGEX = /^([/\\]\s*){2,}[^/\\]/;
const PROTOCOL_SCRIPT_RE = /^[\s\0]*(blob|data|javascript|vbscript):$/i;
const TRAILING_SLASH_RE = /\/$|\/\?|\/#/;
const JOIN_LEADING_SLASH_RE = /^\.?\//;
function hasProtocol(inputString, opts = {}) {
  if (typeof opts === "boolean") {
    opts = { acceptRelative: opts };
  }
  if (opts.strict) {
    return PROTOCOL_STRICT_REGEX.test(inputString);
  }
  return PROTOCOL_REGEX.test(inputString) || (opts.acceptRelative ? PROTOCOL_RELATIVE_REGEX.test(inputString) : false);
}
function isScriptProtocol(protocol) {
  return !!protocol && PROTOCOL_SCRIPT_RE.test(protocol);
}
function hasTrailingSlash(input = "", respectQueryAndFragment) {
  if (!respectQueryAndFragment) {
    return input.endsWith("/");
  }
  return TRAILING_SLASH_RE.test(input);
}
function withoutTrailingSlash(input = "", respectQueryAndFragment) {
  if (!respectQueryAndFragment) {
    return (hasTrailingSlash(input) ? input.slice(0, -1) : input) || "/";
  }
  if (!hasTrailingSlash(input, true)) {
    return input || "/";
  }
  let path = input;
  let fragment = "";
  const fragmentIndex = input.indexOf("#");
  if (fragmentIndex !== -1) {
    path = input.slice(0, fragmentIndex);
    fragment = input.slice(fragmentIndex);
  }
  const [s0, ...s] = path.split("?");
  const cleanPath = s0.endsWith("/") ? s0.slice(0, -1) : s0;
  return (cleanPath || "/") + (s.length > 0 ? `?${s.join("?")}` : "") + fragment;
}
function withTrailingSlash(input = "", respectQueryAndFragment) {
  if (!respectQueryAndFragment) {
    return input.endsWith("/") ? input : input + "/";
  }
  if (hasTrailingSlash(input, true)) {
    return input || "/";
  }
  let path = input;
  let fragment = "";
  const fragmentIndex = input.indexOf("#");
  if (fragmentIndex !== -1) {
    path = input.slice(0, fragmentIndex);
    fragment = input.slice(fragmentIndex);
    if (!path) {
      return fragment;
    }
  }
  const [s0, ...s] = path.split("?");
  return s0 + "/" + (s.length > 0 ? `?${s.join("?")}` : "") + fragment;
}
function hasLeadingSlash(input = "") {
  return input.startsWith("/");
}
function withLeadingSlash(input = "") {
  return hasLeadingSlash(input) ? input : "/" + input;
}
function withBase(input, base) {
  if (isEmptyURL(base) || hasProtocol(input)) {
    return input;
  }
  const _base = withoutTrailingSlash(base);
  if (input.startsWith(_base)) {
    const nextChar = input[_base.length];
    if (!nextChar || nextChar === "/" || nextChar === "?") {
      return input;
    }
  }
  return joinURL(_base, input);
}
function withoutBase(input, base) {
  if (isEmptyURL(base)) {
    return input;
  }
  const _base = withoutTrailingSlash(base);
  if (!input.startsWith(_base)) {
    return input;
  }
  const nextChar = input[_base.length];
  if (nextChar && nextChar !== "/" && nextChar !== "?") {
    return input;
  }
  const trimmed = input.slice(_base.length).replace(/^\/+/, "");
  return "/" + trimmed;
}
function withQuery(input, query) {
  const parsed = parseURL(input);
  const mergedQuery = { ...parseQuery(parsed.search), ...query };
  parsed.search = stringifyQuery(mergedQuery);
  return stringifyParsedURL(parsed);
}
function getQuery$1(input) {
  return parseQuery(parseURL(input).search);
}
function isEmptyURL(url) {
  return !url || url === "/";
}
function isNonEmptyURL(url) {
  return url && url !== "/";
}
function joinURL(base, ...input) {
  let url = base || "";
  for (const segment of input.filter((url2) => isNonEmptyURL(url2))) {
    if (url) {
      const _segment = segment.replace(JOIN_LEADING_SLASH_RE, "");
      url = withTrailingSlash(url) + _segment;
    } else {
      url = segment;
    }
  }
  return url;
}
function joinRelativeURL(..._input) {
  const JOIN_SEGMENT_SPLIT_RE = /\/(?!\/)/;
  const input = _input.filter(Boolean);
  const segments = [];
  let segmentsDepth = 0;
  for (const i of input) {
    if (!i || i === "/") {
      continue;
    }
    for (const [sindex, s] of i.split(JOIN_SEGMENT_SPLIT_RE).entries()) {
      if (!s || s === ".") {
        continue;
      }
      if (s === "..") {
        if (segments.length === 1 && hasProtocol(segments[0])) {
          continue;
        }
        segments.pop();
        segmentsDepth--;
        continue;
      }
      if (sindex === 1 && segments[segments.length - 1]?.endsWith(":/")) {
        segments[segments.length - 1] += "/" + s;
        continue;
      }
      segments.push(s);
      segmentsDepth++;
    }
  }
  let url = segments.join("/");
  if (segmentsDepth >= 0) {
    if (input[0]?.startsWith("/") && !url.startsWith("/")) {
      url = "/" + url;
    } else if (input[0]?.startsWith("./") && !url.startsWith("./")) {
      url = "./" + url;
    }
  } else {
    url = "../".repeat(-1 * segmentsDepth) + url;
  }
  if (input[input.length - 1]?.endsWith("/") && !url.endsWith("/")) {
    url += "/";
  }
  return url;
}

const protocolRelative = Symbol.for("ufo:protocolRelative");
function parseURL(input = "", defaultProto) {
  const _specialProtoMatch = input.match(
    /^[\s\0]*(blob:|data:|javascript:|vbscript:)(.*)/i
  );
  if (_specialProtoMatch) {
    const [, _proto, _pathname = ""] = _specialProtoMatch;
    return {
      protocol: _proto.toLowerCase(),
      pathname: _pathname,
      href: _proto + _pathname,
      auth: "",
      host: "",
      search: "",
      hash: ""
    };
  }
  if (!hasProtocol(input, { acceptRelative: true })) {
    return parsePath(input);
  }
  const [, protocol = "", auth, hostAndPath = ""] = input.replace(/\\/g, "/").match(/^[\s\0]*([\w+.-]{2,}:)?\/\/([^/@]+@)?(.*)/) || [];
  let [, host = "", path = ""] = hostAndPath.match(/([^#/?]*)(.*)?/) || [];
  if (protocol === "file:") {
    path = path.replace(/\/(?=[A-Za-z]:)/, "");
  }
  const { pathname, search, hash } = parsePath(path);
  return {
    protocol: protocol.toLowerCase(),
    auth: auth ? auth.slice(0, Math.max(0, auth.length - 1)) : "",
    host,
    pathname,
    search,
    hash,
    [protocolRelative]: !protocol
  };
}
function parsePath(input = "") {
  const [pathname = "", search = "", hash = ""] = (input.match(/([^#?]*)(\?[^#]*)?(#.*)?/) || []).splice(1);
  return {
    pathname,
    search,
    hash
  };
}
function stringifyParsedURL(parsed) {
  const pathname = parsed.pathname || "";
  const search = parsed.search ? (parsed.search.startsWith("?") ? "" : "?") + parsed.search : "";
  const hash = parsed.hash || "";
  const auth = parsed.auth ? parsed.auth + "@" : "";
  const host = parsed.host || "";
  const proto = parsed.protocol || parsed[protocolRelative] ? (parsed.protocol || "") + "//" : "";
  return proto + auth + host + pathname + search + hash;
}

const NullObject$1 = /* @__PURE__ */ (() => {
  const C = function() {
  };
  C.prototype = /* @__PURE__ */ Object.create(null);
  return C;
})();
function parse$1(str, options) {
  if (typeof str !== "string") {
    throw new TypeError("argument str must be a string");
  }
  const obj = new NullObject$1();
  const opt = {};
  const dec = opt.decode || decode$1;
  let index = 0;
  while (index < str.length) {
    const eqIdx = str.indexOf("=", index);
    if (eqIdx === -1) {
      break;
    }
    let endIdx = str.indexOf(";", index);
    if (endIdx === -1) {
      endIdx = str.length;
    } else if (endIdx < eqIdx) {
      index = str.lastIndexOf(";", eqIdx - 1) + 1;
      continue;
    }
    const key = str.slice(index, eqIdx).trim();
    if (opt?.filter && !opt?.filter(key)) {
      index = endIdx + 1;
      continue;
    }
    if (void 0 === obj[key]) {
      let val = str.slice(eqIdx + 1, endIdx).trim();
      if (val.codePointAt(0) === 34) {
        val = val.slice(1, -1);
      }
      obj[key] = tryDecode$1(val, dec);
    }
    index = endIdx + 1;
  }
  return obj;
}
function decode$1(str) {
  return str.includes("%") ? decodeURIComponent(str) : str;
}
function tryDecode$1(str, decode2) {
  try {
    return decode2(str);
  } catch {
    return str;
  }
}

const fieldContentRegExp = /^[\u0009\u0020-\u007E\u0080-\u00FF]+$/;
function serialize$2(name, value, options) {
  const opt = options || {};
  const enc = opt.encode || encodeURIComponent;
  if (typeof enc !== "function") {
    throw new TypeError("option encode is invalid");
  }
  if (!fieldContentRegExp.test(name)) {
    throw new TypeError("argument name is invalid");
  }
  const encodedValue = enc(value);
  if (encodedValue && !fieldContentRegExp.test(encodedValue)) {
    throw new TypeError("argument val is invalid");
  }
  let str = name + "=" + encodedValue;
  if (void 0 !== opt.maxAge && opt.maxAge !== null) {
    const maxAge = opt.maxAge - 0;
    if (Number.isNaN(maxAge) || !Number.isFinite(maxAge)) {
      throw new TypeError("option maxAge is invalid");
    }
    str += "; Max-Age=" + Math.floor(maxAge);
  }
  if (opt.domain) {
    if (!fieldContentRegExp.test(opt.domain)) {
      throw new TypeError("option domain is invalid");
    }
    str += "; Domain=" + opt.domain;
  }
  if (opt.path) {
    if (!fieldContentRegExp.test(opt.path)) {
      throw new TypeError("option path is invalid");
    }
    str += "; Path=" + opt.path;
  }
  if (opt.expires) {
    if (!isDate(opt.expires) || Number.isNaN(opt.expires.valueOf())) {
      throw new TypeError("option expires is invalid");
    }
    str += "; Expires=" + opt.expires.toUTCString();
  }
  if (opt.httpOnly) {
    str += "; HttpOnly";
  }
  if (opt.secure) {
    str += "; Secure";
  }
  if (opt.priority) {
    const priority = typeof opt.priority === "string" ? opt.priority.toLowerCase() : opt.priority;
    switch (priority) {
      case "low": {
        str += "; Priority=Low";
        break;
      }
      case "medium": {
        str += "; Priority=Medium";
        break;
      }
      case "high": {
        str += "; Priority=High";
        break;
      }
      default: {
        throw new TypeError("option priority is invalid");
      }
    }
  }
  if (opt.sameSite) {
    const sameSite = typeof opt.sameSite === "string" ? opt.sameSite.toLowerCase() : opt.sameSite;
    switch (sameSite) {
      case true: {
        str += "; SameSite=Strict";
        break;
      }
      case "lax": {
        str += "; SameSite=Lax";
        break;
      }
      case "strict": {
        str += "; SameSite=Strict";
        break;
      }
      case "none": {
        str += "; SameSite=None";
        break;
      }
      default: {
        throw new TypeError("option sameSite is invalid");
      }
    }
  }
  if (opt.partitioned) {
    str += "; Partitioned";
  }
  return str;
}
function isDate(val) {
  return Object.prototype.toString.call(val) === "[object Date]" || val instanceof Date;
}

function parseSetCookie(setCookieValue, options) {
  const parts = (setCookieValue || "").split(";").filter((str) => typeof str === "string" && !!str.trim());
  const nameValuePairStr = parts.shift() || "";
  const parsed = _parseNameValuePair(nameValuePairStr);
  const name = parsed.name;
  let value = parsed.value;
  try {
    value = options?.decode === false ? value : (options?.decode || decodeURIComponent)(value);
  } catch {
  }
  const cookie = {
    name,
    value
  };
  for (const part of parts) {
    const sides = part.split("=");
    const partKey = (sides.shift() || "").trimStart().toLowerCase();
    const partValue = sides.join("=");
    switch (partKey) {
      case "expires": {
        cookie.expires = new Date(partValue);
        break;
      }
      case "max-age": {
        cookie.maxAge = Number.parseInt(partValue, 10);
        break;
      }
      case "secure": {
        cookie.secure = true;
        break;
      }
      case "httponly": {
        cookie.httpOnly = true;
        break;
      }
      case "samesite": {
        cookie.sameSite = partValue;
        break;
      }
      default: {
        cookie[partKey] = partValue;
      }
    }
  }
  return cookie;
}
function _parseNameValuePair(nameValuePairStr) {
  let name = "";
  let value = "";
  const nameValueArr = nameValuePairStr.split("=");
  if (nameValueArr.length > 1) {
    name = nameValueArr.shift();
    value = nameValueArr.join("=");
  } else {
    value = nameValuePairStr;
  }
  return { name, value };
}

const NODE_TYPES = {
  NORMAL: 0,
  WILDCARD: 1,
  PLACEHOLDER: 2
};

function createRouter$1(options = {}) {
  const ctx = {
    options,
    rootNode: createRadixNode(),
    staticRoutesMap: {}
  };
  const normalizeTrailingSlash = (p) => options.strictTrailingSlash ? p : p.replace(/\/$/, "") || "/";
  if (options.routes) {
    for (const path in options.routes) {
      insert(ctx, normalizeTrailingSlash(path), options.routes[path]);
    }
  }
  return {
    ctx,
    lookup: (path) => lookup(ctx, normalizeTrailingSlash(path)),
    insert: (path, data) => insert(ctx, normalizeTrailingSlash(path), data),
    remove: (path) => remove(ctx, normalizeTrailingSlash(path))
  };
}
function lookup(ctx, path) {
  const staticPathNode = ctx.staticRoutesMap[path];
  if (staticPathNode) {
    return staticPathNode.data;
  }
  const sections = path.split("/");
  const params = {};
  let paramsFound = false;
  let wildcardNode = null;
  let node = ctx.rootNode;
  let wildCardParam = null;
  for (let i = 0; i < sections.length; i++) {
    const section = sections[i];
    if (node.wildcardChildNode !== null) {
      wildcardNode = node.wildcardChildNode;
      wildCardParam = sections.slice(i).join("/");
    }
    const nextNode = node.children.get(section);
    if (nextNode === void 0) {
      if (node && node.placeholderChildren.length > 1) {
        const remaining = sections.length - i;
        node = node.placeholderChildren.find((c) => c.maxDepth === remaining) || null;
      } else {
        node = node.placeholderChildren[0] || null;
      }
      if (!node) {
        break;
      }
      if (node.paramName) {
        params[node.paramName] = section;
      }
      paramsFound = true;
    } else {
      node = nextNode;
    }
  }
  if ((node === null || node.data === null) && wildcardNode !== null) {
    node = wildcardNode;
    params[node.paramName || "_"] = wildCardParam;
    paramsFound = true;
  }
  if (!node) {
    return null;
  }
  if (paramsFound) {
    return {
      ...node.data,
      params: paramsFound ? params : void 0
    };
  }
  return node.data;
}
function insert(ctx, path, data) {
  let isStaticRoute = true;
  const sections = path.split("/");
  let node = ctx.rootNode;
  let _unnamedPlaceholderCtr = 0;
  const matchedNodes = [node];
  for (const section of sections) {
    let childNode;
    if (childNode = node.children.get(section)) {
      node = childNode;
    } else {
      const type = getNodeType(section);
      childNode = createRadixNode({ type, parent: node });
      node.children.set(section, childNode);
      if (type === NODE_TYPES.PLACEHOLDER) {
        childNode.paramName = section === "*" ? `_${_unnamedPlaceholderCtr++}` : section.slice(1);
        node.placeholderChildren.push(childNode);
        isStaticRoute = false;
      } else if (type === NODE_TYPES.WILDCARD) {
        node.wildcardChildNode = childNode;
        childNode.paramName = section.slice(
          3
          /* "**:" */
        ) || "_";
        isStaticRoute = false;
      }
      matchedNodes.push(childNode);
      node = childNode;
    }
  }
  for (const [depth, node2] of matchedNodes.entries()) {
    node2.maxDepth = Math.max(matchedNodes.length - depth, node2.maxDepth || 0);
  }
  node.data = data;
  if (isStaticRoute === true) {
    ctx.staticRoutesMap[path] = node;
  }
  return node;
}
function remove(ctx, path) {
  let success = false;
  const sections = path.split("/");
  let node = ctx.rootNode;
  for (const section of sections) {
    node = node.children.get(section);
    if (!node) {
      return success;
    }
  }
  if (node.data) {
    const lastSection = sections.at(-1) || "";
    node.data = null;
    if (Object.keys(node.children).length === 0 && node.parent) {
      node.parent.children.delete(lastSection);
      node.parent.wildcardChildNode = null;
      node.parent.placeholderChildren = [];
    }
    success = true;
  }
  return success;
}
function createRadixNode(options = {}) {
  return {
    type: options.type || NODE_TYPES.NORMAL,
    maxDepth: 0,
    parent: options.parent || null,
    children: /* @__PURE__ */ new Map(),
    data: options.data || null,
    paramName: options.paramName || null,
    wildcardChildNode: null,
    placeholderChildren: []
  };
}
function getNodeType(str) {
  if (str.startsWith("**")) {
    return NODE_TYPES.WILDCARD;
  }
  if (str[0] === ":" || str === "*") {
    return NODE_TYPES.PLACEHOLDER;
  }
  return NODE_TYPES.NORMAL;
}

function toRouteMatcher(router) {
  const table = _routerNodeToTable("", router.ctx.rootNode);
  return _createMatcher(table, router.ctx.options.strictTrailingSlash);
}
function _createMatcher(table, strictTrailingSlash) {
  return {
    ctx: { table },
    matchAll: (path) => _matchRoutes(path, table, strictTrailingSlash)
  };
}
function _createRouteTable() {
  return {
    static: /* @__PURE__ */ new Map(),
    wildcard: /* @__PURE__ */ new Map(),
    dynamic: /* @__PURE__ */ new Map()
  };
}
function _matchRoutes(path, table, strictTrailingSlash) {
  if (strictTrailingSlash !== true && path.endsWith("/")) {
    path = path.slice(0, -1) || "/";
  }
  const matches = [];
  for (const [key, value] of _sortRoutesMap(table.wildcard)) {
    if (path === key || path.startsWith(key + "/")) {
      matches.push(value);
    }
  }
  for (const [key, value] of _sortRoutesMap(table.dynamic)) {
    if (path.startsWith(key + "/")) {
      const subPath = "/" + path.slice(key.length).split("/").splice(2).join("/");
      matches.push(..._matchRoutes(subPath, value));
    }
  }
  const staticMatch = table.static.get(path);
  if (staticMatch) {
    matches.push(staticMatch);
  }
  return matches.filter(Boolean);
}
function _sortRoutesMap(m) {
  return [...m.entries()].sort((a, b) => a[0].length - b[0].length);
}
function _routerNodeToTable(initialPath, initialNode) {
  const table = _createRouteTable();
  function _addNode(path, node) {
    if (path) {
      if (node.type === NODE_TYPES.NORMAL && !(path.includes("*") || path.includes(":"))) {
        if (node.data) {
          table.static.set(path, node.data);
        }
      } else if (node.type === NODE_TYPES.WILDCARD) {
        table.wildcard.set(path.replace("/**", ""), node.data);
      } else if (node.type === NODE_TYPES.PLACEHOLDER) {
        const subTable = _routerNodeToTable("", node);
        if (node.data) {
          subTable.static.set("/", node.data);
        }
        table.dynamic.set(path.replace(/\/\*|\/:\w+/, ""), subTable);
        return;
      }
    }
    for (const [childPath, child] of node.children.entries()) {
      _addNode(`${path}/${childPath}`.replace("//", "/"), child);
    }
  }
  _addNode(initialPath, initialNode);
  return table;
}

function isPlainObject(value) {
  if (value === null || typeof value !== "object") {
    return false;
  }
  const prototype = Object.getPrototypeOf(value);
  if (prototype !== null && prototype !== Object.prototype && Object.getPrototypeOf(prototype) !== null) {
    return false;
  }
  if (Symbol.iterator in value) {
    return false;
  }
  if (Symbol.toStringTag in value) {
    return Object.prototype.toString.call(value) === "[object Module]";
  }
  return true;
}

function _defu(baseObject, defaults, namespace = ".", merger) {
  if (!isPlainObject(defaults)) {
    return _defu(baseObject, {}, namespace, merger);
  }
  const object = { ...defaults };
  for (const key of Object.keys(baseObject)) {
    if (key === "__proto__" || key === "constructor") {
      continue;
    }
    const value = baseObject[key];
    if (value === null || value === void 0) {
      continue;
    }
    if (merger && merger(object, key, value, namespace)) {
      continue;
    }
    if (Array.isArray(value) && Array.isArray(object[key])) {
      object[key] = [...value, ...object[key]];
    } else if (isPlainObject(value) && isPlainObject(object[key])) {
      object[key] = _defu(
        value,
        object[key],
        (namespace ? `${namespace}.` : "") + key.toString(),
        merger
      );
    } else {
      object[key] = value;
    }
  }
  return object;
}
function createDefu(merger) {
  return (...arguments_) => (
    // eslint-disable-next-line unicorn/no-array-reduce
    arguments_.reduce((p, c) => _defu(p, c, "", merger), {})
  );
}
const defu = createDefu();
const defuFn = createDefu((object, key, currentValue) => {
  if (object[key] !== void 0 && typeof currentValue === "function") {
    object[key] = currentValue(object[key]);
    return true;
  }
});

function o(n){throw new Error(`${n} is not implemented yet!`)}let i$1 = class i extends EventEmitter{__unenv__={};readableEncoding=null;readableEnded=true;readableFlowing=false;readableHighWaterMark=0;readableLength=0;readableObjectMode=false;readableAborted=false;readableDidRead=false;closed=false;errored=null;readable=false;destroyed=false;static from(e,t){return new i(t)}constructor(e){super();}_read(e){}read(e){}setEncoding(e){return this}pause(){return this}resume(){return this}isPaused(){return  true}unpipe(e){return this}unshift(e,t){}wrap(e){return this}push(e,t){return  false}_destroy(e,t){this.removeAllListeners();}destroy(e){return this.destroyed=true,this._destroy(e),this}pipe(e,t){return {}}compose(e,t){throw new Error("Method not implemented.")}[Symbol.asyncDispose](){return this.destroy(),Promise.resolve()}async*[Symbol.asyncIterator](){throw o("Readable.asyncIterator")}iterator(e){throw o("Readable.iterator")}map(e,t){throw o("Readable.map")}filter(e,t){throw o("Readable.filter")}forEach(e,t){throw o("Readable.forEach")}reduce(e,t,r){throw o("Readable.reduce")}find(e,t){throw o("Readable.find")}findIndex(e,t){throw o("Readable.findIndex")}some(e,t){throw o("Readable.some")}toArray(e){throw o("Readable.toArray")}every(e,t){throw o("Readable.every")}flatMap(e,t){throw o("Readable.flatMap")}drop(e,t){throw o("Readable.drop")}take(e,t){throw o("Readable.take")}asIndexedPairs(e){throw o("Readable.asIndexedPairs")}};let l$1 = class l extends EventEmitter{__unenv__={};writable=true;writableEnded=false;writableFinished=false;writableHighWaterMark=0;writableLength=0;writableObjectMode=false;writableCorked=0;closed=false;errored=null;writableNeedDrain=false;writableAborted=false;destroyed=false;_data;_encoding="utf8";constructor(e){super();}pipe(e,t){return {}}_write(e,t,r){if(this.writableEnded){r&&r();return}if(this._data===void 0)this._data=e;else {const s=typeof this._data=="string"?Buffer$1.from(this._data,this._encoding||t||"utf8"):this._data,a=typeof e=="string"?Buffer$1.from(e,t||this._encoding||"utf8"):e;this._data=Buffer$1.concat([s,a]);}this._encoding=t,r&&r();}_writev(e,t){}_destroy(e,t){}_final(e){}write(e,t,r){const s=typeof t=="string"?this._encoding:"utf8",a=typeof t=="function"?t:typeof r=="function"?r:void 0;return this._write(e,s,a),true}setDefaultEncoding(e){return this}end(e,t,r){const s=typeof e=="function"?e:typeof t=="function"?t:typeof r=="function"?r:void 0;if(this.writableEnded)return s&&s(),this;const a=e===s?void 0:e;if(a){const u=t===s?void 0:t;this.write(a,u,s);}return this.writableEnded=true,this.writableFinished=true,this.emit("close"),this.emit("finish"),this}cork(){}uncork(){}destroy(e){return this.destroyed=true,delete this._data,this.removeAllListeners(),this}compose(e,t){throw new Error("Method not implemented.")}[Symbol.asyncDispose](){return Promise.resolve()}};const c$1=class c{allowHalfOpen=true;_destroy;constructor(e=new i$1,t=new l$1){Object.assign(this,e),Object.assign(this,t),this._destroy=m(e._destroy,t._destroy);}};function _(){return Object.assign(c$1.prototype,i$1.prototype),Object.assign(c$1.prototype,l$1.prototype),c$1}function m(...n){return function(...e){for(const t of n)t(...e);}}const g=_();class A extends g{__unenv__={};bufferSize=0;bytesRead=0;bytesWritten=0;connecting=false;destroyed=false;pending=false;localAddress="";localPort=0;remoteAddress="";remoteFamily="";remotePort=0;autoSelectFamilyAttemptedAddresses=[];readyState="readOnly";constructor(e){super();}write(e,t,r){return  false}connect(e,t,r){return this}end(e,t,r){return this}setEncoding(e){return this}pause(){return this}resume(){return this}setTimeout(e,t){return this}setNoDelay(e){return this}setKeepAlive(e,t){return this}address(){return {}}unref(){return this}ref(){return this}destroySoon(){this.destroy();}resetAndDestroy(){const e=new Error("ERR_SOCKET_CLOSED");return e.code="ERR_SOCKET_CLOSED",this.destroy(e),this}}class y extends i$1{aborted=false;httpVersion="1.1";httpVersionMajor=1;httpVersionMinor=1;complete=true;connection;socket;headers={};trailers={};method="GET";url="/";statusCode=200;statusMessage="";closed=false;errored=null;readable=false;constructor(e){super(),this.socket=this.connection=e||new A;}get rawHeaders(){const e=this.headers,t=[];for(const r in e)if(Array.isArray(e[r]))for(const s of e[r])t.push(r,s);else t.push(r,e[r]);return t}get rawTrailers(){return []}setTimeout(e,t){return this}get headersDistinct(){return p(this.headers)}get trailersDistinct(){return p(this.trailers)}}function p(n){const e={};for(const[t,r]of Object.entries(n))t&&(e[t]=(Array.isArray(r)?r:[r]).filter(Boolean));return e}class w extends l$1{statusCode=200;statusMessage="";upgrading=false;chunkedEncoding=false;shouldKeepAlive=false;useChunkedEncodingByDefault=false;sendDate=false;finished=false;headersSent=false;strictContentLength=false;connection=null;socket=null;req;_headers={};constructor(e){super(),this.req=e;}assignSocket(e){e._httpMessage=this,this.socket=e,this.connection=e,this.emit("socket",e),this._flush();}_flush(){this.flushHeaders();}detachSocket(e){}writeContinue(e){}writeHead(e,t,r){e&&(this.statusCode=e),typeof t=="string"&&(this.statusMessage=t,t=void 0);const s=r||t;if(s&&!Array.isArray(s))for(const a in s)this.setHeader(a,s[a]);return this.headersSent=true,this}writeProcessing(){}setTimeout(e,t){return this}appendHeader(e,t){e=e.toLowerCase();const r=this._headers[e],s=[...Array.isArray(r)?r:[r],...Array.isArray(t)?t:[t]].filter(Boolean);return this._headers[e]=s.length>1?s:s[0],this}setHeader(e,t){return this._headers[e.toLowerCase()]=t,this}setHeaders(e){for(const[t,r]of Object.entries(e))this.setHeader(t,r);return this}getHeader(e){return this._headers[e.toLowerCase()]}getHeaders(){return this._headers}getHeaderNames(){return Object.keys(this._headers)}hasHeader(e){return e.toLowerCase()in this._headers}removeHeader(e){delete this._headers[e.toLowerCase()];}addTrailers(e){}flushHeaders(){}writeEarlyHints(e,t){typeof t=="function"&&t();}}const E=(()=>{const n=function(){};return n.prototype=Object.create(null),n})();function R(n={}){const e=new E,t=Array.isArray(n)||H(n)?n:Object.entries(n);for(const[r,s]of t)if(s){if(e[r]===void 0){e[r]=s;continue}e[r]=[...Array.isArray(e[r])?e[r]:[e[r]],...Array.isArray(s)?s:[s]];}return e}function H(n){return typeof n?.entries=="function"}function v(n={}){if(n instanceof Headers)return n;const e=new Headers;for(const[t,r]of Object.entries(n))if(r!==void 0){if(Array.isArray(r)){for(const s of r)e.append(t,String(s));continue}e.set(t,String(r));}return e}const S=new Set([101,204,205,304]);async function b(n,e){const t=new y,r=new w(t);t.url=e.url?.toString()||"/";let s;if(!t.url.startsWith("/")){const d=new URL(t.url);s=d.host,t.url=d.pathname+d.search+d.hash;}t.method=e.method||"GET",t.headers=R(e.headers||{}),t.headers.host||(t.headers.host=e.host||s||"localhost"),t.connection.encrypted=t.connection.encrypted||e.protocol==="https",t.body=e.body||null,t.__unenv__=e.context,await n(t,r);let a=r._data;(S.has(r.statusCode)||t.method.toUpperCase()==="HEAD")&&(a=null,delete r._headers["content-length"]);const u={status:r.statusCode,statusText:r.statusMessage,headers:r._headers,body:a};return t.destroy(),r.destroy(),u}async function C(n,e,t={}){try{const r=await b(n,{url:e,...t});return new Response(r.body,{status:r.status,statusText:r.statusText,headers:v(r.headers)})}catch(r){return new Response(r.toString(),{status:Number.parseInt(r.statusCode||r.code)||500,statusText:r.statusText})}}

function hasProp(obj, prop) {
  try {
    return prop in obj;
  } catch {
    return false;
  }
}

class H3Error extends Error {
  static __h3_error__ = true;
  statusCode = 500;
  fatal = false;
  unhandled = false;
  statusMessage;
  data;
  cause;
  constructor(message, opts = {}) {
    super(message, opts);
    if (opts.cause && !this.cause) {
      this.cause = opts.cause;
    }
  }
  toJSON() {
    const obj = {
      message: this.message,
      statusCode: sanitizeStatusCode(this.statusCode, 500)
    };
    if (this.statusMessage) {
      obj.statusMessage = sanitizeStatusMessage(this.statusMessage);
    }
    if (this.data !== void 0) {
      obj.data = this.data;
    }
    return obj;
  }
}
function createError$1(input) {
  if (typeof input === "string") {
    return new H3Error(input);
  }
  if (isError(input)) {
    return input;
  }
  const err = new H3Error(input.message ?? input.statusMessage ?? "", {
    cause: input.cause || input
  });
  if (hasProp(input, "stack")) {
    try {
      Object.defineProperty(err, "stack", {
        get() {
          return input.stack;
        }
      });
    } catch {
      try {
        err.stack = input.stack;
      } catch {
      }
    }
  }
  if (input.data) {
    err.data = input.data;
  }
  if (input.statusCode) {
    err.statusCode = sanitizeStatusCode(input.statusCode, err.statusCode);
  } else if (input.status) {
    err.statusCode = sanitizeStatusCode(input.status, err.statusCode);
  }
  if (input.statusMessage) {
    err.statusMessage = input.statusMessage;
  } else if (input.statusText) {
    err.statusMessage = input.statusText;
  }
  if (err.statusMessage) {
    const originalMessage = err.statusMessage;
    const sanitizedMessage = sanitizeStatusMessage(err.statusMessage);
    if (sanitizedMessage !== originalMessage) {
      console.warn(
        "[h3] Please prefer using `message` for longer error messages instead of `statusMessage`. In the future, `statusMessage` will be sanitized by default."
      );
    }
  }
  if (input.fatal !== void 0) {
    err.fatal = input.fatal;
  }
  if (input.unhandled !== void 0) {
    err.unhandled = input.unhandled;
  }
  return err;
}
function sendError(event, error, debug) {
  if (event.handled) {
    return;
  }
  const h3Error = isError(error) ? error : createError$1(error);
  const responseBody = {
    statusCode: h3Error.statusCode,
    statusMessage: h3Error.statusMessage,
    stack: [],
    data: h3Error.data
  };
  if (debug) {
    responseBody.stack = (h3Error.stack || "").split("\n").map((l) => l.trim());
  }
  if (event.handled) {
    return;
  }
  const _code = Number.parseInt(h3Error.statusCode);
  setResponseStatus(event, _code, h3Error.statusMessage);
  event.node.res.setHeader("content-type", MIMES.json);
  event.node.res.end(JSON.stringify(responseBody, void 0, 2));
}
function isError(input) {
  return input?.constructor?.__h3_error__ === true;
}

function getQuery(event) {
  return getQuery$1(event.path || "");
}
function isMethod(event, expected, allowHead) {
  if (typeof expected === "string") {
    if (event.method === expected) {
      return true;
    }
  } else if (expected.includes(event.method)) {
    return true;
  }
  return false;
}
function assertMethod(event, expected, allowHead) {
  if (!isMethod(event, expected)) {
    throw createError$1({
      statusCode: 405,
      statusMessage: "HTTP method is not allowed."
    });
  }
}
function getRequestHeaders(event) {
  const _headers = {};
  for (const key in event.node.req.headers) {
    const val = event.node.req.headers[key];
    _headers[key] = Array.isArray(val) ? val.filter(Boolean).join(", ") : val;
  }
  return _headers;
}
function getRequestHeader(event, name) {
  const headers = getRequestHeaders(event);
  const value = headers[name.toLowerCase()];
  return value;
}
function getRequestHost(event, opts = {}) {
  if (opts.xForwardedHost) {
    const _header = event.node.req.headers["x-forwarded-host"];
    const xForwardedHost = (_header || "").split(",").shift()?.trim();
    if (xForwardedHost) {
      return xForwardedHost;
    }
  }
  return event.node.req.headers.host || "localhost";
}
function getRequestProtocol(event, opts = {}) {
  if (opts.xForwardedProto !== false && event.node.req.headers["x-forwarded-proto"] === "https") {
    return "https";
  }
  return event.node.req.connection?.encrypted ? "https" : "http";
}
function getRequestURL(event, opts = {}) {
  const host = getRequestHost(event, opts);
  const protocol = getRequestProtocol(event, opts);
  const path = (event.node.req.originalUrl || event.path).replace(
    /^[/\\]+/g,
    "/"
  );
  return new URL(path, `${protocol}://${host}`);
}

const RawBodySymbol = Symbol.for("h3RawBody");
const PayloadMethods$1 = ["PATCH", "POST", "PUT", "DELETE"];
function readRawBody(event, encoding = "utf8") {
  assertMethod(event, PayloadMethods$1);
  const _rawBody = event._requestBody || event.web?.request?.body || event.node.req[RawBodySymbol] || event.node.req.rawBody || event.node.req.body;
  if (_rawBody) {
    const promise2 = Promise.resolve(_rawBody).then((_resolved) => {
      if (Buffer.isBuffer(_resolved)) {
        return _resolved;
      }
      if (typeof _resolved.pipeTo === "function") {
        return new Promise((resolve, reject) => {
          const chunks = [];
          _resolved.pipeTo(
            new WritableStream({
              write(chunk) {
                chunks.push(chunk);
              },
              close() {
                resolve(Buffer.concat(chunks));
              },
              abort(reason) {
                reject(reason);
              }
            })
          ).catch(reject);
        });
      } else if (typeof _resolved.pipe === "function") {
        return new Promise((resolve, reject) => {
          const chunks = [];
          _resolved.on("data", (chunk) => {
            chunks.push(chunk);
          }).on("end", () => {
            resolve(Buffer.concat(chunks));
          }).on("error", reject);
        });
      }
      if (_resolved.constructor === Object) {
        return Buffer.from(JSON.stringify(_resolved));
      }
      if (_resolved instanceof URLSearchParams) {
        return Buffer.from(_resolved.toString());
      }
      if (_resolved instanceof FormData) {
        return new Response(_resolved).bytes().then((uint8arr) => Buffer.from(uint8arr));
      }
      return Buffer.from(_resolved);
    });
    return encoding ? promise2.then((buff) => buff.toString(encoding)) : promise2;
  }
  if (!Number.parseInt(event.node.req.headers["content-length"] || "") && !/\bchunked\b/i.test(
    String(event.node.req.headers["transfer-encoding"] ?? "")
  )) {
    return Promise.resolve(void 0);
  }
  const promise = event.node.req[RawBodySymbol] = new Promise(
    (resolve, reject) => {
      const bodyData = [];
      event.node.req.on("error", (err) => {
        reject(err);
      }).on("data", (chunk) => {
        bodyData.push(chunk);
      }).on("end", () => {
        resolve(Buffer.concat(bodyData));
      });
    }
  );
  const result = encoding ? promise.then((buff) => buff.toString(encoding)) : promise;
  return result;
}
function getRequestWebStream(event) {
  if (!PayloadMethods$1.includes(event.method)) {
    return;
  }
  const bodyStream = event.web?.request?.body || event._requestBody;
  if (bodyStream) {
    return bodyStream;
  }
  const _hasRawBody = RawBodySymbol in event.node.req || "rawBody" in event.node.req || "body" in event.node.req || "__unenv__" in event.node.req;
  if (_hasRawBody) {
    return new ReadableStream({
      async start(controller) {
        const _rawBody = await readRawBody(event, false);
        if (_rawBody) {
          controller.enqueue(_rawBody);
        }
        controller.close();
      }
    });
  }
  return new ReadableStream({
    start: (controller) => {
      event.node.req.on("data", (chunk) => {
        controller.enqueue(chunk);
      });
      event.node.req.on("end", () => {
        controller.close();
      });
      event.node.req.on("error", (err) => {
        controller.error(err);
      });
    }
  });
}

function handleCacheHeaders(event, opts) {
  const cacheControls = ["public", ...opts.cacheControls || []];
  let cacheMatched = false;
  if (opts.maxAge !== void 0) {
    cacheControls.push(`max-age=${+opts.maxAge}`, `s-maxage=${+opts.maxAge}`);
  }
  if (opts.modifiedTime) {
    const modifiedTime = new Date(opts.modifiedTime);
    const ifModifiedSince = event.node.req.headers["if-modified-since"];
    event.node.res.setHeader("last-modified", modifiedTime.toUTCString());
    if (ifModifiedSince && new Date(ifModifiedSince) >= modifiedTime) {
      cacheMatched = true;
    }
  }
  if (opts.etag) {
    event.node.res.setHeader("etag", opts.etag);
    const ifNonMatch = event.node.req.headers["if-none-match"];
    if (ifNonMatch === opts.etag) {
      cacheMatched = true;
    }
  }
  event.node.res.setHeader("cache-control", cacheControls.join(", "));
  if (cacheMatched) {
    event.node.res.statusCode = 304;
    if (!event.handled) {
      event.node.res.end();
    }
    return true;
  }
  return false;
}

const MIMES = {
  html: "text/html",
  json: "application/json"
};

const DISALLOWED_STATUS_CHARS = /[^\u0009\u0020-\u007E]/g;
function sanitizeStatusMessage(statusMessage = "") {
  return statusMessage.replace(DISALLOWED_STATUS_CHARS, "");
}
function sanitizeStatusCode(statusCode, defaultStatusCode = 200) {
  if (!statusCode) {
    return defaultStatusCode;
  }
  if (typeof statusCode === "string") {
    statusCode = Number.parseInt(statusCode, 10);
  }
  if (statusCode < 100 || statusCode > 999) {
    return defaultStatusCode;
  }
  return statusCode;
}

function getDistinctCookieKey(name, opts) {
  return [name, opts.domain || "", opts.path || "/"].join(";");
}

function parseCookies(event) {
  return parse$1(event.node.req.headers.cookie || "");
}
function getCookie(event, name) {
  return parseCookies(event)[name];
}
function setCookie(event, name, value, serializeOptions = {}) {
  if (!serializeOptions.path) {
    serializeOptions = { path: "/", ...serializeOptions };
  }
  const newCookie = serialize$2(name, value, serializeOptions);
  const currentCookies = splitCookiesString(
    event.node.res.getHeader("set-cookie")
  );
  if (currentCookies.length === 0) {
    event.node.res.setHeader("set-cookie", newCookie);
    return;
  }
  const newCookieKey = getDistinctCookieKey(name, serializeOptions);
  event.node.res.removeHeader("set-cookie");
  for (const cookie of currentCookies) {
    const parsed = parseSetCookie(cookie);
    const key = getDistinctCookieKey(parsed.name, parsed);
    if (key === newCookieKey) {
      continue;
    }
    event.node.res.appendHeader("set-cookie", cookie);
  }
  event.node.res.appendHeader("set-cookie", newCookie);
}
function deleteCookie(event, name, serializeOptions) {
  setCookie(event, name, "", {
    ...serializeOptions,
    maxAge: 0
  });
}
function splitCookiesString(cookiesString) {
  if (Array.isArray(cookiesString)) {
    return cookiesString.flatMap((c) => splitCookiesString(c));
  }
  if (typeof cookiesString !== "string") {
    return [];
  }
  const cookiesStrings = [];
  let pos = 0;
  let start;
  let ch;
  let lastComma;
  let nextStart;
  let cookiesSeparatorFound;
  const skipWhitespace = () => {
    while (pos < cookiesString.length && /\s/.test(cookiesString.charAt(pos))) {
      pos += 1;
    }
    return pos < cookiesString.length;
  };
  const notSpecialChar = () => {
    ch = cookiesString.charAt(pos);
    return ch !== "=" && ch !== ";" && ch !== ",";
  };
  while (pos < cookiesString.length) {
    start = pos;
    cookiesSeparatorFound = false;
    while (skipWhitespace()) {
      ch = cookiesString.charAt(pos);
      if (ch === ",") {
        lastComma = pos;
        pos += 1;
        skipWhitespace();
        nextStart = pos;
        while (pos < cookiesString.length && notSpecialChar()) {
          pos += 1;
        }
        if (pos < cookiesString.length && cookiesString.charAt(pos) === "=") {
          cookiesSeparatorFound = true;
          pos = nextStart;
          cookiesStrings.push(cookiesString.slice(start, lastComma));
          start = pos;
        } else {
          pos = lastComma + 1;
        }
      } else {
        pos += 1;
      }
    }
    if (!cookiesSeparatorFound || pos >= cookiesString.length) {
      cookiesStrings.push(cookiesString.slice(start));
    }
  }
  return cookiesStrings;
}

const defer = typeof setImmediate === "undefined" ? (fn) => fn() : setImmediate;
function send(event, data, type) {
  if (type) {
    defaultContentType(event, type);
  }
  return new Promise((resolve) => {
    defer(() => {
      if (!event.handled) {
        event.node.res.end(data);
      }
      resolve();
    });
  });
}
function sendNoContent(event, code) {
  if (event.handled) {
    return;
  }
  if (!code && event.node.res.statusCode !== 200) {
    code = event.node.res.statusCode;
  }
  const _code = sanitizeStatusCode(code, 204);
  if (_code === 204) {
    event.node.res.removeHeader("content-length");
  }
  event.node.res.writeHead(_code);
  event.node.res.end();
}
function setResponseStatus(event, code, text) {
  if (code) {
    event.node.res.statusCode = sanitizeStatusCode(
      code,
      event.node.res.statusCode
    );
  }
  if (text) {
    event.node.res.statusMessage = sanitizeStatusMessage(text);
  }
}
function getResponseStatus(event) {
  return event.node.res.statusCode;
}
function getResponseStatusText(event) {
  return event.node.res.statusMessage;
}
function defaultContentType(event, type) {
  if (type && event.node.res.statusCode !== 304 && !event.node.res.getHeader("content-type")) {
    event.node.res.setHeader("content-type", type);
  }
}
function sendRedirect(event, location, code = 302) {
  event.node.res.statusCode = sanitizeStatusCode(
    code,
    event.node.res.statusCode
  );
  event.node.res.setHeader("location", location);
  const encodedLoc = location.replace(/"/g, "%22");
  const html = `<!DOCTYPE html><html><head><meta http-equiv="refresh" content="0; url=${encodedLoc}"></head></html>`;
  return send(event, html, MIMES.html);
}
function getResponseHeader(event, name) {
  return event.node.res.getHeader(name);
}
function setResponseHeaders(event, headers) {
  for (const [name, value] of Object.entries(headers)) {
    event.node.res.setHeader(
      name,
      value
    );
  }
}
const setHeaders = setResponseHeaders;
function setResponseHeader(event, name, value) {
  event.node.res.setHeader(name, value);
}
function appendResponseHeader(event, name, value) {
  let current = event.node.res.getHeader(name);
  if (!current) {
    event.node.res.setHeader(name, value);
    return;
  }
  if (!Array.isArray(current)) {
    current = [current.toString()];
  }
  event.node.res.setHeader(name, [...current, value]);
}
function removeResponseHeader(event, name) {
  return event.node.res.removeHeader(name);
}
function isStream(data) {
  if (!data || typeof data !== "object") {
    return false;
  }
  if (typeof data.pipe === "function") {
    if (typeof data._read === "function") {
      return true;
    }
    if (typeof data.abort === "function") {
      return true;
    }
  }
  if (typeof data.pipeTo === "function") {
    return true;
  }
  return false;
}
function isWebResponse(data) {
  return typeof Response !== "undefined" && data instanceof Response;
}
function sendStream(event, stream) {
  if (!stream || typeof stream !== "object") {
    throw new Error("[h3] Invalid stream provided.");
  }
  event.node.res._data = stream;
  if (!event.node.res.socket) {
    event._handled = true;
    return Promise.resolve();
  }
  if (hasProp(stream, "pipeTo") && typeof stream.pipeTo === "function") {
    return stream.pipeTo(
      new WritableStream({
        write(chunk) {
          event.node.res.write(chunk);
        }
      })
    ).then(() => {
      event.node.res.end();
    });
  }
  if (hasProp(stream, "pipe") && typeof stream.pipe === "function") {
    return new Promise((resolve, reject) => {
      stream.pipe(event.node.res);
      if (stream.on) {
        stream.on("end", () => {
          event.node.res.end();
          resolve();
        });
        stream.on("error", (error) => {
          reject(error);
        });
      }
      event.node.res.on("close", () => {
        if (stream.abort) {
          stream.abort();
        }
      });
    });
  }
  throw new Error("[h3] Invalid or incompatible stream provided.");
}
function sendWebResponse(event, response) {
  for (const [key, value] of response.headers) {
    if (key === "set-cookie") {
      event.node.res.appendHeader(key, splitCookiesString(value));
    } else {
      event.node.res.setHeader(key, value);
    }
  }
  if (response.status) {
    event.node.res.statusCode = sanitizeStatusCode(
      response.status,
      event.node.res.statusCode
    );
  }
  if (response.statusText) {
    event.node.res.statusMessage = sanitizeStatusMessage(response.statusText);
  }
  if (response.redirected) {
    event.node.res.setHeader("location", response.url);
  }
  if (!response.body) {
    event.node.res.end();
    return;
  }
  return sendStream(event, response.body);
}

const PayloadMethods = /* @__PURE__ */ new Set(["PATCH", "POST", "PUT", "DELETE"]);
const ignoredHeaders = /* @__PURE__ */ new Set([
  "transfer-encoding",
  "accept-encoding",
  "connection",
  "keep-alive",
  "upgrade",
  "expect",
  "host",
  "accept"
]);
async function proxyRequest(event, target, opts = {}) {
  let body;
  let duplex;
  if (PayloadMethods.has(event.method)) {
    if (opts.streamRequest) {
      body = getRequestWebStream(event);
      duplex = "half";
    } else {
      body = await readRawBody(event, false).catch(() => void 0);
    }
  }
  const method = opts.fetchOptions?.method || event.method;
  const fetchHeaders = mergeHeaders$1(
    getProxyRequestHeaders(event, { host: target.startsWith("/") }),
    opts.fetchOptions?.headers,
    opts.headers
  );
  return sendProxy(event, target, {
    ...opts,
    fetchOptions: {
      method,
      body,
      duplex,
      ...opts.fetchOptions,
      headers: fetchHeaders
    }
  });
}
async function sendProxy(event, target, opts = {}) {
  let response;
  try {
    response = await _getFetch(opts.fetch)(target, {
      headers: opts.headers,
      ignoreResponseError: true,
      // make $ofetch.raw transparent
      ...opts.fetchOptions
    });
  } catch (error) {
    throw createError$1({
      status: 502,
      statusMessage: "Bad Gateway",
      cause: error
    });
  }
  event.node.res.statusCode = sanitizeStatusCode(
    response.status,
    event.node.res.statusCode
  );
  event.node.res.statusMessage = sanitizeStatusMessage(response.statusText);
  const cookies = [];
  for (const [key, value] of response.headers.entries()) {
    if (key === "content-encoding") {
      continue;
    }
    if (key === "content-length") {
      continue;
    }
    if (key === "set-cookie") {
      cookies.push(...splitCookiesString(value));
      continue;
    }
    event.node.res.setHeader(key, value);
  }
  if (cookies.length > 0) {
    event.node.res.setHeader(
      "set-cookie",
      cookies.map((cookie) => {
        if (opts.cookieDomainRewrite) {
          cookie = rewriteCookieProperty(
            cookie,
            opts.cookieDomainRewrite,
            "domain"
          );
        }
        if (opts.cookiePathRewrite) {
          cookie = rewriteCookieProperty(
            cookie,
            opts.cookiePathRewrite,
            "path"
          );
        }
        return cookie;
      })
    );
  }
  if (opts.onResponse) {
    await opts.onResponse(event, response);
  }
  if (response._data !== void 0) {
    return response._data;
  }
  if (event.handled) {
    return;
  }
  if (opts.sendStream === false) {
    const data = new Uint8Array(await response.arrayBuffer());
    return event.node.res.end(data);
  }
  if (response.body) {
    for await (const chunk of response.body) {
      event.node.res.write(chunk);
    }
  }
  return event.node.res.end();
}
function getProxyRequestHeaders(event, opts) {
  const headers = /* @__PURE__ */ Object.create(null);
  const reqHeaders = getRequestHeaders(event);
  for (const name in reqHeaders) {
    if (!ignoredHeaders.has(name) || name === "host" && opts?.host) {
      headers[name] = reqHeaders[name];
    }
  }
  return headers;
}
function fetchWithEvent(event, req, init, options) {
  return _getFetch(options?.fetch)(req, {
    ...init,
    context: init?.context || event.context,
    headers: {
      ...getProxyRequestHeaders(event, {
        host: typeof req === "string" && req.startsWith("/")
      }),
      ...init?.headers
    }
  });
}
function _getFetch(_fetch) {
  if (_fetch) {
    return _fetch;
  }
  if (globalThis.fetch) {
    return globalThis.fetch;
  }
  throw new Error(
    "fetch is not available. Try importing `node-fetch-native/polyfill` for Node.js."
  );
}
function rewriteCookieProperty(header, map, property) {
  const _map = typeof map === "string" ? { "*": map } : map;
  return header.replace(
    new RegExp(`(;\\s*${property}=)([^;]+)`, "gi"),
    (match, prefix, previousValue) => {
      let newValue;
      if (previousValue in _map) {
        newValue = _map[previousValue];
      } else if ("*" in _map) {
        newValue = _map["*"];
      } else {
        return match;
      }
      return newValue ? prefix + newValue : "";
    }
  );
}
function mergeHeaders$1(defaults, ...inputs) {
  const _inputs = inputs.filter(Boolean);
  if (_inputs.length === 0) {
    return defaults;
  }
  const merged = new Headers(defaults);
  for (const input of _inputs) {
    const entries = Array.isArray(input) ? input : typeof input.entries === "function" ? input.entries() : Object.entries(input);
    for (const [key, value] of entries) {
      if (value !== void 0) {
        merged.set(key, value);
      }
    }
  }
  return merged;
}

class H3Event {
  "__is_event__" = true;
  // Context
  node;
  // Node
  web;
  // Web
  context = {};
  // Shared
  // Request
  _method;
  _path;
  _headers;
  _requestBody;
  // Response
  _handled = false;
  // Hooks
  _onBeforeResponseCalled;
  _onAfterResponseCalled;
  constructor(req, res) {
    this.node = { req, res };
  }
  // --- Request ---
  get method() {
    if (!this._method) {
      this._method = (this.node.req.method || "GET").toUpperCase();
    }
    return this._method;
  }
  get path() {
    return this._path || this.node.req.url || "/";
  }
  get headers() {
    if (!this._headers) {
      this._headers = _normalizeNodeHeaders(this.node.req.headers);
    }
    return this._headers;
  }
  // --- Respoonse ---
  get handled() {
    return this._handled || this.node.res.writableEnded || this.node.res.headersSent;
  }
  respondWith(response) {
    return Promise.resolve(response).then(
      (_response) => sendWebResponse(this, _response)
    );
  }
  // --- Utils ---
  toString() {
    return `[${this.method}] ${this.path}`;
  }
  toJSON() {
    return this.toString();
  }
  // --- Deprecated ---
  /** @deprecated Please use `event.node.req` instead. */
  get req() {
    return this.node.req;
  }
  /** @deprecated Please use `event.node.res` instead. */
  get res() {
    return this.node.res;
  }
}
function isEvent(input) {
  return hasProp(input, "__is_event__");
}
function createEvent(req, res) {
  return new H3Event(req, res);
}
function _normalizeNodeHeaders(nodeHeaders) {
  const headers = new Headers();
  for (const [name, value] of Object.entries(nodeHeaders)) {
    if (Array.isArray(value)) {
      for (const item of value) {
        headers.append(name, item);
      }
    } else if (value) {
      headers.set(name, value);
    }
  }
  return headers;
}

function defineEventHandler(handler) {
  if (typeof handler === "function") {
    handler.__is_handler__ = true;
    return handler;
  }
  const _hooks = {
    onRequest: _normalizeArray(handler.onRequest),
    onBeforeResponse: _normalizeArray(handler.onBeforeResponse)
  };
  const _handler = (event) => {
    return _callHandler(event, handler.handler, _hooks);
  };
  _handler.__is_handler__ = true;
  _handler.__resolve__ = handler.handler.__resolve__;
  _handler.__websocket__ = handler.websocket;
  return _handler;
}
function _normalizeArray(input) {
  return input ? Array.isArray(input) ? input : [input] : void 0;
}
async function _callHandler(event, handler, hooks) {
  if (hooks.onRequest) {
    for (const hook of hooks.onRequest) {
      await hook(event);
      if (event.handled) {
        return;
      }
    }
  }
  const body = await handler(event);
  const response = { body };
  if (hooks.onBeforeResponse) {
    for (const hook of hooks.onBeforeResponse) {
      await hook(event, response);
    }
  }
  return response.body;
}
const eventHandler = defineEventHandler;
function isEventHandler(input) {
  return hasProp(input, "__is_handler__");
}
function toEventHandler(input, _, _route) {
  return input;
}
function defineLazyEventHandler(factory) {
  let _promise;
  let _resolved;
  const resolveHandler = () => {
    if (_resolved) {
      return Promise.resolve(_resolved);
    }
    if (!_promise) {
      _promise = Promise.resolve(factory()).then((r) => {
        const handler2 = r.default || r;
        if (typeof handler2 !== "function") {
          throw new TypeError(
            "Invalid lazy handler result. It should be a function:",
            handler2
          );
        }
        _resolved = { handler: toEventHandler(r.default || r) };
        return _resolved;
      });
    }
    return _promise;
  };
  const handler = eventHandler((event) => {
    if (_resolved) {
      return _resolved.handler(event);
    }
    return resolveHandler().then((r) => r.handler(event));
  });
  handler.__resolve__ = resolveHandler;
  return handler;
}
const lazyEventHandler = defineLazyEventHandler;

function createApp(options = {}) {
  const stack = [];
  const handler = createAppEventHandler(stack, options);
  const resolve = createResolver(stack);
  handler.__resolve__ = resolve;
  const getWebsocket = cachedFn(() => websocketOptions(resolve, options));
  const app = {
    // @ts-expect-error
    use: (arg1, arg2, arg3) => use(app, arg1, arg2, arg3),
    resolve,
    handler,
    stack,
    options,
    get websocket() {
      return getWebsocket();
    }
  };
  return app;
}
function use(app, arg1, arg2, arg3) {
  if (Array.isArray(arg1)) {
    for (const i of arg1) {
      use(app, i, arg2, arg3);
    }
  } else if (Array.isArray(arg2)) {
    for (const i of arg2) {
      use(app, arg1, i, arg3);
    }
  } else if (typeof arg1 === "string") {
    app.stack.push(
      normalizeLayer({ ...arg3, route: arg1, handler: arg2 })
    );
  } else if (typeof arg1 === "function") {
    app.stack.push(normalizeLayer({ ...arg2, handler: arg1 }));
  } else {
    app.stack.push(normalizeLayer({ ...arg1 }));
  }
  return app;
}
function createAppEventHandler(stack, options) {
  const spacing = options.debug ? 2 : void 0;
  return eventHandler(async (event) => {
    event.node.req.originalUrl = event.node.req.originalUrl || event.node.req.url || "/";
    const _rawReqUrl = event.node.req.url || "/";
    const _reqPath = _decodePath(event._path || _rawReqUrl);
    event._path = _reqPath;
    const _needsRawUrl = _reqPath !== _rawReqUrl;
    let _layerPath;
    if (options.onRequest) {
      await options.onRequest(event);
    }
    for (const layer of stack) {
      if (layer.route.length > 1) {
        if (!_reqPath.startsWith(layer.route)) {
          continue;
        }
        _layerPath = _reqPath.slice(layer.route.length) || "/";
      } else {
        _layerPath = _reqPath;
      }
      if (layer.match && !layer.match(_layerPath, event)) {
        continue;
      }
      event._path = _layerPath;
      event.node.req.url = _needsRawUrl ? layer.route.length > 1 ? _rawReqUrl.slice(layer.route.length) || "/" : _rawReqUrl : _layerPath;
      const val = await layer.handler(event);
      const _body = val === void 0 ? void 0 : await val;
      if (_body !== void 0) {
        const _response = { body: _body };
        if (options.onBeforeResponse) {
          event._onBeforeResponseCalled = true;
          await options.onBeforeResponse(event, _response);
        }
        await handleHandlerResponse(event, _response.body, spacing);
        if (options.onAfterResponse) {
          event._onAfterResponseCalled = true;
          await options.onAfterResponse(event, _response);
        }
        return;
      }
      if (event.handled) {
        if (options.onAfterResponse) {
          event._onAfterResponseCalled = true;
          await options.onAfterResponse(event, void 0);
        }
        return;
      }
    }
    if (!event.handled) {
      throw createError$1({
        statusCode: 404,
        statusMessage: `Cannot find any path matching ${event.path || "/"}.`
      });
    }
    if (options.onAfterResponse) {
      event._onAfterResponseCalled = true;
      await options.onAfterResponse(event, void 0);
    }
  });
}
function createResolver(stack) {
  return async (path) => {
    let _layerPath;
    for (const layer of stack) {
      if (layer.route === "/" && !layer.handler.__resolve__) {
        continue;
      }
      if (!path.startsWith(layer.route)) {
        continue;
      }
      _layerPath = path.slice(layer.route.length) || "/";
      if (layer.match && !layer.match(_layerPath, void 0)) {
        continue;
      }
      let res = { route: layer.route, handler: layer.handler };
      if (res.handler.__resolve__) {
        const _res = await res.handler.__resolve__(_layerPath);
        if (!_res) {
          continue;
        }
        res = {
          ...res,
          ..._res,
          route: joinURL(res.route || "/", _res.route || "/")
        };
      }
      return res;
    }
  };
}
function normalizeLayer(input) {
  let handler = input.handler;
  if (handler.handler) {
    handler = handler.handler;
  }
  if (input.lazy) {
    handler = lazyEventHandler(handler);
  } else if (!isEventHandler(handler)) {
    handler = toEventHandler(handler, void 0, input.route);
  }
  return {
    route: withoutTrailingSlash(input.route),
    match: input.match,
    handler
  };
}
function handleHandlerResponse(event, val, jsonSpace) {
  if (val === null) {
    return sendNoContent(event);
  }
  if (val) {
    if (isWebResponse(val)) {
      return sendWebResponse(event, val);
    }
    if (isStream(val)) {
      return sendStream(event, val);
    }
    if (val.buffer) {
      return send(event, val);
    }
    if (val.arrayBuffer && typeof val.arrayBuffer === "function") {
      return val.arrayBuffer().then((arrayBuffer) => {
        return send(event, Buffer.from(arrayBuffer), val.type);
      });
    }
    if (val instanceof Error) {
      throw createError$1(val);
    }
    if (typeof val.end === "function") {
      return true;
    }
  }
  const valType = typeof val;
  if (valType === "string") {
    return send(event, val, MIMES.html);
  }
  if (valType === "object" || valType === "boolean" || valType === "number") {
    return send(event, JSON.stringify(val, void 0, jsonSpace), MIMES.json);
  }
  if (valType === "bigint") {
    return send(event, val.toString(), MIMES.json);
  }
  throw createError$1({
    statusCode: 500,
    statusMessage: `[h3] Cannot send ${valType} as response.`
  });
}
function cachedFn(fn) {
  let cache;
  return () => {
    if (!cache) {
      cache = fn();
    }
    return cache;
  };
}
function _decodePath(url) {
  const qIndex = url.indexOf("?");
  const path = qIndex === -1 ? url : url.slice(0, qIndex);
  const query = qIndex === -1 ? "" : url.slice(qIndex);
  const decodedPath = path.includes("%25") ? decodePath(path.replace(/%25/g, "%2525")) : decodePath(path);
  return decodedPath + query;
}
function websocketOptions(evResolver, appOptions) {
  return {
    ...appOptions.websocket,
    async resolve(info) {
      const url = info.request?.url || info.url || "/";
      const { pathname } = typeof url === "string" ? parseURL(url) : url;
      const resolved = await evResolver(pathname);
      return resolved?.handler?.__websocket__ || {};
    }
  };
}

const RouterMethods = [
  "connect",
  "delete",
  "get",
  "head",
  "options",
  "post",
  "put",
  "trace",
  "patch"
];
function createRouter(opts = {}) {
  const _router = createRouter$1({});
  const routes = {};
  let _matcher;
  const router = {};
  const addRoute = (path, handler, method) => {
    let route = routes[path];
    if (!route) {
      routes[path] = route = { path, handlers: {} };
      _router.insert(path, route);
    }
    if (Array.isArray(method)) {
      for (const m of method) {
        addRoute(path, handler, m);
      }
    } else {
      route.handlers[method] = toEventHandler(handler);
    }
    return router;
  };
  router.use = router.add = (path, handler, method) => addRoute(path, handler, method || "all");
  for (const method of RouterMethods) {
    router[method] = (path, handle) => router.add(path, handle, method);
  }
  const matchHandler = (path = "/", method = "get") => {
    const qIndex = path.indexOf("?");
    if (qIndex !== -1) {
      path = path.slice(0, Math.max(0, qIndex));
    }
    const matched = _router.lookup(path);
    if (!matched || !matched.handlers) {
      return {
        error: createError$1({
          statusCode: 404,
          name: "Not Found",
          statusMessage: `Cannot find any route matching ${path || "/"}.`
        })
      };
    }
    let handler = matched.handlers[method] || matched.handlers.all;
    if (!handler) {
      if (!_matcher) {
        _matcher = toRouteMatcher(_router);
      }
      const _matches = _matcher.matchAll(path).reverse();
      for (const _match of _matches) {
        if (_match.handlers[method]) {
          handler = _match.handlers[method];
          matched.handlers[method] = matched.handlers[method] || handler;
          break;
        }
        if (_match.handlers.all) {
          handler = _match.handlers.all;
          matched.handlers.all = matched.handlers.all || handler;
          break;
        }
      }
    }
    if (!handler) {
      return {
        error: createError$1({
          statusCode: 405,
          name: "Method Not Allowed",
          statusMessage: `Method ${method} is not allowed on this route.`
        })
      };
    }
    return { matched, handler };
  };
  const isPreemptive = opts.preemptive || opts.preemtive;
  router.handler = eventHandler((event) => {
    const match = matchHandler(
      event.path,
      event.method.toLowerCase()
    );
    if ("error" in match) {
      if (isPreemptive) {
        throw match.error;
      } else {
        return;
      }
    }
    event.context.matchedRoute = match.matched;
    const params = match.matched.params || {};
    event.context.params = params;
    return Promise.resolve(match.handler(event)).then((res) => {
      if (res === void 0 && isPreemptive) {
        return null;
      }
      return res;
    });
  });
  router.handler.__resolve__ = async (path) => {
    path = withLeadingSlash(path);
    const match = matchHandler(path);
    if ("error" in match) {
      return;
    }
    let res = {
      route: match.matched.path,
      handler: match.handler
    };
    if (match.handler.__resolve__) {
      const _res = await match.handler.__resolve__(path);
      if (!_res) {
        return;
      }
      res = { ...res, ..._res };
    }
    return res;
  };
  return router;
}
function toNodeListener(app) {
  const toNodeHandle = async function(req, res) {
    const event = createEvent(req, res);
    try {
      await app.handler(event);
    } catch (_error) {
      const error = createError$1(_error);
      if (!isError(_error)) {
        error.unhandled = true;
      }
      setResponseStatus(event, error.statusCode, error.statusMessage);
      if (app.options.onError) {
        await app.options.onError(error, event);
      }
      if (event.handled) {
        return;
      }
      if (error.unhandled || error.fatal) {
        console.error("[h3]", error.fatal ? "[fatal]" : "[unhandled]", error);
      }
      if (app.options.onBeforeResponse && !event._onBeforeResponseCalled) {
        await app.options.onBeforeResponse(event, { body: error });
      }
      await sendError(event, error, !!app.options.debug);
      if (app.options.onAfterResponse && !event._onAfterResponseCalled) {
        await app.options.onAfterResponse(event, { body: error });
      }
    }
  };
  return toNodeHandle;
}

function flatHooks(configHooks, hooks = {}, parentName) {
  for (const key in configHooks) {
    const subHook = configHooks[key];
    const name = parentName ? `${parentName}:${key}` : key;
    if (typeof subHook === "object" && subHook !== null) {
      flatHooks(subHook, hooks, name);
    } else if (typeof subHook === "function") {
      hooks[name] = subHook;
    }
  }
  return hooks;
}
const defaultTask = { run: (function_) => function_() };
const _createTask = () => defaultTask;
const createTask = typeof console.createTask !== "undefined" ? console.createTask : _createTask;
function serialTaskCaller(hooks, args) {
  const name = args.shift();
  const task = createTask(name);
  return hooks.reduce(
    (promise, hookFunction) => promise.then(() => task.run(() => hookFunction(...args))),
    Promise.resolve()
  );
}
function parallelTaskCaller(hooks, args) {
  const name = args.shift();
  const task = createTask(name);
  return Promise.all(hooks.map((hook) => task.run(() => hook(...args))));
}
function callEachWith(callbacks, arg0) {
  for (const callback of [...callbacks]) {
    callback(arg0);
  }
}

class Hookable {
  constructor() {
    this._hooks = {};
    this._before = void 0;
    this._after = void 0;
    this._deprecatedMessages = void 0;
    this._deprecatedHooks = {};
    this.hook = this.hook.bind(this);
    this.callHook = this.callHook.bind(this);
    this.callHookWith = this.callHookWith.bind(this);
  }
  hook(name, function_, options = {}) {
    if (!name || typeof function_ !== "function") {
      return () => {
      };
    }
    const originalName = name;
    let dep;
    while (this._deprecatedHooks[name]) {
      dep = this._deprecatedHooks[name];
      name = dep.to;
    }
    if (dep && !options.allowDeprecated) {
      let message = dep.message;
      if (!message) {
        message = `${originalName} hook has been deprecated` + (dep.to ? `, please use ${dep.to}` : "");
      }
      if (!this._deprecatedMessages) {
        this._deprecatedMessages = /* @__PURE__ */ new Set();
      }
      if (!this._deprecatedMessages.has(message)) {
        console.warn(message);
        this._deprecatedMessages.add(message);
      }
    }
    if (!function_.name) {
      try {
        Object.defineProperty(function_, "name", {
          get: () => "_" + name.replace(/\W+/g, "_") + "_hook_cb",
          configurable: true
        });
      } catch {
      }
    }
    this._hooks[name] = this._hooks[name] || [];
    this._hooks[name].push(function_);
    return () => {
      if (function_) {
        this.removeHook(name, function_);
        function_ = void 0;
      }
    };
  }
  hookOnce(name, function_) {
    let _unreg;
    let _function = (...arguments_) => {
      if (typeof _unreg === "function") {
        _unreg();
      }
      _unreg = void 0;
      _function = void 0;
      return function_(...arguments_);
    };
    _unreg = this.hook(name, _function);
    return _unreg;
  }
  removeHook(name, function_) {
    if (this._hooks[name]) {
      const index = this._hooks[name].indexOf(function_);
      if (index !== -1) {
        this._hooks[name].splice(index, 1);
      }
      if (this._hooks[name].length === 0) {
        delete this._hooks[name];
      }
    }
  }
  deprecateHook(name, deprecated) {
    this._deprecatedHooks[name] = typeof deprecated === "string" ? { to: deprecated } : deprecated;
    const _hooks = this._hooks[name] || [];
    delete this._hooks[name];
    for (const hook of _hooks) {
      this.hook(name, hook);
    }
  }
  deprecateHooks(deprecatedHooks) {
    Object.assign(this._deprecatedHooks, deprecatedHooks);
    for (const name in deprecatedHooks) {
      this.deprecateHook(name, deprecatedHooks[name]);
    }
  }
  addHooks(configHooks) {
    const hooks = flatHooks(configHooks);
    const removeFns = Object.keys(hooks).map(
      (key) => this.hook(key, hooks[key])
    );
    return () => {
      for (const unreg of removeFns.splice(0, removeFns.length)) {
        unreg();
      }
    };
  }
  removeHooks(configHooks) {
    const hooks = flatHooks(configHooks);
    for (const key in hooks) {
      this.removeHook(key, hooks[key]);
    }
  }
  removeAllHooks() {
    for (const key in this._hooks) {
      delete this._hooks[key];
    }
  }
  callHook(name, ...arguments_) {
    arguments_.unshift(name);
    return this.callHookWith(serialTaskCaller, name, ...arguments_);
  }
  callHookParallel(name, ...arguments_) {
    arguments_.unshift(name);
    return this.callHookWith(parallelTaskCaller, name, ...arguments_);
  }
  callHookWith(caller, name, ...arguments_) {
    const event = this._before || this._after ? { name, args: arguments_, context: {} } : void 0;
    if (this._before) {
      callEachWith(this._before, event);
    }
    const result = caller(
      name in this._hooks ? [...this._hooks[name]] : [],
      arguments_
    );
    if (result instanceof Promise) {
      return result.finally(() => {
        if (this._after && event) {
          callEachWith(this._after, event);
        }
      });
    }
    if (this._after && event) {
      callEachWith(this._after, event);
    }
    return result;
  }
  beforeEach(function_) {
    this._before = this._before || [];
    this._before.push(function_);
    return () => {
      if (this._before !== void 0) {
        const index = this._before.indexOf(function_);
        if (index !== -1) {
          this._before.splice(index, 1);
        }
      }
    };
  }
  afterEach(function_) {
    this._after = this._after || [];
    this._after.push(function_);
    return () => {
      if (this._after !== void 0) {
        const index = this._after.indexOf(function_);
        if (index !== -1) {
          this._after.splice(index, 1);
        }
      }
    };
  }
}
function createHooks() {
  return new Hookable();
}

const s$1=globalThis.Headers,i=globalThis.AbortController,l=globalThis.fetch||(()=>{throw new Error("[node-fetch-native] Failed to fetch: `globalThis.fetch` is not available!")});

class FetchError extends Error {
  constructor(message, opts) {
    super(message, opts);
    this.name = "FetchError";
    if (opts?.cause && !this.cause) {
      this.cause = opts.cause;
    }
  }
}
function createFetchError(ctx) {
  const errorMessage = ctx.error?.message || ctx.error?.toString() || "";
  const method = ctx.request?.method || ctx.options?.method || "GET";
  const url = ctx.request?.url || String(ctx.request) || "/";
  const requestStr = `[${method}] ${JSON.stringify(url)}`;
  const statusStr = ctx.response ? `${ctx.response.status} ${ctx.response.statusText}` : "<no response>";
  const message = `${requestStr}: ${statusStr}${errorMessage ? ` ${errorMessage}` : ""}`;
  const fetchError = new FetchError(
    message,
    ctx.error ? { cause: ctx.error } : void 0
  );
  for (const key of ["request", "options", "response"]) {
    Object.defineProperty(fetchError, key, {
      get() {
        return ctx[key];
      }
    });
  }
  for (const [key, refKey] of [
    ["data", "_data"],
    ["status", "status"],
    ["statusCode", "status"],
    ["statusText", "statusText"],
    ["statusMessage", "statusText"]
  ]) {
    Object.defineProperty(fetchError, key, {
      get() {
        return ctx.response && ctx.response[refKey];
      }
    });
  }
  return fetchError;
}

const payloadMethods = new Set(
  Object.freeze(["PATCH", "POST", "PUT", "DELETE"])
);
function isPayloadMethod(method = "GET") {
  return payloadMethods.has(method.toUpperCase());
}
function isJSONSerializable(value) {
  if (value === void 0) {
    return false;
  }
  const t = typeof value;
  if (t === "string" || t === "number" || t === "boolean" || t === null) {
    return true;
  }
  if (t !== "object") {
    return false;
  }
  if (Array.isArray(value)) {
    return true;
  }
  if (value.buffer) {
    return false;
  }
  if (value instanceof FormData || value instanceof URLSearchParams) {
    return false;
  }
  return value.constructor && value.constructor.name === "Object" || typeof value.toJSON === "function";
}
const textTypes = /* @__PURE__ */ new Set([
  "image/svg",
  "application/xml",
  "application/xhtml",
  "application/html"
]);
const JSON_RE = /^application\/(?:[\w!#$%&*.^`~-]*\+)?json(;.+)?$/i;
function detectResponseType(_contentType = "") {
  if (!_contentType) {
    return "json";
  }
  const contentType = _contentType.split(";").shift() || "";
  if (JSON_RE.test(contentType)) {
    return "json";
  }
  if (contentType === "text/event-stream") {
    return "stream";
  }
  if (textTypes.has(contentType) || contentType.startsWith("text/")) {
    return "text";
  }
  return "blob";
}
function resolveFetchOptions(request, input, defaults, Headers) {
  const headers = mergeHeaders(
    input?.headers ?? request?.headers,
    defaults?.headers,
    Headers
  );
  let query;
  if (defaults?.query || defaults?.params || input?.params || input?.query) {
    query = {
      ...defaults?.params,
      ...defaults?.query,
      ...input?.params,
      ...input?.query
    };
  }
  return {
    ...defaults,
    ...input,
    query,
    params: query,
    headers
  };
}
function mergeHeaders(input, defaults, Headers) {
  if (!defaults) {
    return new Headers(input);
  }
  const headers = new Headers(defaults);
  if (input) {
    for (const [key, value] of Symbol.iterator in input || Array.isArray(input) ? input : new Headers(input)) {
      headers.set(key, value);
    }
  }
  return headers;
}
async function callHooks(context, hooks) {
  if (hooks) {
    if (Array.isArray(hooks)) {
      for (const hook of hooks) {
        await hook(context);
      }
    } else {
      await hooks(context);
    }
  }
}

const retryStatusCodes = /* @__PURE__ */ new Set([
  408,
  // Request Timeout
  409,
  // Conflict
  425,
  // Too Early (Experimental)
  429,
  // Too Many Requests
  500,
  // Internal Server Error
  502,
  // Bad Gateway
  503,
  // Service Unavailable
  504
  // Gateway Timeout
]);
const nullBodyResponses = /* @__PURE__ */ new Set([101, 204, 205, 304]);
function createFetch(globalOptions = {}) {
  const {
    fetch = globalThis.fetch,
    Headers = globalThis.Headers,
    AbortController = globalThis.AbortController
  } = globalOptions;
  async function onError(context) {
    const isAbort = context.error && context.error.name === "AbortError" && !context.options.timeout || false;
    if (context.options.retry !== false && !isAbort) {
      let retries;
      if (typeof context.options.retry === "number") {
        retries = context.options.retry;
      } else {
        retries = isPayloadMethod(context.options.method) ? 0 : 1;
      }
      const responseCode = context.response && context.response.status || 500;
      if (retries > 0 && (Array.isArray(context.options.retryStatusCodes) ? context.options.retryStatusCodes.includes(responseCode) : retryStatusCodes.has(responseCode))) {
        const retryDelay = typeof context.options.retryDelay === "function" ? context.options.retryDelay(context) : context.options.retryDelay || 0;
        if (retryDelay > 0) {
          await new Promise((resolve) => setTimeout(resolve, retryDelay));
        }
        return $fetchRaw(context.request, {
          ...context.options,
          retry: retries - 1
        });
      }
    }
    const error = createFetchError(context);
    if (Error.captureStackTrace) {
      Error.captureStackTrace(error, $fetchRaw);
    }
    throw error;
  }
  const $fetchRaw = async function $fetchRaw2(_request, _options = {}) {
    const context = {
      request: _request,
      options: resolveFetchOptions(
        _request,
        _options,
        globalOptions.defaults,
        Headers
      ),
      response: void 0,
      error: void 0
    };
    if (context.options.method) {
      context.options.method = context.options.method.toUpperCase();
    }
    if (context.options.onRequest) {
      await callHooks(context, context.options.onRequest);
      if (!(context.options.headers instanceof Headers)) {
        context.options.headers = new Headers(
          context.options.headers || {}
          /* compat */
        );
      }
    }
    if (typeof context.request === "string") {
      if (context.options.baseURL) {
        context.request = withBase(context.request, context.options.baseURL);
      }
      if (context.options.query) {
        context.request = withQuery(context.request, context.options.query);
        delete context.options.query;
      }
      if ("query" in context.options) {
        delete context.options.query;
      }
      if ("params" in context.options) {
        delete context.options.params;
      }
    }
    if (context.options.body && isPayloadMethod(context.options.method)) {
      if (isJSONSerializable(context.options.body)) {
        const contentType = context.options.headers.get("content-type");
        if (typeof context.options.body !== "string") {
          context.options.body = contentType === "application/x-www-form-urlencoded" ? new URLSearchParams(
            context.options.body
          ).toString() : JSON.stringify(context.options.body);
        }
        if (!contentType) {
          context.options.headers.set("content-type", "application/json");
        }
        if (!context.options.headers.has("accept")) {
          context.options.headers.set("accept", "application/json");
        }
      } else if (
        // ReadableStream Body
        "pipeTo" in context.options.body && typeof context.options.body.pipeTo === "function" || // Node.js Stream Body
        typeof context.options.body.pipe === "function"
      ) {
        if (!("duplex" in context.options)) {
          context.options.duplex = "half";
        }
      }
    }
    let abortTimeout;
    if (!context.options.signal && context.options.timeout) {
      const controller = new AbortController();
      abortTimeout = setTimeout(() => {
        const error = new Error(
          "[TimeoutError]: The operation was aborted due to timeout"
        );
        error.name = "TimeoutError";
        error.code = 23;
        controller.abort(error);
      }, context.options.timeout);
      context.options.signal = controller.signal;
    }
    try {
      context.response = await fetch(
        context.request,
        context.options
      );
    } catch (error) {
      context.error = error;
      if (context.options.onRequestError) {
        await callHooks(
          context,
          context.options.onRequestError
        );
      }
      return await onError(context);
    } finally {
      if (abortTimeout) {
        clearTimeout(abortTimeout);
      }
    }
    const hasBody = (context.response.body || // https://github.com/unjs/ofetch/issues/324
    // https://github.com/unjs/ofetch/issues/294
    // https://github.com/JakeChampion/fetch/issues/1454
    context.response._bodyInit) && !nullBodyResponses.has(context.response.status) && context.options.method !== "HEAD";
    if (hasBody) {
      const responseType = (context.options.parseResponse ? "json" : context.options.responseType) || detectResponseType(context.response.headers.get("content-type") || "");
      switch (responseType) {
        case "json": {
          const data = await context.response.text();
          const parseFunction = context.options.parseResponse || destr;
          context.response._data = parseFunction(data);
          break;
        }
        case "stream": {
          context.response._data = context.response.body || context.response._bodyInit;
          break;
        }
        default: {
          context.response._data = await context.response[responseType]();
        }
      }
    }
    if (context.options.onResponse) {
      await callHooks(
        context,
        context.options.onResponse
      );
    }
    if (!context.options.ignoreResponseError && context.response.status >= 400 && context.response.status < 600) {
      if (context.options.onResponseError) {
        await callHooks(
          context,
          context.options.onResponseError
        );
      }
      return await onError(context);
    }
    return context.response;
  };
  const $fetch = async function $fetch2(request, options) {
    const r = await $fetchRaw(request, options);
    return r._data;
  };
  $fetch.raw = $fetchRaw;
  $fetch.native = (...args) => fetch(...args);
  $fetch.create = (defaultOptions = {}, customGlobalOptions = {}) => createFetch({
    ...globalOptions,
    ...customGlobalOptions,
    defaults: {
      ...globalOptions.defaults,
      ...customGlobalOptions.defaults,
      ...defaultOptions
    }
  });
  return $fetch;
}

function createNodeFetch() {
  const useKeepAlive = JSON.parse(process.env.FETCH_KEEP_ALIVE || "false");
  if (!useKeepAlive) {
    return l;
  }
  const agentOptions = { keepAlive: true };
  const httpAgent = new http.Agent(agentOptions);
  const httpsAgent = new https.Agent(agentOptions);
  const nodeFetchOptions = {
    agent(parsedURL) {
      return parsedURL.protocol === "http:" ? httpAgent : httpsAgent;
    }
  };
  return function nodeFetchWithKeepAlive(input, init) {
    return l(input, { ...nodeFetchOptions, ...init });
  };
}
const fetch = globalThis.fetch ? (...args) => globalThis.fetch(...args) : createNodeFetch();
const Headers$1 = globalThis.Headers || s$1;
const AbortController = globalThis.AbortController || i;
const ofetch = createFetch({ fetch, Headers: Headers$1, AbortController });
const $fetch = ofetch;

function wrapToPromise(value) {
  if (!value || typeof value.then !== "function") {
    return Promise.resolve(value);
  }
  return value;
}
function asyncCall(function_, ...arguments_) {
  try {
    return wrapToPromise(function_(...arguments_));
  } catch (error) {
    return Promise.reject(error);
  }
}
function isPrimitive(value) {
  const type = typeof value;
  return value === null || type !== "object" && type !== "function";
}
function isPureObject(value) {
  const proto = Object.getPrototypeOf(value);
  return !proto || proto.isPrototypeOf(Object);
}
function stringify(value) {
  if (isPrimitive(value)) {
    return String(value);
  }
  if (isPureObject(value) || Array.isArray(value)) {
    return JSON.stringify(value);
  }
  if (typeof value.toJSON === "function") {
    return stringify(value.toJSON());
  }
  throw new Error("[unstorage] Cannot stringify value!");
}
const BASE64_PREFIX = "base64:";
function serializeRaw(value) {
  if (typeof value === "string") {
    return value;
  }
  return BASE64_PREFIX + base64Encode(value);
}
function deserializeRaw(value) {
  if (typeof value !== "string") {
    return value;
  }
  if (!value.startsWith(BASE64_PREFIX)) {
    return value;
  }
  return base64Decode(value.slice(BASE64_PREFIX.length));
}
function base64Decode(input) {
  if (globalThis.Buffer) {
    return Buffer.from(input, "base64");
  }
  return Uint8Array.from(
    globalThis.atob(input),
    (c) => c.codePointAt(0)
  );
}
function base64Encode(input) {
  if (globalThis.Buffer) {
    return Buffer.from(input).toString("base64");
  }
  return globalThis.btoa(String.fromCodePoint(...input));
}

const storageKeyProperties = [
  "has",
  "hasItem",
  "get",
  "getItem",
  "getItemRaw",
  "set",
  "setItem",
  "setItemRaw",
  "del",
  "remove",
  "removeItem",
  "getMeta",
  "setMeta",
  "removeMeta",
  "getKeys",
  "clear",
  "mount",
  "unmount"
];
function prefixStorage(storage, base) {
  base = normalizeBaseKey(base);
  if (!base) {
    return storage;
  }
  const nsStorage = { ...storage };
  for (const property of storageKeyProperties) {
    nsStorage[property] = (key = "", ...args) => (
      // @ts-ignore
      storage[property](base + key, ...args)
    );
  }
  nsStorage.getKeys = (key = "", ...arguments_) => storage.getKeys(base + key, ...arguments_).then((keys) => keys.map((key2) => key2.slice(base.length)));
  nsStorage.keys = nsStorage.getKeys;
  nsStorage.getItems = async (items, commonOptions) => {
    const prefixedItems = items.map(
      (item) => typeof item === "string" ? base + item : { ...item, key: base + item.key }
    );
    const results = await storage.getItems(prefixedItems, commonOptions);
    return results.map((entry) => ({
      key: entry.key.slice(base.length),
      value: entry.value
    }));
  };
  nsStorage.setItems = async (items, commonOptions) => {
    const prefixedItems = items.map((item) => ({
      key: base + item.key,
      value: item.value,
      options: item.options
    }));
    return storage.setItems(prefixedItems, commonOptions);
  };
  return nsStorage;
}
function normalizeKey$1(key) {
  if (!key) {
    return "";
  }
  return key.split("?")[0]?.replace(/[/\\]/g, ":").replace(/:+/g, ":").replace(/^:|:$/g, "") || "";
}
function joinKeys(...keys) {
  return normalizeKey$1(keys.join(":"));
}
function normalizeBaseKey(base) {
  base = normalizeKey$1(base);
  return base ? base + ":" : "";
}
function filterKeyByDepth(key, depth) {
  if (depth === void 0) {
    return true;
  }
  let substrCount = 0;
  let index = key.indexOf(":");
  while (index > -1) {
    substrCount++;
    index = key.indexOf(":", index + 1);
  }
  return substrCount <= depth;
}
function filterKeyByBase(key, base) {
  if (base) {
    return key.startsWith(base) && key[key.length - 1] !== "$";
  }
  return key[key.length - 1] !== "$";
}

function defineDriver$1(factory) {
  return factory;
}

const DRIVER_NAME$1 = "memory";
const memory = defineDriver$1(() => {
  const data = /* @__PURE__ */ new Map();
  return {
    name: DRIVER_NAME$1,
    getInstance: () => data,
    hasItem(key) {
      return data.has(key);
    },
    getItem(key) {
      return data.get(key) ?? null;
    },
    getItemRaw(key) {
      return data.get(key) ?? null;
    },
    setItem(key, value) {
      data.set(key, value);
    },
    setItemRaw(key, value) {
      data.set(key, value);
    },
    removeItem(key) {
      data.delete(key);
    },
    getKeys() {
      return [...data.keys()];
    },
    clear() {
      data.clear();
    },
    dispose() {
      data.clear();
    }
  };
});

function createStorage(options = {}) {
  const context = {
    mounts: { "": options.driver || memory() },
    mountpoints: [""],
    watching: false,
    watchListeners: [],
    unwatch: {}
  };
  const getMount = (key) => {
    for (const base of context.mountpoints) {
      if (key.startsWith(base)) {
        return {
          base,
          relativeKey: key.slice(base.length),
          driver: context.mounts[base]
        };
      }
    }
    return {
      base: "",
      relativeKey: key,
      driver: context.mounts[""]
    };
  };
  const getMounts = (base, includeParent) => {
    return context.mountpoints.filter(
      (mountpoint) => mountpoint.startsWith(base) || includeParent && base.startsWith(mountpoint)
    ).map((mountpoint) => ({
      relativeBase: base.length > mountpoint.length ? base.slice(mountpoint.length) : void 0,
      mountpoint,
      driver: context.mounts[mountpoint]
    }));
  };
  const onChange = (event, key) => {
    if (!context.watching) {
      return;
    }
    key = normalizeKey$1(key);
    for (const listener of context.watchListeners) {
      listener(event, key);
    }
  };
  const startWatch = async () => {
    if (context.watching) {
      return;
    }
    context.watching = true;
    for (const mountpoint in context.mounts) {
      context.unwatch[mountpoint] = await watch(
        context.mounts[mountpoint],
        onChange,
        mountpoint
      );
    }
  };
  const stopWatch = async () => {
    if (!context.watching) {
      return;
    }
    for (const mountpoint in context.unwatch) {
      await context.unwatch[mountpoint]();
    }
    context.unwatch = {};
    context.watching = false;
  };
  const runBatch = (items, commonOptions, cb) => {
    const batches = /* @__PURE__ */ new Map();
    const getBatch = (mount) => {
      let batch = batches.get(mount.base);
      if (!batch) {
        batch = {
          driver: mount.driver,
          base: mount.base,
          items: []
        };
        batches.set(mount.base, batch);
      }
      return batch;
    };
    for (const item of items) {
      const isStringItem = typeof item === "string";
      const key = normalizeKey$1(isStringItem ? item : item.key);
      const value = isStringItem ? void 0 : item.value;
      const options2 = isStringItem || !item.options ? commonOptions : { ...commonOptions, ...item.options };
      const mount = getMount(key);
      getBatch(mount).items.push({
        key,
        value,
        relativeKey: mount.relativeKey,
        options: options2
      });
    }
    return Promise.all([...batches.values()].map((batch) => cb(batch))).then(
      (r) => r.flat()
    );
  };
  const storage = {
    // Item
    hasItem(key, opts = {}) {
      key = normalizeKey$1(key);
      const { relativeKey, driver } = getMount(key);
      return asyncCall(driver.hasItem, relativeKey, opts);
    },
    getItem(key, opts = {}) {
      key = normalizeKey$1(key);
      const { relativeKey, driver } = getMount(key);
      return asyncCall(driver.getItem, relativeKey, opts).then(
        (value) => destr(value)
      );
    },
    getItems(items, commonOptions = {}) {
      return runBatch(items, commonOptions, (batch) => {
        if (batch.driver.getItems) {
          return asyncCall(
            batch.driver.getItems,
            batch.items.map((item) => ({
              key: item.relativeKey,
              options: item.options
            })),
            commonOptions
          ).then(
            (r) => r.map((item) => ({
              key: joinKeys(batch.base, item.key),
              value: destr(item.value)
            }))
          );
        }
        return Promise.all(
          batch.items.map((item) => {
            return asyncCall(
              batch.driver.getItem,
              item.relativeKey,
              item.options
            ).then((value) => ({
              key: item.key,
              value: destr(value)
            }));
          })
        );
      });
    },
    getItemRaw(key, opts = {}) {
      key = normalizeKey$1(key);
      const { relativeKey, driver } = getMount(key);
      if (driver.getItemRaw) {
        return asyncCall(driver.getItemRaw, relativeKey, opts);
      }
      return asyncCall(driver.getItem, relativeKey, opts).then(
        (value) => deserializeRaw(value)
      );
    },
    async setItem(key, value, opts = {}) {
      if (value === void 0) {
        return storage.removeItem(key);
      }
      key = normalizeKey$1(key);
      const { relativeKey, driver } = getMount(key);
      if (!driver.setItem) {
        return;
      }
      await asyncCall(driver.setItem, relativeKey, stringify(value), opts);
      if (!driver.watch) {
        onChange("update", key);
      }
    },
    async setItems(items, commonOptions) {
      await runBatch(items, commonOptions, async (batch) => {
        if (batch.driver.setItems) {
          return asyncCall(
            batch.driver.setItems,
            batch.items.map((item) => ({
              key: item.relativeKey,
              value: stringify(item.value),
              options: item.options
            })),
            commonOptions
          );
        }
        if (!batch.driver.setItem) {
          return;
        }
        await Promise.all(
          batch.items.map((item) => {
            return asyncCall(
              batch.driver.setItem,
              item.relativeKey,
              stringify(item.value),
              item.options
            );
          })
        );
      });
    },
    async setItemRaw(key, value, opts = {}) {
      if (value === void 0) {
        return storage.removeItem(key, opts);
      }
      key = normalizeKey$1(key);
      const { relativeKey, driver } = getMount(key);
      if (driver.setItemRaw) {
        await asyncCall(driver.setItemRaw, relativeKey, value, opts);
      } else if (driver.setItem) {
        await asyncCall(driver.setItem, relativeKey, serializeRaw(value), opts);
      } else {
        return;
      }
      if (!driver.watch) {
        onChange("update", key);
      }
    },
    async removeItem(key, opts = {}) {
      if (typeof opts === "boolean") {
        opts = { removeMeta: opts };
      }
      key = normalizeKey$1(key);
      const { relativeKey, driver } = getMount(key);
      if (!driver.removeItem) {
        return;
      }
      await asyncCall(driver.removeItem, relativeKey, opts);
      if (opts.removeMeta || opts.removeMata) {
        await asyncCall(driver.removeItem, relativeKey + "$", opts);
      }
      if (!driver.watch) {
        onChange("remove", key);
      }
    },
    // Meta
    async getMeta(key, opts = {}) {
      if (typeof opts === "boolean") {
        opts = { nativeOnly: opts };
      }
      key = normalizeKey$1(key);
      const { relativeKey, driver } = getMount(key);
      const meta = /* @__PURE__ */ Object.create(null);
      if (driver.getMeta) {
        Object.assign(meta, await asyncCall(driver.getMeta, relativeKey, opts));
      }
      if (!opts.nativeOnly) {
        const value = await asyncCall(
          driver.getItem,
          relativeKey + "$",
          opts
        ).then((value_) => destr(value_));
        if (value && typeof value === "object") {
          if (typeof value.atime === "string") {
            value.atime = new Date(value.atime);
          }
          if (typeof value.mtime === "string") {
            value.mtime = new Date(value.mtime);
          }
          Object.assign(meta, value);
        }
      }
      return meta;
    },
    setMeta(key, value, opts = {}) {
      return this.setItem(key + "$", value, opts);
    },
    removeMeta(key, opts = {}) {
      return this.removeItem(key + "$", opts);
    },
    // Keys
    async getKeys(base, opts = {}) {
      base = normalizeBaseKey(base);
      const mounts = getMounts(base, true);
      let maskedMounts = [];
      const allKeys = [];
      let allMountsSupportMaxDepth = true;
      for (const mount of mounts) {
        if (!mount.driver.flags?.maxDepth) {
          allMountsSupportMaxDepth = false;
        }
        const rawKeys = await asyncCall(
          mount.driver.getKeys,
          mount.relativeBase,
          opts
        );
        for (const key of rawKeys) {
          const fullKey = mount.mountpoint + normalizeKey$1(key);
          if (!maskedMounts.some((p) => fullKey.startsWith(p))) {
            allKeys.push(fullKey);
          }
        }
        maskedMounts = [
          mount.mountpoint,
          ...maskedMounts.filter((p) => !p.startsWith(mount.mountpoint))
        ];
      }
      const shouldFilterByDepth = opts.maxDepth !== void 0 && !allMountsSupportMaxDepth;
      return allKeys.filter(
        (key) => (!shouldFilterByDepth || filterKeyByDepth(key, opts.maxDepth)) && filterKeyByBase(key, base)
      );
    },
    // Utils
    async clear(base, opts = {}) {
      base = normalizeBaseKey(base);
      await Promise.all(
        getMounts(base, false).map(async (m) => {
          if (m.driver.clear) {
            return asyncCall(m.driver.clear, m.relativeBase, opts);
          }
          if (m.driver.removeItem) {
            const keys = await m.driver.getKeys(m.relativeBase || "", opts);
            return Promise.all(
              keys.map((key) => m.driver.removeItem(key, opts))
            );
          }
        })
      );
    },
    async dispose() {
      await Promise.all(
        Object.values(context.mounts).map((driver) => dispose(driver))
      );
    },
    async watch(callback) {
      await startWatch();
      context.watchListeners.push(callback);
      return async () => {
        context.watchListeners = context.watchListeners.filter(
          (listener) => listener !== callback
        );
        if (context.watchListeners.length === 0) {
          await stopWatch();
        }
      };
    },
    async unwatch() {
      context.watchListeners = [];
      await stopWatch();
    },
    // Mount
    mount(base, driver) {
      base = normalizeBaseKey(base);
      if (base && context.mounts[base]) {
        throw new Error(`already mounted at ${base}`);
      }
      if (base) {
        context.mountpoints.push(base);
        context.mountpoints.sort((a, b) => b.length - a.length);
      }
      context.mounts[base] = driver;
      if (context.watching) {
        Promise.resolve(watch(driver, onChange, base)).then((unwatcher) => {
          context.unwatch[base] = unwatcher;
        }).catch(console.error);
      }
      return storage;
    },
    async unmount(base, _dispose = true) {
      base = normalizeBaseKey(base);
      if (!base || !context.mounts[base]) {
        return;
      }
      if (context.watching && base in context.unwatch) {
        context.unwatch[base]?.();
        delete context.unwatch[base];
      }
      if (_dispose) {
        await dispose(context.mounts[base]);
      }
      context.mountpoints = context.mountpoints.filter((key) => key !== base);
      delete context.mounts[base];
    },
    getMount(key = "") {
      key = normalizeKey$1(key) + ":";
      const m = getMount(key);
      return {
        driver: m.driver,
        base: m.base
      };
    },
    getMounts(base = "", opts = {}) {
      base = normalizeKey$1(base);
      const mounts = getMounts(base, opts.parents);
      return mounts.map((m) => ({
        driver: m.driver,
        base: m.mountpoint
      }));
    },
    // Aliases
    keys: (base, opts = {}) => storage.getKeys(base, opts),
    get: (key, opts = {}) => storage.getItem(key, opts),
    set: (key, value, opts = {}) => storage.setItem(key, value, opts),
    has: (key, opts = {}) => storage.hasItem(key, opts),
    del: (key, opts = {}) => storage.removeItem(key, opts),
    remove: (key, opts = {}) => storage.removeItem(key, opts)
  };
  return storage;
}
function watch(driver, onChange, base) {
  return driver.watch ? driver.watch((event, key) => onChange(event, base + key)) : () => {
  };
}
async function dispose(driver) {
  if (typeof driver.dispose === "function") {
    await asyncCall(driver.dispose);
  }
}

const _assets = {

};

const normalizeKey = function normalizeKey(key) {
  if (!key) {
    return "";
  }
  return key.split("?")[0]?.replace(/[/\\]/g, ":").replace(/:+/g, ":").replace(/^:|:$/g, "") || "";
};

const assets$1 = {
  getKeys() {
    return Promise.resolve(Object.keys(_assets))
  },
  hasItem (id) {
    id = normalizeKey(id);
    return Promise.resolve(id in _assets)
  },
  getItem (id) {
    id = normalizeKey(id);
    return Promise.resolve(_assets[id] ? _assets[id].import() : null)
  },
  getMeta (id) {
    id = normalizeKey(id);
    return Promise.resolve(_assets[id] ? _assets[id].meta : {})
  }
};

function defineDriver(factory) {
  return factory;
}
function createError(driver, message, opts) {
  const err = new Error(`[unstorage] [${driver}] ${message}`, opts);
  if (Error.captureStackTrace) {
    Error.captureStackTrace(err, createError);
  }
  return err;
}
function createRequiredError(driver, name) {
  if (Array.isArray(name)) {
    return createError(
      driver,
      `Missing some of the required options ${name.map((n) => "`" + n + "`").join(", ")}`
    );
  }
  return createError(driver, `Missing required option \`${name}\`.`);
}

function ignoreNotfound(err) {
  return err.code === "ENOENT" || err.code === "EISDIR" ? null : err;
}
function ignoreExists(err) {
  return err.code === "EEXIST" ? null : err;
}
async function writeFile(path, data, encoding) {
  await ensuredir(dirname$1(path));
  return promises.writeFile(path, data, encoding);
}
function readFile(path, encoding) {
  return promises.readFile(path, encoding).catch(ignoreNotfound);
}
function unlink(path) {
  return promises.unlink(path).catch(ignoreNotfound);
}
function readdir(dir) {
  return promises.readdir(dir, { withFileTypes: true }).catch(ignoreNotfound).then((r) => r || []);
}
async function ensuredir(dir) {
  if (existsSync(dir)) {
    return;
  }
  await ensuredir(dirname$1(dir)).catch(ignoreExists);
  await promises.mkdir(dir).catch(ignoreExists);
}
async function readdirRecursive(dir, ignore, maxDepth) {
  if (ignore && ignore(dir)) {
    return [];
  }
  const entries = await readdir(dir);
  const files = [];
  await Promise.all(
    entries.map(async (entry) => {
      const entryPath = resolve$1(dir, entry.name);
      if (entry.isDirectory()) {
        if (maxDepth === void 0 || maxDepth > 0) {
          const dirFiles = await readdirRecursive(
            entryPath,
            ignore,
            maxDepth === void 0 ? void 0 : maxDepth - 1
          );
          files.push(...dirFiles.map((f) => entry.name + "/" + f));
        }
      } else {
        if (!(ignore && ignore(entry.name))) {
          files.push(entry.name);
        }
      }
    })
  );
  return files;
}
async function rmRecursive(dir) {
  const entries = await readdir(dir);
  await Promise.all(
    entries.map((entry) => {
      const entryPath = resolve$1(dir, entry.name);
      if (entry.isDirectory()) {
        return rmRecursive(entryPath).then(() => promises.rmdir(entryPath));
      } else {
        return promises.unlink(entryPath);
      }
    })
  );
}

const PATH_TRAVERSE_RE = /\.\.:|\.\.$/;
const DRIVER_NAME = "fs-lite";
const unstorage_47drivers_47fs_45lite = defineDriver((opts = {}) => {
  if (!opts.base) {
    throw createRequiredError(DRIVER_NAME, "base");
  }
  opts.base = resolve$1(opts.base);
  const r = (key) => {
    if (PATH_TRAVERSE_RE.test(key)) {
      throw createError(
        DRIVER_NAME,
        `Invalid key: ${JSON.stringify(key)}. It should not contain .. segments`
      );
    }
    const resolved = join(opts.base, key.replace(/:/g, "/"));
    return resolved;
  };
  return {
    name: DRIVER_NAME,
    options: opts,
    flags: {
      maxDepth: true
    },
    hasItem(key) {
      return existsSync(r(key));
    },
    getItem(key) {
      return readFile(r(key), "utf8");
    },
    getItemRaw(key) {
      return readFile(r(key));
    },
    async getMeta(key) {
      const { atime, mtime, size, birthtime, ctime } = await promises.stat(r(key)).catch(() => ({}));
      return { atime, mtime, size, birthtime, ctime };
    },
    setItem(key, value) {
      if (opts.readOnly) {
        return;
      }
      return writeFile(r(key), value, "utf8");
    },
    setItemRaw(key, value) {
      if (opts.readOnly) {
        return;
      }
      return writeFile(r(key), value);
    },
    removeItem(key) {
      if (opts.readOnly) {
        return;
      }
      return unlink(r(key));
    },
    getKeys(_base, topts) {
      return readdirRecursive(r("."), opts.ignore, topts?.maxDepth);
    },
    async clear() {
      if (opts.readOnly || opts.noClear) {
        return;
      }
      await rmRecursive(r("."));
    }
  };
});

const storage = createStorage({});

storage.mount('/assets', assets$1);

storage.mount('data', unstorage_47drivers_47fs_45lite({"driver":"fsLite","base":"./.data/kv"}));

function useStorage(base = "") {
  return base ? prefixStorage(storage, base) : storage;
}

function serialize$1(o){return typeof o=="string"?`'${o}'`:new c().serialize(o)}const c=/*@__PURE__*/function(){class o{#t=new Map;compare(t,r){const e=typeof t,n=typeof r;return e==="string"&&n==="string"?t.localeCompare(r):e==="number"&&n==="number"?t-r:String.prototype.localeCompare.call(this.serialize(t,true),this.serialize(r,true))}serialize(t,r){if(t===null)return "null";switch(typeof t){case "string":return r?t:`'${t}'`;case "bigint":return `${t}n`;case "object":return this.$object(t);case "function":return this.$function(t)}return String(t)}serializeObject(t){const r=Object.prototype.toString.call(t);if(r!=="[object Object]")return this.serializeBuiltInType(r.length<10?`unknown:${r}`:r.slice(8,-1),t);const e=t.constructor,n=e===Object||e===void 0?"":e.name;if(n!==""&&globalThis[n]===e)return this.serializeBuiltInType(n,t);if(typeof t.toJSON=="function"){const i=t.toJSON();return n+(i!==null&&typeof i=="object"?this.$object(i):`(${this.serialize(i)})`)}return this.serializeObjectEntries(n,Object.entries(t))}serializeBuiltInType(t,r){const e=this["$"+t];if(e)return e.call(this,r);if(typeof r?.entries=="function")return this.serializeObjectEntries(t,r.entries());throw new Error(`Cannot serialize ${t}`)}serializeObjectEntries(t,r){const e=Array.from(r).sort((i,a)=>this.compare(i[0],a[0]));let n=`${t}{`;for(let i=0;i<e.length;i++){const[a,l]=e[i];n+=`${this.serialize(a,true)}:${this.serialize(l)}`,i<e.length-1&&(n+=",");}return n+"}"}$object(t){let r=this.#t.get(t);return r===void 0&&(this.#t.set(t,`#${this.#t.size}`),r=this.serializeObject(t),this.#t.set(t,r)),r}$function(t){const r=Function.prototype.toString.call(t);return r.slice(-15)==="[native code] }"?`${t.name||""}()[native]`:`${t.name}(${t.length})${r.replace(/\s*\n\s*/g,"")}`}$Array(t){let r="[";for(let e=0;e<t.length;e++)r+=this.serialize(t[e]),e<t.length-1&&(r+=",");return r+"]"}$Date(t){try{return `Date(${t.toISOString()})`}catch{return "Date(null)"}}$ArrayBuffer(t){return `ArrayBuffer[${new Uint8Array(t).join(",")}]`}$Set(t){return `Set${this.$Array(Array.from(t).sort((r,e)=>this.compare(r,e)))}`}$Map(t){return this.serializeObjectEntries("Map",t.entries())}}for(const s of ["Error","RegExp","URL"])o.prototype["$"+s]=function(t){return `${s}(${t})`};for(const s of ["Int8Array","Uint8Array","Uint8ClampedArray","Int16Array","Uint16Array","Int32Array","Uint32Array","Float32Array","Float64Array"])o.prototype["$"+s]=function(t){return `${s}[${t.join(",")}]`};for(const s of ["BigInt64Array","BigUint64Array"])o.prototype["$"+s]=function(t){return `${s}[${t.join("n,")}${t.length>0?"n":""}]`};return o}();

function isEqual(object1, object2) {
  if (object1 === object2) {
    return true;
  }
  if (serialize$1(object1) === serialize$1(object2)) {
    return true;
  }
  return false;
}

const e=globalThis.process?.getBuiltinModule?.("crypto")?.hash,r="sha256",s="base64url";function digest(t){if(e)return e(r,t,s);const o=createHash(r).update(t);return globalThis.process?.versions?.webcontainer?o.digest().toString(s):o.digest(s)}

const Hasher = /* @__PURE__ */ (() => {
  class Hasher2 {
    buff = "";
    #context = /* @__PURE__ */ new Map();
    write(str) {
      this.buff += str;
    }
    dispatch(value) {
      const type = value === null ? "null" : typeof value;
      return this[type](value);
    }
    object(object) {
      if (object && typeof object.toJSON === "function") {
        return this.object(object.toJSON());
      }
      const objString = Object.prototype.toString.call(object);
      let objType = "";
      const objectLength = objString.length;
      objType = objectLength < 10 ? "unknown:[" + objString + "]" : objString.slice(8, objectLength - 1);
      objType = objType.toLowerCase();
      let objectNumber = null;
      if ((objectNumber = this.#context.get(object)) === void 0) {
        this.#context.set(object, this.#context.size);
      } else {
        return this.dispatch("[CIRCULAR:" + objectNumber + "]");
      }
      if (typeof Buffer !== "undefined" && Buffer.isBuffer && Buffer.isBuffer(object)) {
        this.write("buffer:");
        return this.write(object.toString("utf8"));
      }
      if (objType !== "object" && objType !== "function" && objType !== "asyncfunction") {
        if (this[objType]) {
          this[objType](object);
        } else {
          this.unknown(object, objType);
        }
      } else {
        const keys = Object.keys(object).sort();
        const extraKeys = [];
        this.write("object:" + (keys.length + extraKeys.length) + ":");
        const dispatchForKey = (key) => {
          this.dispatch(key);
          this.write(":");
          this.dispatch(object[key]);
          this.write(",");
        };
        for (const key of keys) {
          dispatchForKey(key);
        }
        for (const key of extraKeys) {
          dispatchForKey(key);
        }
      }
    }
    array(arr, unordered) {
      unordered = unordered === void 0 ? false : unordered;
      this.write("array:" + arr.length + ":");
      if (!unordered || arr.length <= 1) {
        for (const entry of arr) {
          this.dispatch(entry);
        }
        return;
      }
      const contextAdditions = /* @__PURE__ */ new Map();
      const entries = arr.map((entry) => {
        const hasher = new Hasher2();
        hasher.dispatch(entry);
        for (const [key, value] of hasher.#context) {
          contextAdditions.set(key, value);
        }
        return hasher.toString();
      });
      this.#context = contextAdditions;
      entries.sort();
      return this.array(entries, false);
    }
    date(date) {
      return this.write("date:" + date.toJSON());
    }
    symbol(sym) {
      return this.write("symbol:" + sym.toString());
    }
    unknown(value, type) {
      this.write(type);
      if (!value) {
        return;
      }
      this.write(":");
      if (value && typeof value.entries === "function") {
        return this.array(
          [...value.entries()],
          true
          /* ordered */
        );
      }
    }
    error(err) {
      return this.write("error:" + err.toString());
    }
    boolean(bool) {
      return this.write("bool:" + bool);
    }
    string(string) {
      this.write("string:" + string.length + ":");
      this.write(string);
    }
    function(fn) {
      this.write("fn:");
      if (isNativeFunction(fn)) {
        this.dispatch("[native]");
      } else {
        this.dispatch(fn.toString());
      }
    }
    number(number) {
      return this.write("number:" + number);
    }
    null() {
      return this.write("Null");
    }
    undefined() {
      return this.write("Undefined");
    }
    regexp(regex) {
      return this.write("regex:" + regex.toString());
    }
    arraybuffer(arr) {
      this.write("arraybuffer:");
      return this.dispatch(new Uint8Array(arr));
    }
    url(url) {
      return this.write("url:" + url.toString());
    }
    map(map) {
      this.write("map:");
      const arr = [...map];
      return this.array(arr, false);
    }
    set(set) {
      this.write("set:");
      const arr = [...set];
      return this.array(arr, false);
    }
    bigint(number) {
      return this.write("bigint:" + number.toString());
    }
  }
  for (const type of [
    "uint8array",
    "uint8clampedarray",
    "unt8array",
    "uint16array",
    "unt16array",
    "uint32array",
    "unt32array",
    "float32array",
    "float64array"
  ]) {
    Hasher2.prototype[type] = function(arr) {
      this.write(type + ":");
      return this.array([...arr], false);
    };
  }
  function isNativeFunction(f) {
    if (typeof f !== "function") {
      return false;
    }
    return Function.prototype.toString.call(f).slice(
      -15
      /* "[native code] }".length */
    ) === "[native code] }";
  }
  return Hasher2;
})();
function serialize(object) {
  const hasher = new Hasher();
  hasher.dispatch(object);
  return hasher.buff;
}
function hash(value) {
  return digest(typeof value === "string" ? value : serialize(value)).replace(/[-_]/g, "").slice(0, 10);
}

function defaultCacheOptions() {
  return {
    name: "_",
    base: "/cache",
    swr: true,
    maxAge: 1
  };
}
function defineCachedFunction(fn, opts = {}) {
  opts = { ...defaultCacheOptions(), ...opts };
  const pending = {};
  const group = opts.group || "nitro/functions";
  const name = opts.name || fn.name || "_";
  const integrity = opts.integrity || hash([fn, opts]);
  const validate = opts.validate || ((entry) => entry.value !== void 0);
  async function get(key, resolver, shouldInvalidateCache, event) {
    const cacheKey = [opts.base, group, name, key + ".json"].filter(Boolean).join(":").replace(/:\/$/, ":index");
    let entry = await useStorage().getItem(cacheKey).catch((error) => {
      console.error(`[cache] Cache read error.`, error);
      useNitroApp().captureError(error, { event, tags: ["cache"] });
    }) || {};
    if (typeof entry !== "object") {
      entry = {};
      const error = new Error("Malformed data read from cache.");
      console.error("[cache]", error);
      useNitroApp().captureError(error, { event, tags: ["cache"] });
    }
    const ttl = (opts.maxAge ?? 0) * 1e3;
    if (ttl) {
      entry.expires = Date.now() + ttl;
    }
    const expired = shouldInvalidateCache || entry.integrity !== integrity || ttl && Date.now() - (entry.mtime || 0) > ttl || validate(entry) === false;
    const _resolve = async () => {
      const isPending = pending[key];
      if (!isPending) {
        if (entry.value !== void 0 && (opts.staleMaxAge || 0) >= 0 && opts.swr === false) {
          entry.value = void 0;
          entry.integrity = void 0;
          entry.mtime = void 0;
          entry.expires = void 0;
        }
        pending[key] = Promise.resolve(resolver());
      }
      try {
        entry.value = await pending[key];
      } catch (error) {
        if (!isPending) {
          delete pending[key];
        }
        throw error;
      }
      if (!isPending) {
        entry.mtime = Date.now();
        entry.integrity = integrity;
        delete pending[key];
        if (validate(entry) !== false) {
          let setOpts;
          if (opts.maxAge && !opts.swr) {
            setOpts = { ttl: opts.maxAge };
          }
          const promise = useStorage().setItem(cacheKey, entry, setOpts).catch((error) => {
            console.error(`[cache] Cache write error.`, error);
            useNitroApp().captureError(error, { event, tags: ["cache"] });
          });
          if (event?.waitUntil) {
            event.waitUntil(promise);
          }
        }
      }
    };
    const _resolvePromise = expired ? _resolve() : Promise.resolve();
    if (entry.value === void 0) {
      await _resolvePromise;
    } else if (expired && event && event.waitUntil) {
      event.waitUntil(_resolvePromise);
    }
    if (opts.swr && validate(entry) !== false) {
      _resolvePromise.catch((error) => {
        console.error(`[cache] SWR handler error.`, error);
        useNitroApp().captureError(error, { event, tags: ["cache"] });
      });
      return entry;
    }
    return _resolvePromise.then(() => entry);
  }
  return async (...args) => {
    const shouldBypassCache = await opts.shouldBypassCache?.(...args);
    if (shouldBypassCache) {
      return fn(...args);
    }
    const key = await (opts.getKey || getKey)(...args);
    const shouldInvalidateCache = await opts.shouldInvalidateCache?.(...args);
    const entry = await get(
      key,
      () => fn(...args),
      shouldInvalidateCache,
      args[0] && isEvent(args[0]) ? args[0] : void 0
    );
    let value = entry.value;
    if (opts.transform) {
      value = await opts.transform(entry, ...args) || value;
    }
    return value;
  };
}
function cachedFunction(fn, opts = {}) {
  return defineCachedFunction(fn, opts);
}
function getKey(...args) {
  return args.length > 0 ? hash(args) : "";
}
function escapeKey(key) {
  return String(key).replace(/\W/g, "");
}
function defineCachedEventHandler(handler, opts = defaultCacheOptions()) {
  const variableHeaderNames = (opts.varies || []).filter(Boolean).map((h) => h.toLowerCase()).sort();
  const _opts = {
    ...opts,
    getKey: async (event) => {
      const customKey = await opts.getKey?.(event);
      if (customKey) {
        return escapeKey(customKey);
      }
      const _path = event.node.req.originalUrl || event.node.req.url || event.path;
      let _pathname;
      try {
        _pathname = escapeKey(decodeURI(parseURL(_path).pathname)).slice(0, 16) || "index";
      } catch {
        _pathname = "-";
      }
      const _hashedPath = `${_pathname}.${hash(_path)}`;
      const _headers = variableHeaderNames.map((header) => [header, event.node.req.headers[header]]).map(([name, value]) => `${escapeKey(name)}.${hash(value)}`);
      return [_hashedPath, ..._headers].join(":");
    },
    validate: (entry) => {
      if (!entry.value) {
        return false;
      }
      if (entry.value.code >= 400) {
        return false;
      }
      if (entry.value.body === void 0) {
        return false;
      }
      if (entry.value.headers.etag === "undefined" || entry.value.headers["last-modified"] === "undefined") {
        return false;
      }
      return true;
    },
    group: opts.group || "nitro/handlers",
    integrity: opts.integrity || hash([handler, opts])
  };
  const _cachedHandler = cachedFunction(
    async (incomingEvent) => {
      const variableHeaders = {};
      for (const header of variableHeaderNames) {
        const value = incomingEvent.node.req.headers[header];
        if (value !== void 0) {
          variableHeaders[header] = value;
        }
      }
      const reqProxy = cloneWithProxy(incomingEvent.node.req, {
        headers: variableHeaders
      });
      const resHeaders = {};
      let _resSendBody;
      const resProxy = cloneWithProxy(incomingEvent.node.res, {
        statusCode: 200,
        writableEnded: false,
        writableFinished: false,
        headersSent: false,
        closed: false,
        getHeader(name) {
          return resHeaders[name];
        },
        setHeader(name, value) {
          resHeaders[name] = value;
          return this;
        },
        getHeaderNames() {
          return Object.keys(resHeaders);
        },
        hasHeader(name) {
          return name in resHeaders;
        },
        removeHeader(name) {
          delete resHeaders[name];
        },
        getHeaders() {
          return resHeaders;
        },
        end(chunk, arg2, arg3) {
          if (typeof chunk === "string") {
            _resSendBody = chunk;
          }
          if (typeof arg2 === "function") {
            arg2();
          }
          if (typeof arg3 === "function") {
            arg3();
          }
          return this;
        },
        write(chunk, arg2, arg3) {
          if (typeof chunk === "string") {
            _resSendBody = chunk;
          }
          if (typeof arg2 === "function") {
            arg2(void 0);
          }
          if (typeof arg3 === "function") {
            arg3();
          }
          return true;
        },
        writeHead(statusCode, headers2) {
          this.statusCode = statusCode;
          if (headers2) {
            if (Array.isArray(headers2) || typeof headers2 === "string") {
              throw new TypeError("Raw headers  is not supported.");
            }
            for (const header in headers2) {
              const value = headers2[header];
              if (value !== void 0) {
                this.setHeader(
                  header,
                  value
                );
              }
            }
          }
          return this;
        }
      });
      const event = createEvent(reqProxy, resProxy);
      event.fetch = (url, fetchOptions) => fetchWithEvent(event, url, fetchOptions, {
        fetch: useNitroApp().localFetch
      });
      event.$fetch = (url, fetchOptions) => fetchWithEvent(event, url, fetchOptions, {
        fetch: globalThis.$fetch
      });
      event.waitUntil = incomingEvent.waitUntil;
      event.context = incomingEvent.context;
      event.context.cache = {
        options: _opts
      };
      const body = await handler(event) || _resSendBody;
      const headers = event.node.res.getHeaders();
      headers.etag = String(
        headers.Etag || headers.etag || `W/"${hash(body)}"`
      );
      headers["last-modified"] = String(
        headers["Last-Modified"] || headers["last-modified"] || (/* @__PURE__ */ new Date()).toUTCString()
      );
      const cacheControl = [];
      if (opts.swr) {
        if (opts.maxAge) {
          cacheControl.push(`s-maxage=${opts.maxAge}`);
        }
        if (opts.staleMaxAge) {
          cacheControl.push(`stale-while-revalidate=${opts.staleMaxAge}`);
        } else {
          cacheControl.push("stale-while-revalidate");
        }
      } else if (opts.maxAge) {
        cacheControl.push(`max-age=${opts.maxAge}`);
      }
      if (cacheControl.length > 0) {
        headers["cache-control"] = cacheControl.join(", ");
      }
      const cacheEntry = {
        code: event.node.res.statusCode,
        headers,
        body
      };
      return cacheEntry;
    },
    _opts
  );
  return defineEventHandler(async (event) => {
    if (opts.headersOnly) {
      if (handleCacheHeaders(event, { maxAge: opts.maxAge })) {
        return;
      }
      return handler(event);
    }
    const response = await _cachedHandler(
      event
    );
    if (event.node.res.headersSent || event.node.res.writableEnded) {
      return response.body;
    }
    if (handleCacheHeaders(event, {
      modifiedTime: new Date(response.headers["last-modified"]),
      etag: response.headers.etag,
      maxAge: opts.maxAge
    })) {
      return;
    }
    event.node.res.statusCode = response.code;
    for (const name in response.headers) {
      const value = response.headers[name];
      if (name === "set-cookie") {
        event.node.res.appendHeader(
          name,
          splitCookiesString(value)
        );
      } else {
        if (value !== void 0) {
          event.node.res.setHeader(name, value);
        }
      }
    }
    return response.body;
  });
}
function cloneWithProxy(obj, overrides) {
  return new Proxy(obj, {
    get(target, property, receiver) {
      if (property in overrides) {
        return overrides[property];
      }
      return Reflect.get(target, property, receiver);
    },
    set(target, property, value, receiver) {
      if (property in overrides) {
        overrides[property] = value;
        return true;
      }
      return Reflect.set(target, property, value, receiver);
    }
  });
}
const cachedEventHandler = defineCachedEventHandler;

function klona(x) {
	if (typeof x !== 'object') return x;

	var k, tmp, str=Object.prototype.toString.call(x);

	if (str === '[object Object]') {
		if (x.constructor !== Object && typeof x.constructor === 'function') {
			tmp = new x.constructor();
			for (k in x) {
				if (x.hasOwnProperty(k) && tmp[k] !== x[k]) {
					tmp[k] = klona(x[k]);
				}
			}
		} else {
			tmp = {}; // null
			for (k in x) {
				if (k === '__proto__') {
					Object.defineProperty(tmp, k, {
						value: klona(x[k]),
						configurable: true,
						enumerable: true,
						writable: true,
					});
				} else {
					tmp[k] = klona(x[k]);
				}
			}
		}
		return tmp;
	}

	if (str === '[object Array]') {
		k = x.length;
		for (tmp=Array(k); k--;) {
			tmp[k] = klona(x[k]);
		}
		return tmp;
	}

	if (str === '[object Set]') {
		tmp = new Set;
		x.forEach(function (val) {
			tmp.add(klona(val));
		});
		return tmp;
	}

	if (str === '[object Map]') {
		tmp = new Map;
		x.forEach(function (val, key) {
			tmp.set(klona(key), klona(val));
		});
		return tmp;
	}

	if (str === '[object Date]') {
		return new Date(+x);
	}

	if (str === '[object RegExp]') {
		tmp = new RegExp(x.source, x.flags);
		tmp.lastIndex = x.lastIndex;
		return tmp;
	}

	if (str === '[object DataView]') {
		return new x.constructor( klona(x.buffer) );
	}

	if (str === '[object ArrayBuffer]') {
		return x.slice(0);
	}

	// ArrayBuffer.isView(x)
	// ~> `new` bcuz `Buffer.slice` => ref
	if (str.slice(-6) === 'Array]') {
		return new x.constructor(x);
	}

	return x;
}

const inlineAppConfig = {
  "nuxt": {}
};



const appConfig = defuFn(inlineAppConfig);

const NUMBER_CHAR_RE = /\d/;
const STR_SPLITTERS = ["-", "_", "/", "."];
function isUppercase(char = "") {
  if (NUMBER_CHAR_RE.test(char)) {
    return void 0;
  }
  return char !== char.toLowerCase();
}
function splitByCase(str, separators) {
  const splitters = STR_SPLITTERS;
  const parts = [];
  if (!str || typeof str !== "string") {
    return parts;
  }
  let buff = "";
  let previousUpper;
  let previousSplitter;
  for (const char of str) {
    const isSplitter = splitters.includes(char);
    if (isSplitter === true) {
      parts.push(buff);
      buff = "";
      previousUpper = void 0;
      continue;
    }
    const isUpper = isUppercase(char);
    if (previousSplitter === false) {
      if (previousUpper === false && isUpper === true) {
        parts.push(buff);
        buff = char;
        previousUpper = isUpper;
        continue;
      }
      if (previousUpper === true && isUpper === false && buff.length > 1) {
        const lastChar = buff.at(-1);
        parts.push(buff.slice(0, Math.max(0, buff.length - 1)));
        buff = lastChar + char;
        previousUpper = isUpper;
        continue;
      }
    }
    buff += char;
    previousUpper = isUpper;
    previousSplitter = isSplitter;
  }
  parts.push(buff);
  return parts;
}
function kebabCase(str, joiner) {
  return str ? (Array.isArray(str) ? str : splitByCase(str)).map((p) => p.toLowerCase()).join(joiner) : "";
}
function snakeCase(str) {
  return kebabCase(str || "", "_");
}

function getEnv(key, opts) {
  const envKey = snakeCase(key).toUpperCase();
  return destr(
    process.env[opts.prefix + envKey] ?? process.env[opts.altPrefix + envKey]
  );
}
function _isObject(input) {
  return typeof input === "object" && !Array.isArray(input);
}
function applyEnv(obj, opts, parentKey = "") {
  for (const key in obj) {
    const subKey = parentKey ? `${parentKey}_${key}` : key;
    const envValue = getEnv(subKey, opts);
    if (_isObject(obj[key])) {
      if (_isObject(envValue)) {
        obj[key] = { ...obj[key], ...envValue };
        applyEnv(obj[key], opts, subKey);
      } else if (envValue === void 0) {
        applyEnv(obj[key], opts, subKey);
      } else {
        obj[key] = envValue ?? obj[key];
      }
    } else {
      obj[key] = envValue ?? obj[key];
    }
    if (opts.envExpansion && typeof obj[key] === "string") {
      obj[key] = _expandFromEnv(obj[key]);
    }
  }
  return obj;
}
const envExpandRx = /\{\{([^{}]*)\}\}/g;
function _expandFromEnv(value) {
  return value.replace(envExpandRx, (match, key) => {
    return process.env[key] || match;
  });
}

const _inlineRuntimeConfig = {
  "app": {
    "baseURL": "/",
    "buildId": "a2268c73-ad23-416c-b458-06b8d2bdbc36",
    "buildAssetsDir": "/_nuxt/",
    "cdnURL": ""
  },
  "nitro": {
    "envPrefix": "NUXT_",
    "routeRules": {
      "/__nuxt_error": {
        "cache": false
      },
      "/_nuxt/builds/meta/**": {
        "headers": {
          "cache-control": "public, max-age=31536000, immutable"
        }
      },
      "/_nuxt/builds/**": {
        "headers": {
          "cache-control": "public, max-age=1, immutable"
        }
      },
      "/_nuxt/**": {
        "headers": {
          "cache-control": "public, max-age=31536000, immutable"
        }
      }
    }
  },
  "public": {},
  "baseUrl": "https://api.ahuan.ir"
};
const envOptions = {
  prefix: "NITRO_",
  altPrefix: _inlineRuntimeConfig.nitro.envPrefix ?? process.env.NITRO_ENV_PREFIX ?? "_",
  envExpansion: _inlineRuntimeConfig.nitro.envExpansion ?? process.env.NITRO_ENV_EXPANSION ?? false
};
const _sharedRuntimeConfig = _deepFreeze(
  applyEnv(klona(_inlineRuntimeConfig), envOptions)
);
function useRuntimeConfig(event) {
  if (!event) {
    return _sharedRuntimeConfig;
  }
  if (event.context.nitro.runtimeConfig) {
    return event.context.nitro.runtimeConfig;
  }
  const runtimeConfig = klona(_inlineRuntimeConfig);
  applyEnv(runtimeConfig, envOptions);
  event.context.nitro.runtimeConfig = runtimeConfig;
  return runtimeConfig;
}
_deepFreeze(klona(appConfig));
function _deepFreeze(object) {
  const propNames = Object.getOwnPropertyNames(object);
  for (const name of propNames) {
    const value = object[name];
    if (value && typeof value === "object") {
      _deepFreeze(value);
    }
  }
  return Object.freeze(object);
}
new Proxy(/* @__PURE__ */ Object.create(null), {
  get: (_, prop) => {
    console.warn(
      "Please use `useRuntimeConfig()` instead of accessing config directly."
    );
    const runtimeConfig = useRuntimeConfig();
    if (prop in runtimeConfig) {
      return runtimeConfig[prop];
    }
    return void 0;
  }
});

function createContext(opts = {}) {
  let currentInstance;
  let isSingleton = false;
  const checkConflict = (instance) => {
    if (currentInstance && currentInstance !== instance) {
      throw new Error("Context conflict");
    }
  };
  let als;
  if (opts.asyncContext) {
    const _AsyncLocalStorage = opts.AsyncLocalStorage || globalThis.AsyncLocalStorage;
    if (_AsyncLocalStorage) {
      als = new _AsyncLocalStorage();
    } else {
      console.warn("[unctx] `AsyncLocalStorage` is not provided.");
    }
  }
  const _getCurrentInstance = () => {
    if (als) {
      const instance = als.getStore();
      if (instance !== void 0) {
        return instance;
      }
    }
    return currentInstance;
  };
  return {
    use: () => {
      const _instance = _getCurrentInstance();
      if (_instance === void 0) {
        throw new Error("Context is not available");
      }
      return _instance;
    },
    tryUse: () => {
      return _getCurrentInstance();
    },
    set: (instance, replace) => {
      if (!replace) {
        checkConflict(instance);
      }
      currentInstance = instance;
      isSingleton = true;
    },
    unset: () => {
      currentInstance = void 0;
      isSingleton = false;
    },
    call: (instance, callback) => {
      checkConflict(instance);
      currentInstance = instance;
      try {
        return als ? als.run(instance, callback) : callback();
      } finally {
        if (!isSingleton) {
          currentInstance = void 0;
        }
      }
    },
    async callAsync(instance, callback) {
      currentInstance = instance;
      const onRestore = () => {
        currentInstance = instance;
      };
      const onLeave = () => currentInstance === instance ? onRestore : void 0;
      asyncHandlers.add(onLeave);
      try {
        const r = als ? als.run(instance, callback) : callback();
        if (!isSingleton) {
          currentInstance = void 0;
        }
        return await r;
      } finally {
        asyncHandlers.delete(onLeave);
      }
    }
  };
}
function createNamespace(defaultOpts = {}) {
  const contexts = {};
  return {
    get(key, opts = {}) {
      if (!contexts[key]) {
        contexts[key] = createContext({ ...defaultOpts, ...opts });
      }
      return contexts[key];
    }
  };
}
const _globalThis = typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : typeof global !== "undefined" ? global : {};
const globalKey = "__unctx__";
const defaultNamespace = _globalThis[globalKey] || (_globalThis[globalKey] = createNamespace());
const getContext = (key, opts = {}) => defaultNamespace.get(key, opts);
const asyncHandlersKey = "__unctx_async_handlers__";
const asyncHandlers = _globalThis[asyncHandlersKey] || (_globalThis[asyncHandlersKey] = /* @__PURE__ */ new Set());
function executeAsync(function_) {
  const restores = [];
  for (const leaveHandler of asyncHandlers) {
    const restore2 = leaveHandler();
    if (restore2) {
      restores.push(restore2);
    }
  }
  const restore = () => {
    for (const restore2 of restores) {
      restore2();
    }
  };
  let awaitable = function_();
  if (awaitable && typeof awaitable === "object" && "catch" in awaitable) {
    awaitable = awaitable.catch((error) => {
      restore();
      throw error;
    });
  }
  return [awaitable, restore];
}

function isPathInScope(pathname, base) {
  let canonical;
  try {
    const pre = pathname.replace(/%2f/gi, "/").replace(/%5c/gi, "\\");
    canonical = new URL(pre, "http://_").pathname;
  } catch {
    return false;
  }
  return !base || canonical === base || canonical.startsWith(base + "/");
}

const config = useRuntimeConfig();
const _routeRulesMatcher = toRouteMatcher(
  createRouter$1({ routes: config.nitro.routeRules })
);
function createRouteRulesHandler(ctx) {
  return eventHandler((event) => {
    const routeRules = getRouteRules(event);
    if (routeRules.headers) {
      setHeaders(event, routeRules.headers);
    }
    if (routeRules.redirect) {
      let target = routeRules.redirect.to;
      if (target.endsWith("/**")) {
        let targetPath = event.path;
        const strpBase = routeRules.redirect._redirectStripBase;
        if (strpBase) {
          if (!isPathInScope(event.path.split("?")[0], strpBase)) {
            throw createError$1({ statusCode: 400 });
          }
          targetPath = withoutBase(targetPath, strpBase);
        } else if (targetPath.startsWith("//")) {
          targetPath = targetPath.replace(/^\/+/, "/");
        }
        target = joinURL(target.slice(0, -3), targetPath);
      } else if (event.path.includes("?")) {
        const query = getQuery$1(event.path);
        target = withQuery(target, query);
      }
      return sendRedirect(event, target, routeRules.redirect.statusCode);
    }
    if (routeRules.proxy) {
      let target = routeRules.proxy.to;
      if (target.endsWith("/**")) {
        let targetPath = event.path;
        const strpBase = routeRules.proxy._proxyStripBase;
        if (strpBase) {
          if (!isPathInScope(event.path.split("?")[0], strpBase)) {
            throw createError$1({ statusCode: 400 });
          }
          targetPath = withoutBase(targetPath, strpBase);
        } else if (targetPath.startsWith("//")) {
          targetPath = targetPath.replace(/^\/+/, "/");
        }
        target = joinURL(target.slice(0, -3), targetPath);
      } else if (event.path.includes("?")) {
        const query = getQuery$1(event.path);
        target = withQuery(target, query);
      }
      return proxyRequest(event, target, {
        fetch: ctx.localFetch,
        ...routeRules.proxy
      });
    }
  });
}
function getRouteRules(event) {
  event.context._nitro = event.context._nitro || {};
  if (!event.context._nitro.routeRules) {
    event.context._nitro.routeRules = getRouteRulesForPath(
      withoutBase(event.path.split("?")[0], useRuntimeConfig().app.baseURL)
    );
  }
  return event.context._nitro.routeRules;
}
function getRouteRulesForPath(path) {
  return defu({}, ..._routeRulesMatcher.matchAll(path).reverse());
}

function _captureError(error, type) {
  console.error(`[${type}]`, error);
  useNitroApp().captureError(error, { tags: [type] });
}
function trapUnhandledNodeErrors() {
  process.on(
    "unhandledRejection",
    (error) => _captureError(error, "unhandledRejection")
  );
  process.on(
    "uncaughtException",
    (error) => _captureError(error, "uncaughtException")
  );
}
function joinHeaders(value) {
  return Array.isArray(value) ? value.join(", ") : String(value);
}
function normalizeFetchResponse(response) {
  if (!response.headers.has("set-cookie")) {
    return response;
  }
  return new Response(response.body, {
    status: response.status,
    statusText: response.statusText,
    headers: normalizeCookieHeaders(response.headers)
  });
}
function normalizeCookieHeader(header = "") {
  return splitCookiesString(joinHeaders(header));
}
function normalizeCookieHeaders(headers) {
  const outgoingHeaders = new Headers();
  for (const [name, header] of headers) {
    if (name === "set-cookie") {
      for (const cookie of normalizeCookieHeader(header)) {
        outgoingHeaders.append("set-cookie", cookie);
      }
    } else {
      outgoingHeaders.set(name, joinHeaders(header));
    }
  }
  return outgoingHeaders;
}

function isJsonRequest(event) {
	
	if (hasReqHeader(event, "accept", "text/html")) {
		return false;
	}
	return hasReqHeader(event, "accept", "application/json") || hasReqHeader(event, "user-agent", "curl/") || hasReqHeader(event, "user-agent", "httpie/") || hasReqHeader(event, "sec-fetch-mode", "cors") || event.path.startsWith("/api/") || event.path.endsWith(".json");
}
function hasReqHeader(event, name, includes) {
	const value = getRequestHeader(event, name);
	return !!(value && typeof value === "string" && value.toLowerCase().includes(includes));
}

const errorHandler$0 = (async function errorhandler(error, event, { defaultHandler }) {
	if (event.handled || isJsonRequest(event)) {
		
		return;
	}
	
	const defaultRes = await defaultHandler(error, event, { json: true });
	
	const status = error.status || error.statusCode || 500;
	if (status === 404 && defaultRes.status === 302) {
		setResponseHeaders(event, defaultRes.headers);
		setResponseStatus(event, defaultRes.status, defaultRes.statusText);
		return send(event, JSON.stringify(defaultRes.body, null, 2));
	}
	const errorObject = defaultRes.body;
	
	const url = new URL(errorObject.url);
	errorObject.url = withoutBase(url.pathname, useRuntimeConfig(event).app.baseURL) + url.search + url.hash;
	
	errorObject.message = error.unhandled ? errorObject.message || "Server Error" : error.message || errorObject.message || "Server Error";
	
	errorObject.data ||= error.data;
	errorObject.statusText ||= error.statusText || error.statusMessage;
	delete defaultRes.headers["content-type"];
	delete defaultRes.headers["content-security-policy"];
	setResponseHeaders(event, defaultRes.headers);
	
	const reqHeaders = getRequestHeaders(event);
	
	const isRenderingError = event.path.startsWith("/__nuxt_error") || !!reqHeaders["x-nuxt-error"] || !!event.context.nuxt?.["~rendering-error"];
	if (!isRenderingError) {
		event.context.nuxt ||= {};
		event.context.nuxt["~rendering-error"] = true;
	}
	
	const res = isRenderingError ? null : await useNitroApp().localFetch(withQuery(joinURL(useRuntimeConfig(event).app.baseURL, "/__nuxt_error"), errorObject), {
		headers: {
			...reqHeaders,
			"x-nuxt-error": "true"
		},
		redirect: "manual"
	}).catch(() => null);
	if (event.handled) {
		return;
	}
	
	if (!res) {
		const { template } = await import('./error-500.mjs');
		setResponseHeader(event, "Content-Type", "text/html;charset=UTF-8");
		return send(event, template(errorObject));
	}
	const html = await res.text();
	for (const [header, value] of res.headers.entries()) {
		if (header === "set-cookie") {
			appendResponseHeader(event, header, value);
			continue;
		}
		setResponseHeader(event, header, value);
	}
	setResponseStatus(event, res.status && res.status !== 200 ? res.status : defaultRes.status, res.statusText || defaultRes.statusText);
	return send(event, html);
});

function defineNitroErrorHandler(handler) {
  return handler;
}

const errorHandler$1 = defineNitroErrorHandler(
  function defaultNitroErrorHandler(error, event) {
    const res = defaultHandler(error, event);
    setResponseHeaders(event, res.headers);
    setResponseStatus(event, res.status, res.statusText);
    return send(event, JSON.stringify(res.body, null, 2));
  }
);
function defaultHandler(error, event, opts) {
  const isSensitive = error.unhandled || error.fatal;
  const statusCode = error.statusCode || 500;
  const statusMessage = error.statusMessage || "Server Error";
  const url = getRequestURL(event, { xForwardedHost: true, xForwardedProto: true });
  if (statusCode === 404) {
    const baseURL = "/";
    if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) {
      const redirectTo = `${baseURL}${url.pathname.slice(1)}${url.search}`;
      return {
        status: 302,
        statusText: "Found",
        headers: { location: redirectTo },
        body: `Redirecting...`
      };
    }
  }
  if (isSensitive && !opts?.silent) {
    const tags = [error.unhandled && "[unhandled]", error.fatal && "[fatal]"].filter(Boolean).join(" ");
    console.error(`[request error] ${tags} [${event.method}] ${url}
`, error);
  }
  const headers = {
    "content-type": "application/json",
    // Prevent browser from guessing the MIME types of resources.
    "x-content-type-options": "nosniff",
    // Prevent error page from being embedded in an iframe
    "x-frame-options": "DENY",
    // Prevent browsers from sending the Referer header
    "referrer-policy": "no-referrer",
    // Disable the execution of any js
    "content-security-policy": "script-src 'none'; frame-ancestors 'none';"
  };
  setResponseStatus(event, statusCode, statusMessage);
  if (statusCode === 404 || !getResponseHeader(event, "cache-control")) {
    headers["cache-control"] = "no-cache";
  }
  const body = {
    error: true,
    url: url.href,
    statusCode,
    statusMessage,
    message: isSensitive ? "Server Error" : error.message,
    data: isSensitive ? void 0 : error.data
  };
  return {
    status: statusCode,
    statusText: statusMessage,
    headers,
    body
  };
}

const errorHandlers = [errorHandler$0, errorHandler$1];

async function errorHandler(error, event) {
  for (const handler of errorHandlers) {
    try {
      await handler(error, event, { defaultHandler });
      if (event.handled) {
        return; // Response handled
      }
    } catch(error) {
      // Handler itself thrown, log and continue
      console.error(error);
    }
  }
  // H3 will handle fallback
}

const plugins = [
  
];

const assets = {
  "/favicon.ico": {
    "type": "image/vnd.microsoft.icon",
    "etag": "\"10be-n8egyE9tcb7sKGr/pYCaQ4uWqxI\"",
    "mtime": "2026-06-09T22:19:23.000Z",
    "size": 4286,
    "path": "../public/favicon.ico"
  },
  "/logoSite.png": {
    "type": "image/png",
    "etag": "\"45074-nX61Oru1g7Vqw6fGYhFEjiziALQ\"",
    "mtime": "2026-11-01T06:39:55.802Z",
    "size": 282740,
    "path": "../public/logoSite.png"
  },
  "/robots.txt": {
    "type": "text/plain; charset=utf-8",
    "etag": "\"18-j8OIsL9qGDmNZ+lHhp2tyH4XtaE\"",
    "mtime": "2026-06-09T22:19:23.000Z",
    "size": 24,
    "path": "../public/robots.txt"
  },
  "/hotel/1991722.jpg": {
    "type": "image/jpeg",
    "etag": "\"2f067-kWAe0+H+JlyFXFyl+IosKrDM3gs\"",
    "mtime": "2026-11-01T06:53:11.464Z",
    "size": 192615,
    "path": "../public/hotel/1991722.jpg"
  },
  "/hotel/favicon.ico": {
    "type": "image/vnd.microsoft.icon",
    "etag": "\"6667-VzFoZyVZfuJ3GLb0960WKFP2VEw\"",
    "mtime": "2026-11-01T06:53:11.477Z",
    "size": 26215,
    "path": "../public/hotel/favicon.ico"
  },
  "/hotel/index.html": {
    "type": "text/html; charset=utf-8",
    "etag": "\"320-2HZP7Jp1SqOeE8gudEa5hTnlT0E\"",
    "mtime": "2026-11-01T06:53:11.601Z",
    "size": 800,
    "path": "../public/hotel/index.html"
  },
  "/hotel/pattern site.png": {
    "type": "image/png",
    "etag": "\"1ef3a-OuO1QfTX8dLWKujp+dgpaHeGSvk\"",
    "mtime": "2026-11-01T06:53:11.647Z",
    "size": 126778,
    "path": "../public/hotel/pattern site.png"
  },
  "/_nuxt/49XO3ybx.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"2933-ZN46pT/zuBBYuJUC8zZbNFXMUKE\"",
    "mtime": "2026-11-09T11:13:45.612Z",
    "size": 10547,
    "path": "../public/_nuxt/49XO3ybx.js"
  },
  "/_nuxt/4PNVSj4j.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"17c99-gyKikP4LBPDDtnqZB4BIINL9B8Q\"",
    "mtime": "2026-11-09T11:13:45.611Z",
    "size": 97433,
    "path": "../public/_nuxt/4PNVSj4j.js"
  },
  "/_nuxt/AboutUs.DGPeOTK4.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"11f-WDweQI4lYcG7UYe5YUBvPZ060qM\"",
    "mtime": "2026-11-09T11:13:45.611Z",
    "size": 287,
    "path": "../public/_nuxt/AboutUs.DGPeOTK4.css"
  },
  "/_nuxt/5oyzJlNm.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"d43-HZwuoYF+7FGgpNtDGjD82jWW13c\"",
    "mtime": "2026-11-09T11:13:45.612Z",
    "size": 3395,
    "path": "../public/_nuxt/5oyzJlNm.js"
  },
  "/_nuxt/7-IZA48C.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"26ce7-/UJEttyfGjF2cqbU7wgEA2dW6YY\"",
    "mtime": "2026-11-09T11:13:45.614Z",
    "size": 158951,
    "path": "../public/_nuxt/7-IZA48C.js"
  },
  "/_nuxt/BaseAutocomplete.CKX3Up5b.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"2ab-hkPCETQnZ1bw70fxg+83Zsiag1s\"",
    "mtime": "2026-11-09T11:13:45.611Z",
    "size": 683,
    "path": "../public/_nuxt/BaseAutocomplete.CKX3Up5b.css"
  },
  "/_nuxt/BaseInput.Dic9hM4R.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"10b-uZVfXfjov3qvpdRyAD3FBtqrwwM\"",
    "mtime": "2026-11-09T11:13:45.611Z",
    "size": 267,
    "path": "../public/_nuxt/BaseInput.Dic9hM4R.css"
  },
  "/_nuxt/B3XdLEFX.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1d18-sFC2U3yhV2H5h1mtA/vC4OGCM14\"",
    "mtime": "2026-11-09T11:13:45.612Z",
    "size": 7448,
    "path": "../public/_nuxt/B3XdLEFX.js"
  },
  "/_nuxt/BaseTabs.CKrxn-ue.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"271-pFr1M1F7Q3VLZ1AZeUs8u0duVhI\"",
    "mtime": "2026-11-09T11:13:45.611Z",
    "size": 625,
    "path": "../public/_nuxt/BaseTabs.CKrxn-ue.css"
  },
  "/_nuxt/B6hObn66.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"da9-xStNEeOjetmR26UA6qEzWIT8Cgc\"",
    "mtime": "2026-11-09T11:13:45.612Z",
    "size": 3497,
    "path": "../public/_nuxt/B6hObn66.js"
  },
  "/_nuxt/BffRlnIq.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"35f8-LXa2DaUQpIEmYrlrw704GgxAuF8\"",
    "mtime": "2026-11-09T11:13:45.612Z",
    "size": 13816,
    "path": "../public/_nuxt/BffRlnIq.js"
  },
  "/_nuxt/BkotdkjM.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1c84-+cWVL+eEZBVzsQo6d4Yal8vqZzQ\"",
    "mtime": "2026-11-09T11:13:45.612Z",
    "size": 7300,
    "path": "../public/_nuxt/BkotdkjM.js"
  },
  "/_nuxt/BLBJAPgF.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"266d-7bEFePBnCEjnAgT7dmAQ2ZKzkP0\"",
    "mtime": "2026-11-09T11:13:45.612Z",
    "size": 9837,
    "path": "../public/_nuxt/BLBJAPgF.js"
  },
  "/_nuxt/BlYN92ok.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"7563-qf0wWNOVJ583817MHN6tYI1EdD0\"",
    "mtime": "2026-11-09T11:13:45.612Z",
    "size": 30051,
    "path": "../public/_nuxt/BlYN92ok.js"
  },
  "/_nuxt/BOGTfZe5.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1f00-8l1bQIIxkP9+3q9mY99HubEuDyE\"",
    "mtime": "2026-11-09T11:13:45.612Z",
    "size": 7936,
    "path": "../public/_nuxt/BOGTfZe5.js"
  },
  "/_nuxt/bootstrap-icons.mSm7cUeB.woff2": {
    "type": "font/woff2",
    "etag": "\"20b9c-tEH8/5OeJPoJBqN7d4h4i5/du2g\"",
    "mtime": "2026-11-09T11:13:45.611Z",
    "size": 134044,
    "path": "../public/_nuxt/bootstrap-icons.mSm7cUeB.woff2"
  },
  "/_nuxt/bootstrap-icons.BeopsB42.woff": {
    "type": "font/woff",
    "etag": "\"2c040-diAQx5tKBeETH8j7Oxrv8yTYAz8\"",
    "mtime": "2026-11-09T11:13:45.597Z",
    "size": 180288,
    "path": "../public/_nuxt/bootstrap-icons.BeopsB42.woff"
  },
  "/_nuxt/BtFD5omA.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"abea-gEMqCDbOk3E1VXNEHg5hazaFHFM\"",
    "mtime": "2026-11-09T11:13:45.612Z",
    "size": 44010,
    "path": "../public/_nuxt/BtFD5omA.js"
  },
  "/_nuxt/C2t415Ax.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"40-iVAM+b1+K46vhGQrFnV5ndqrhi8\"",
    "mtime": "2026-11-09T11:13:45.612Z",
    "size": 64,
    "path": "../public/_nuxt/C2t415Ax.js"
  },
  "/_nuxt/C3Rg87jv.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"19c68-Du6sT3Dk60vNYx/Wvx5Kz/dD4Js\"",
    "mtime": "2026-11-09T11:13:45.612Z",
    "size": 105576,
    "path": "../public/_nuxt/C3Rg87jv.js"
  },
  "/_nuxt/C85WY3RI.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"f2-1t0OMwSlT5135yiIFYNv1LpcMrI\"",
    "mtime": "2026-11-09T11:13:45.612Z",
    "size": 242,
    "path": "../public/_nuxt/C85WY3RI.js"
  },
  "/_nuxt/C4MhRHri.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"ec4-azfqrUdDLrv7zNaZTPTxS0jb5tc\"",
    "mtime": "2026-11-09T11:13:45.611Z",
    "size": 3780,
    "path": "../public/_nuxt/C4MhRHri.js"
  },
  "/_nuxt/bVKBIeqZ.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"2b1d3-bpNZ2yYM1sCL5dt6ho1yVpwYiJE\"",
    "mtime": "2026-11-09T11:13:45.612Z",
    "size": 176595,
    "path": "../public/_nuxt/bVKBIeqZ.js"
  },
  "/_nuxt/C9Jt_6Mo.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"14504-32PXOgOz/Sl4EWR3odVRcM2R20k\"",
    "mtime": "2026-11-09T11:13:45.612Z",
    "size": 83204,
    "path": "../public/_nuxt/C9Jt_6Mo.js"
  },
  "/_nuxt/CEBYger9.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"70bc-ACI6reTSHPnxH2qoGnp6HQi6b4E\"",
    "mtime": "2026-11-09T11:13:45.613Z",
    "size": 28860,
    "path": "../public/_nuxt/CEBYger9.js"
  },
  "/_nuxt/C9QVHim-.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1ab8-tehyW48zO1sKtoA0kv+KxslJKyQ\"",
    "mtime": "2026-11-09T11:13:45.612Z",
    "size": 6840,
    "path": "../public/_nuxt/C9QVHim-.js"
  },
  "/_nuxt/CFSdD0rv.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"8a7-C7i18S/ZIXYLJXpzj/vIiX+vvd8\"",
    "mtime": "2026-11-09T11:13:45.612Z",
    "size": 2215,
    "path": "../public/_nuxt/CFSdD0rv.js"
  },
  "/_nuxt/CtZ9pSN5.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1c84-PyVSW5Bv2gsNOBCxO7FMSsSKB7M\"",
    "mtime": "2026-11-09T11:13:45.612Z",
    "size": 7300,
    "path": "../public/_nuxt/CtZ9pSN5.js"
  },
  "/_nuxt/ContactUs.DGGSdCdM.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"177-hZ2wJirZYva85Ofd9T76ck4lETg\"",
    "mtime": "2026-11-09T11:13:45.611Z",
    "size": 375,
    "path": "../public/_nuxt/ContactUs.DGGSdCdM.css"
  },
  "/_nuxt/CustomerRightsOffice.D-atnBXS.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"21a-X3/tKhN/e5eOj0br8lRV8VpyfHw\"",
    "mtime": "2026-11-09T11:13:45.611Z",
    "size": 538,
    "path": "../public/_nuxt/CustomerRightsOffice.D-atnBXS.css"
  },
  "/_nuxt/Cpj98o6Y.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"ec-QtY1KaLA8vnMK3l2IvajpxyuPmY\"",
    "mtime": "2026-11-09T11:13:45.614Z",
    "size": 236,
    "path": "../public/_nuxt/Cpj98o6Y.js"
  },
  "/_nuxt/CapwiaUA.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"153b-8Bz4sbhonmw2qEboIbXpcVHufzM\"",
    "mtime": "2026-11-09T11:13:45.612Z",
    "size": 5435,
    "path": "../public/_nuxt/CapwiaUA.js"
  },
  "/_nuxt/CJDIr1pP.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"3c-HzEKOWShbExffbELnn3+QxrFgso\"",
    "mtime": "2026-11-09T11:13:45.612Z",
    "size": 60,
    "path": "../public/_nuxt/CJDIr1pP.js"
  },
  "/_nuxt/CWE7o2cY.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"63c7-6UOsw7Jgfg+HnmBxpkJg6Bx+BRE\"",
    "mtime": "2026-11-09T11:13:45.612Z",
    "size": 25543,
    "path": "../public/_nuxt/CWE7o2cY.js"
  },
  "/_nuxt/CSAlF372.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1570-iTDo6xOvbxiNhf8Tdl+AJziMm/E\"",
    "mtime": "2026-11-09T11:13:45.612Z",
    "size": 5488,
    "path": "../public/_nuxt/CSAlF372.js"
  },
  "/_nuxt/DateCarousel.D56cTI0K.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"7f-H2H+yh7DlPNWzb5uXsFWspaghRs\"",
    "mtime": "2026-11-09T11:13:45.611Z",
    "size": 127,
    "path": "../public/_nuxt/DateCarousel.D56cTI0K.css"
  },
  "/_nuxt/Cz_0g-EY.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1626-K9Tlmnwjz1QpUZewxofWTL/TssM\"",
    "mtime": "2026-11-09T11:13:45.612Z",
    "size": 5670,
    "path": "../public/_nuxt/Cz_0g-EY.js"
  },
  "/_nuxt/default.C8QsuFCM.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"4b6-BUPvOycgN3UAAYo9OaGDV0yQsdE\"",
    "mtime": "2026-11-09T11:13:45.611Z",
    "size": 1206,
    "path": "../public/_nuxt/default.C8QsuFCM.css"
  },
  "/_nuxt/DaH9nC2Y.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"4f8-zPH+2CA7AnKpEbpFyqAX/Rlc3lw\"",
    "mtime": "2026-11-09T11:13:45.612Z",
    "size": 1272,
    "path": "../public/_nuxt/DaH9nC2Y.js"
  },
  "/_nuxt/D2H5Dp7R.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"2127-XtjrN4ifoJD1aqQI3NQUeHWWlFY\"",
    "mtime": "2026-11-09T11:13:45.612Z",
    "size": 8487,
    "path": "../public/_nuxt/D2H5Dp7R.js"
  },
  "/_nuxt/CuWI8Lot.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"5e49d-dsCFWa54r+YZOzZIdj6pdenA2PA\"",
    "mtime": "2026-11-09T11:13:45.612Z",
    "size": 386205,
    "path": "../public/_nuxt/CuWI8Lot.js"
  },
  "/_nuxt/CyomWann.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"17e08-p/EfPWMIvfuwqhd51O9pYV/P/1s\"",
    "mtime": "2026-11-09T11:13:45.612Z",
    "size": 97800,
    "path": "../public/_nuxt/CyomWann.js"
  },
  "/_nuxt/DEUKR54l.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"6686-45INg5qb5ZUXkyoHOnQkpD8gVCs\"",
    "mtime": "2026-11-09T11:13:45.612Z",
    "size": 26246,
    "path": "../public/_nuxt/DEUKR54l.js"
  },
  "/_nuxt/Dj8hvrly.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"5b56-/dzu4XEO8am4v9i4klMCqWulnHU\"",
    "mtime": "2026-11-09T11:13:45.612Z",
    "size": 23382,
    "path": "../public/_nuxt/Dj8hvrly.js"
  },
  "/_nuxt/DNEWkfQ5.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1320f-+wbiaMVluqV5G9HzmS7UHc2YsbU\"",
    "mtime": "2026-11-09T11:13:45.612Z",
    "size": 78351,
    "path": "../public/_nuxt/DNEWkfQ5.js"
  },
  "/_nuxt/DNmdQrfK.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"fa7d-NTlqLcZy68vKJQD50ReUMEGaS4Q\"",
    "mtime": "2026-11-09T11:13:45.612Z",
    "size": 64125,
    "path": "../public/_nuxt/DNmdQrfK.js"
  },
  "/_nuxt/Dq8UUZNx.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"dc-+HRzC63n0NNqd4SNDVCcMM3opsg\"",
    "mtime": "2026-11-09T11:13:45.612Z",
    "size": 220,
    "path": "../public/_nuxt/Dq8UUZNx.js"
  },
  "/_nuxt/DsPrVMZN.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"764-DQ8kqHUwkx2C/ZASYxJY2rhfiK0\"",
    "mtime": "2026-11-09T11:13:45.612Z",
    "size": 1892,
    "path": "../public/_nuxt/DsPrVMZN.js"
  },
  "/_nuxt/DVed23k8.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"7048-gfpvEo1GtV8WyQRNrTH6lkSmh8w\"",
    "mtime": "2026-11-09T11:13:45.612Z",
    "size": 28744,
    "path": "../public/_nuxt/DVed23k8.js"
  },
  "/_nuxt/DWsW1mAt.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"306db-b9Q4yLMwWItG5/D2z5AFRpwguos\"",
    "mtime": "2026-11-09T11:13:45.611Z",
    "size": 198363,
    "path": "../public/_nuxt/DWsW1mAt.js"
  },
  "/_nuxt/DXEQVQnt.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"31151-TyUyRNm9rR2JDwpyAxcruTmmr6A\"",
    "mtime": "2026-11-09T11:13:45.612Z",
    "size": 201041,
    "path": "../public/_nuxt/DXEQVQnt.js"
  },
  "/_nuxt/DyJvOIIe.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"dc-8KkrAtVLQ2kXd+mMg2hZ1nk+xjk\"",
    "mtime": "2026-11-09T11:13:45.612Z",
    "size": 220,
    "path": "../public/_nuxt/DyJvOIIe.js"
  },
  "/_nuxt/entry.NCLxmWEB.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"4da-oGhz7MM6YWyITpmfmw8yADhZ++c\"",
    "mtime": "2026-11-09T11:13:45.611Z",
    "size": 1242,
    "path": "../public/_nuxt/entry.NCLxmWEB.css"
  },
  "/_nuxt/flights.DJ6cj02C.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"4fc-NFXKJ/iRZVFKf//ktboaKWZRNzQ\"",
    "mtime": "2026-11-09T11:13:45.611Z",
    "size": 1276,
    "path": "../public/_nuxt/flights.DJ6cj02C.css"
  },
  "/_nuxt/FlightSearchPanel.DGz5wqui.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"25f-YSXL3Bx16iiGPaxh1uqY7FDPXx0\"",
    "mtime": "2026-11-09T11:13:45.611Z",
    "size": 607,
    "path": "../public/_nuxt/FlightSearchPanel.DGz5wqui.css"
  },
  "/_nuxt/hqwOHZQc.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"8d8c-4iwBlZ6rvHXvVfEKICAo4wqOFDI\"",
    "mtime": "2026-11-09T11:13:45.612Z",
    "size": 36236,
    "path": "../public/_nuxt/hqwOHZQc.js"
  },
  "/_nuxt/index.1yBJokol.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"c6-Ur8v8y3hXIuxlqgrWQVJwscply8\"",
    "mtime": "2026-11-09T11:13:45.611Z",
    "size": 198,
    "path": "../public/_nuxt/index.1yBJokol.css"
  },
  "/_nuxt/index.5d-DaXTF.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"45c-sdS5NKnLLg0u5qq9BOiXaGvOi0g\"",
    "mtime": "2026-11-09T11:13:45.611Z",
    "size": 1116,
    "path": "../public/_nuxt/index.5d-DaXTF.css"
  },
  "/_nuxt/index.Bmmh2CyO.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"1b7-GcsPFmDc8Wo/OokEInsQ3kyeXAw\"",
    "mtime": "2026-11-09T11:13:45.611Z",
    "size": 439,
    "path": "../public/_nuxt/index.Bmmh2CyO.css"
  },
  "/_nuxt/index.BYQh3hYv.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"293-Rt+E+NODafEmPFu9luQhsAlLCvE\"",
    "mtime": "2026-11-09T11:13:45.611Z",
    "size": 659,
    "path": "../public/_nuxt/index.BYQh3hYv.css"
  },
  "/_nuxt/JpW81jz0.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"7892-mZbW+/PserUJGtuhFvxtT8p0HU4\"",
    "mtime": "2026-11-09T11:13:45.611Z",
    "size": 30866,
    "path": "../public/_nuxt/JpW81jz0.js"
  },
  "/_nuxt/mdUPZOFX.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"3a6e-1WR/Ldko/AAkJqTEkAfXl0JEWu4\"",
    "mtime": "2026-11-09T11:13:45.612Z",
    "size": 14958,
    "path": "../public/_nuxt/mdUPZOFX.js"
  },
  "/_nuxt/oowsIQDN.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"a11-OTnuSiWKhPswOetv8gGitipN7jA\"",
    "mtime": "2026-11-09T11:13:45.612Z",
    "size": 2577,
    "path": "../public/_nuxt/oowsIQDN.js"
  },
  "/_nuxt/opportunities.BhK3gegw.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"20c-bSE5c/4ZDf4THJ0p4nZzVOD6Jek\"",
    "mtime": "2026-11-09T11:13:45.611Z",
    "size": 524,
    "path": "../public/_nuxt/opportunities.BhK3gegw.css"
  },
  "/_nuxt/Orh4xMj8.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"a813-i3l5lERPgl6R4ZFmZW0c1UwBiF8\"",
    "mtime": "2026-11-09T11:13:45.612Z",
    "size": 43027,
    "path": "../public/_nuxt/Orh4xMj8.js"
  },
  "/_nuxt/PaymentSummary.djU_hIPa.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"48a-+p7xBlG3ch36hlDswbl68+JCNDM\"",
    "mtime": "2026-11-09T11:13:45.611Z",
    "size": 1162,
    "path": "../public/_nuxt/PaymentSummary.djU_hIPa.css"
  },
  "/_nuxt/PelakFA-Medium.Bqa6iDD0.ttf": {
    "type": "font/ttf",
    "etag": "\"166b0-RM0BbuuLYK+cbjH1vTbwhQliz5M\"",
    "mtime": "2026-11-09T11:13:45.611Z",
    "size": 91824,
    "path": "../public/_nuxt/PelakFA-Medium.Bqa6iDD0.ttf"
  },
  "/_nuxt/profile.ByT980gx.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"173c-zKTZJwWn4JB3UMQporIiNWpmfbk\"",
    "mtime": "2026-11-09T11:13:45.611Z",
    "size": 5948,
    "path": "../public/_nuxt/profile.ByT980gx.css"
  },
  "/_nuxt/pSY-1kFq.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1134-239HsAGH1VBeklWPZkkRIQlQ+OI\"",
    "mtime": "2026-11-09T11:13:45.612Z",
    "size": 4404,
    "path": "../public/_nuxt/pSY-1kFq.js"
  },
  "/_nuxt/Rokh-Bold.O05jJwSh.woff": {
    "type": "font/woff",
    "etag": "\"16598-/R8ItamZKZR7hFLCSjGDZwIaqP8\"",
    "mtime": "2026-11-09T11:13:45.611Z",
    "size": 91544,
    "path": "../public/_nuxt/Rokh-Bold.O05jJwSh.woff"
  },
  "/_nuxt/SfO-C7cq.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"188f-69foZXn6uta6i49xHgoGyQ39KKk\"",
    "mtime": "2026-11-09T11:13:45.612Z",
    "size": 6287,
    "path": "../public/_nuxt/SfO-C7cq.js"
  },
  "/_nuxt/UiSingleDatePicker.CNvC7jP7.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"1047-Dv996yqlxt2zDtr1Nfof+YFVZa0\"",
    "mtime": "2026-11-09T11:13:45.612Z",
    "size": 4167,
    "path": "../public/_nuxt/UiSingleDatePicker.CNvC7jP7.css"
  },
  "/_nuxt/v_HmErKp.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"11d3-ue0cLx5vjfYBQoE10UU84lQPLvU\"",
    "mtime": "2026-11-09T11:13:45.612Z",
    "size": 4563,
    "path": "../public/_nuxt/v_HmErKp.js"
  },
  "/_nuxt/W69qMeq0.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"dc-LlHw4s4h2phZXmu3idjyk66CUeg\"",
    "mtime": "2026-11-09T11:13:45.612Z",
    "size": 220,
    "path": "../public/_nuxt/W69qMeq0.js"
  },
  "/_nuxt/_id_.BV7McCFz.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"38e-1d1JzAtkp2wkRgHqqaa0Ox+ej0o\"",
    "mtime": "2026-11-09T11:13:45.611Z",
    "size": 910,
    "path": "../public/_nuxt/_id_.BV7McCFz.css"
  },
  "/_nuxt/_id_.ChGKKsTG.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"26b7-Bxq4a4vGgj/tBnjqGPcJIbw+Zcg\"",
    "mtime": "2026-11-09T11:13:45.611Z",
    "size": 9911,
    "path": "../public/_nuxt/_id_.ChGKKsTG.css"
  },
  "/_nuxt/_id_.Dlt8L2qM.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"f7d-3UwsiXpSrIjF6aPRIaspyp+2bR4\"",
    "mtime": "2026-11-09T11:13:45.611Z",
    "size": 3965,
    "path": "../public/_nuxt/_id_.Dlt8L2qM.css"
  },
  "/_nuxt/_packageId_.1E90POCv.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"16b-olAo/Gs/f1X/PrCivt2zqMPPaLg\"",
    "mtime": "2026-11-09T11:13:45.611Z",
    "size": 363,
    "path": "../public/_nuxt/_packageId_.1E90POCv.css"
  },
  "/hotel/css/143.4986fb9a.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"c8-B9Y4e1qnfr/hbuxpTwVVzffx1rE\"",
    "mtime": "2026-11-01T06:53:11.465Z",
    "size": 200,
    "path": "../public/hotel/css/143.4986fb9a.css"
  },
  "/hotel/css/218.b5d1a9bd.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"fdc2-YMO7iAO61RhSunjqWPFYBDD1Nzs\"",
    "mtime": "2026-11-01T06:53:11.466Z",
    "size": 64962,
    "path": "../public/hotel/css/218.b5d1a9bd.css"
  },
  "/hotel/css/257.0fc9cf67.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"49a-QNuYiRgs6vl9S6g9CDgmHQCUG2A\"",
    "mtime": "2026-11-01T06:53:11.467Z",
    "size": 1178,
    "path": "../public/hotel/css/257.0fc9cf67.css"
  },
  "/hotel/css/279.cfe5ad74.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"c8-1fGdrWcbYg5vuMPywzzmK4Cpfqc\"",
    "mtime": "2026-11-01T06:53:11.467Z",
    "size": 200,
    "path": "../public/hotel/css/279.cfe5ad74.css"
  },
  "/hotel/css/319.acb148c7.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"c7-6APmonL8Li7b2sOZJXiB7R61i3Y\"",
    "mtime": "2026-11-01T06:53:11.468Z",
    "size": 199,
    "path": "../public/hotel/css/319.acb148c7.css"
  },
  "/hotel/css/34.dccdb780.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"c8-LBwQLsmwKSTrwD+fGnAq6/LMzZw\"",
    "mtime": "2026-11-01T06:53:11.468Z",
    "size": 200,
    "path": "../public/hotel/css/34.dccdb780.css"
  },
  "/hotel/css/411.6a05e8bb.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"c8-rTxa/DNNlCZj5yvouqFRuU3hlL8\"",
    "mtime": "2026-11-01T06:53:11.469Z",
    "size": 200,
    "path": "../public/hotel/css/411.6a05e8bb.css"
  },
  "/hotel/css/453.72a99900.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"c8-I/2rrAI3w1qdlkCDv+zpTUE3Zz8\"",
    "mtime": "2026-11-01T06:53:11.469Z",
    "size": 200,
    "path": "../public/hotel/css/453.72a99900.css"
  },
  "/hotel/css/543.12b895a7.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"c8-7qVjw/WINQ90Bk38EoWYK24Q7hY\"",
    "mtime": "2026-11-01T06:53:11.469Z",
    "size": 200,
    "path": "../public/hotel/css/543.12b895a7.css"
  },
  "/hotel/css/643.065c7765.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"c8-bY9vKfBq1eTiJS5HpXBYzg46h48\"",
    "mtime": "2026-11-01T06:53:11.470Z",
    "size": 200,
    "path": "../public/hotel/css/643.065c7765.css"
  },
  "/hotel/css/848.dd492fa0.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"195-90f1LqzePnNNcY6UbPb2WUkuts8\"",
    "mtime": "2026-11-01T06:53:11.470Z",
    "size": 405,
    "path": "../public/hotel/css/848.dd492fa0.css"
  },
  "/hotel/css/984.1158248e.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"c8-96mlOJn0QOrr/DAhFFwbQ+cCzuU\"",
    "mtime": "2026-11-01T06:53:11.471Z",
    "size": 200,
    "path": "../public/hotel/css/984.1158248e.css"
  },
  "/hotel/css/app.dbda882d.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"5984-gZ6RW97xBvI5jBtr1YcyKEgKHpE\"",
    "mtime": "2026-11-01T06:53:11.472Z",
    "size": 22916,
    "path": "../public/hotel/css/app.dbda882d.css"
  },
  "/hotel/fonts/at10.06f41e4e.woff": {
    "type": "font/woff",
    "etag": "\"89d0-PEHVNjO0GCTeJ7mfvrIaPPxeeUQ\"",
    "mtime": "2026-11-01T06:53:11.489Z",
    "size": 35280,
    "path": "../public/hotel/fonts/at10.06f41e4e.woff"
  },
  "/hotel/css/chunk-vendors.35e3814c.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"be2d8-BhOsaWWKl3YMGn586OnsgPFM0y4\"",
    "mtime": "2026-11-01T06:53:11.476Z",
    "size": 778968,
    "path": "../public/hotel/css/chunk-vendors.35e3814c.css"
  },
  "/hotel/fonts/at10.9be5c96c.eot": {
    "type": "application/vnd.ms-fontobject",
    "etag": "\"da8c-QVSBuTsUk77TH0bmUddMIMlRZ7U\"",
    "mtime": "2026-11-01T06:53:11.490Z",
    "size": 55948,
    "path": "../public/hotel/fonts/at10.9be5c96c.eot"
  },
  "/hotel/fonts/at10.c7178acf.ttf": {
    "type": "font/ttf",
    "etag": "\"d958-lUC97MNjy4hq758sDmCmv1u4iC8\"",
    "mtime": "2026-11-01T06:53:11.491Z",
    "size": 55640,
    "path": "../public/hotel/fonts/at10.c7178acf.ttf"
  },
  "/hotel/fonts/at10.ecabe04e.woff2": {
    "type": "font/woff2",
    "etag": "\"6d28-AufINCNdNZVNkWiYA6/Wp9W2wE4\"",
    "mtime": "2026-11-01T06:53:11.493Z",
    "size": 27944,
    "path": "../public/hotel/fonts/at10.ecabe04e.woff2"
  },
  "/hotel/fonts/materialdesignicons-webfont.fbaef2a9.woff2": {
    "type": "font/woff2",
    "etag": "\"62710-TiD2zPQxmd6lyFsjoODwuoH/7iY\"",
    "mtime": "2026-11-01T06:53:11.525Z",
    "size": 403216,
    "path": "../public/hotel/fonts/materialdesignicons-webfont.fbaef2a9.woff2"
  },
  "/hotel/fonts/MaterialIcons-Regular.14b0bb77.woff": {
    "type": "font/woff",
    "etag": "\"27340-5fpSVkjHQhPN64VUqncFfwxNhIg\"",
    "mtime": "2026-11-01T06:53:11.478Z",
    "size": 160576,
    "path": "../public/hotel/fonts/MaterialIcons-Regular.14b0bb77.woff"
  },
  "/hotel/fonts/MaterialIcons-Regular.a973ee76.eot": {
    "type": "application/vnd.ms-fontobject",
    "etag": "\"2305c-WeR7bd7nzLd2G0q5uBxGYbgYEf0\"",
    "mtime": "2026-11-01T06:53:11.480Z",
    "size": 143452,
    "path": "../public/hotel/fonts/MaterialIcons-Regular.a973ee76.eot"
  },
  "/hotel/fonts/MaterialIcons-Regular.d1b99623.woff2": {
    "type": "font/woff2",
    "etag": "\"1e8bc-fmes9W9tUnmAUEw9DdKjDXBuUzk\"",
    "mtime": "2026-11-01T06:53:11.481Z",
    "size": 125116,
    "path": "../public/hotel/fonts/MaterialIcons-Regular.d1b99623.woff2"
  },
  "/hotel/fonts/MaterialIcons-Regular.fa58bcb9.ttf": {
    "type": "font/ttf",
    "etag": "\"54dc4-tYK4af4F819aHQjN9QsrXrN7rkQ\"",
    "mtime": "2026-11-01T06:53:11.485Z",
    "size": 347588,
    "path": "../public/hotel/fonts/MaterialIcons-Regular.fa58bcb9.ttf"
  },
  "/hotel/fonts/PelakFA-Medium.134c7c02.ttf": {
    "type": "font/ttf",
    "etag": "\"166b0-RM0BbuuLYK+cbjH1vTbwhQliz5M\"",
    "mtime": "2026-11-01T06:53:11.487Z",
    "size": 91824,
    "path": "../public/hotel/fonts/PelakFA-Medium.134c7c02.ttf"
  },
  "/hotel/fonts/Rokh-Bold.aef0bebc.woff": {
    "type": "font/woff",
    "etag": "\"16598-/R8ItamZKZR7hFLCSjGDZwIaqP8\"",
    "mtime": "2026-11-01T06:53:11.488Z",
    "size": 91544,
    "path": "../public/hotel/fonts/Rokh-Bold.aef0bebc.woff"
  },
  "/hotel/img/361251718542130217238228142899722922172134.6c77c68d.jpg": {
    "type": "image/jpeg",
    "etag": "\"1bc4f-f8oh9fZf5YeHBCxOyW24EeAMLko\"",
    "mtime": "2026-11-01T06:53:11.527Z",
    "size": 113743,
    "path": "../public/hotel/img/361251718542130217238228142899722922172134.6c77c68d.jpg"
  },
  "/hotel/img/404.0d0235b8.png": {
    "type": "image/png",
    "etag": "\"12df5-+fSIMSwwKdlXIlwTOz3q2bWtyFM\"",
    "mtime": "2026-11-01T06:53:11.528Z",
    "size": 77301,
    "path": "../public/hotel/img/404.0d0235b8.png"
  },
  "/hotel/img/7.f9a4b712.jpg": {
    "type": "image/jpeg",
    "etag": "\"951a-J8tCowp9owS8EwxDyj00aQopVTo\"",
    "mtime": "2026-11-01T06:53:11.529Z",
    "size": 38170,
    "path": "../public/hotel/img/7.f9a4b712.jpg"
  },
  "/hotel/img/abgarm.b46be0e8.jpg": {
    "type": "image/jpeg",
    "etag": "\"34c33-/vTkLq2YmtTspJztpQDTJQQy99s\"",
    "mtime": "2026-11-01T06:53:11.531Z",
    "size": 216115,
    "path": "../public/hotel/img/abgarm.b46be0e8.jpg"
  },
  "/hotel/img/Asset 3112.2953919e.svg": {
    "type": "image/svg+xml",
    "etag": "\"2319-2ZhopYEdsPVjTwS/Ys67lXvrvws\"",
    "mtime": "2026-11-01T06:53:11.529Z",
    "size": 8985,
    "path": "../public/hotel/img/Asset 3112.2953919e.svg"
  },
  "/hotel/img/at10.8b39b899.svg": {
    "type": "image/svg+xml",
    "etag": "\"362d0-2fZfyQTnfAArGjznwqMktLaRUOg\"",
    "mtime": "2026-11-01T06:53:11.533Z",
    "size": 221904,
    "path": "../public/hotel/img/at10.8b39b899.svg"
  },
  "/hotel/img/baghalaghatogh.6043df82.jpg": {
    "type": "image/jpeg",
    "etag": "\"16ba2-e+EqiWHJA/t4Xmy0QcGnsU62cI8\"",
    "mtime": "2026-11-01T06:53:11.534Z",
    "size": 93090,
    "path": "../public/hotel/img/baghalaghatogh.6043df82.jpg"
  },
  "/hotel/img/card2p.c73a0ef4.jpg": {
    "type": "image/jpeg",
    "etag": "\"19557-k1XZlg1hfBJVXIKdO06VcJjzRa4\"",
    "mtime": "2026-11-01T06:53:11.535Z",
    "size": 103767,
    "path": "../public/hotel/img/card2p.c73a0ef4.jpg"
  },
  "/hotel/img/chiken.eaec7af5.jpg": {
    "type": "image/jpeg",
    "etag": "\"135dd-i4JSylWQHubu5lOTyQr29T+/Gf0\"",
    "mtime": "2026-11-01T06:53:11.536Z",
    "size": 79325,
    "path": "../public/hotel/img/chiken.eaec7af5.jpg"
  },
  "/hotel/img/country-1.2afab4a9.jpg": {
    "type": "image/jpeg",
    "etag": "\"1c52f-1HAtv9g8ehhb3dn++jZMI5nWJV0\"",
    "mtime": "2026-11-01T06:53:11.537Z",
    "size": 116015,
    "path": "../public/hotel/img/country-1.2afab4a9.jpg"
  },
  "/hotel/img/country-2.74fda308.jpg": {
    "type": "image/jpeg",
    "etag": "\"10409-pczHH0VUYSpZQ0TBVclcY+OMpGs\"",
    "mtime": "2026-11-01T06:53:11.538Z",
    "size": 66569,
    "path": "../public/hotel/img/country-2.74fda308.jpg"
  },
  "/hotel/fonts/materialdesignicons-webfont.e659bf56.woff": {
    "type": "font/woff",
    "etag": "\"8f8d0-zD3UavWtb7zNpwtFPVWUs57NasQ\"",
    "mtime": "2026-11-01T06:53:11.523Z",
    "size": 587984,
    "path": "../public/hotel/fonts/materialdesignicons-webfont.e659bf56.woff"
  },
  "/hotel/img/country-3.22fceb72.jpg": {
    "type": "image/jpeg",
    "etag": "\"b797-w3rOkjBVlqGKNClZXd39NM+mvA0\"",
    "mtime": "2026-11-01T06:53:11.539Z",
    "size": 46999,
    "path": "../public/hotel/img/country-3.22fceb72.jpg"
  },
  "/hotel/fonts/materialdesignicons-webfont.0766edc9.eot": {
    "type": "application/vnd.ms-fontobject",
    "etag": "\"13f4e8-ApygSKV9BTQg/POr5dCUzjU5OZw\"",
    "mtime": "2026-11-01T06:53:11.507Z",
    "size": 1307880,
    "path": "../public/hotel/fonts/materialdesignicons-webfont.0766edc9.eot"
  },
  "/hotel/fonts/materialdesignicons-webfont.714a4eee.ttf": {
    "type": "font/ttf",
    "etag": "\"13f40c-T1Gk3HWmjT5XMhxEjv3eojyKnbA\"",
    "mtime": "2026-11-01T06:53:11.520Z",
    "size": 1307660,
    "path": "../public/hotel/fonts/materialdesignicons-webfont.714a4eee.ttf"
  },
  "/hotel/img/country-5.0de8a317.jpg": {
    "type": "image/jpeg",
    "etag": "\"d7a1-/kPPcy7F7IG65oPZC6OI7WCdONA\"",
    "mtime": "2026-11-01T06:53:11.541Z",
    "size": 55201,
    "path": "../public/hotel/img/country-5.0de8a317.jpg"
  },
  "/hotel/img/country-4.552de940.jpg": {
    "type": "image/jpeg",
    "etag": "\"19449-8UwUnBtx14h0xnT0lRUlJ/22PWY\"",
    "mtime": "2026-11-01T06:53:11.540Z",
    "size": 103497,
    "path": "../public/hotel/img/country-4.552de940.jpg"
  },
  "/hotel/img/country-6.1ad76dc9.jpg": {
    "type": "image/jpeg",
    "etag": "\"29038-ed1Md3TNVy2npmvFppDiEe5ohDM\"",
    "mtime": "2026-11-01T06:53:11.542Z",
    "size": 167992,
    "path": "../public/hotel/img/country-6.1ad76dc9.jpg"
  },
  "/hotel/img/england_homework_gnome.29a2fb4b.jpg": {
    "type": "image/jpeg",
    "etag": "\"2502d-3qj4Lw+8W8jAXkoTlV6WumOIIM0\"",
    "mtime": "2026-11-01T06:53:11.544Z",
    "size": 151597,
    "path": "../public/hotel/img/england_homework_gnome.29a2fb4b.jpg"
  },
  "/hotel/img/eylagh2000.d1f131f7.jpg": {
    "type": "image/jpeg",
    "etag": "\"5cbb7-EHOYKOkg8AGZSqAooaKsGrnGgVI\"",
    "mtime": "2026-11-01T06:53:11.546Z",
    "size": 379831,
    "path": "../public/hotel/img/eylagh2000.d1f131f7.jpg"
  },
  "/hotel/img/gilan-dress.f882106c.jpg": {
    "type": "image/jpeg",
    "etag": "\"1f9a9-/Vs8Jw2WzRbZ4PlEQ5UexOZK9Pc\"",
    "mtime": "2026-11-01T06:53:11.559Z",
    "size": 129449,
    "path": "../public/hotel/img/gilan-dress.f882106c.jpg"
  },
  "/hotel/img/javaherdasht5.66bae68c.jpg": {
    "type": "image/jpeg",
    "etag": "\"130dc-tj1+IlL+LHrtGUoLyhG8L6v0OFY\"",
    "mtime": "2026-11-01T06:53:11.563Z",
    "size": 78044,
    "path": "../public/hotel/img/javaherdasht5.66bae68c.jpg"
  },
  "/hotel/img/javaherdasht.535e58c8.gif": {
    "type": "image/gif",
    "etag": "\"54670-+h0puQ+BBi5A8JJeUmOAgPM2Ckc\"",
    "mtime": "2026-11-01T06:53:11.562Z",
    "size": 345712,
    "path": "../public/hotel/img/javaherdasht.535e58c8.gif"
  },
  "/hotel/img/kababtorsh.3dc8d76f.jpg": {
    "type": "image/jpeg",
    "etag": "\"16232-7zyVwjI9apUWPKMhk1jvwczuAds\"",
    "mtime": "2026-11-01T06:53:11.564Z",
    "size": 90674,
    "path": "../public/hotel/img/kababtorsh.3dc8d76f.jpg"
  },
  "/hotel/img/map.4fac819d.jpg": {
    "type": "image/jpeg",
    "etag": "\"b2bb-Z3yIVyVY+fRRIOFVJ1lfC3qmbWY\"",
    "mtime": "2026-11-01T06:53:11.569Z",
    "size": 45755,
    "path": "../public/hotel/img/map.4fac819d.jpg"
  },
  "/hotel/img/mahi.f2e8dc74.jpg": {
    "type": "image/jpeg",
    "etag": "\"15fcd-8lRaFpUaigN2br7/ZsZjJWZE3rY\"",
    "mtime": "2026-11-01T06:53:11.569Z",
    "size": 90061,
    "path": "../public/hotel/img/mahi.f2e8dc74.jpg"
  },
  "/hotel/img/mirzaghasemi.aac99af4.jpg": {
    "type": "image/jpeg",
    "etag": "\"153c3-kpb3JUIG/UvxDOcuOdwZdxr5zq0\"",
    "mtime": "2026-11-01T06:53:11.571Z",
    "size": 86979,
    "path": "../public/hotel/img/mirzaghasemi.aac99af4.jpg"
  },
  "/hotel/img/logo-header.29ca394d.png": {
    "type": "image/png",
    "etag": "\"45074-nX61Oru1g7Vqw6fGYhFEjiziALQ\"",
    "mtime": "2026-11-01T06:53:11.568Z",
    "size": 282740,
    "path": "../public/hotel/img/logo-header.29ca394d.png"
  },
  "/hotel/img/qasemabadesofla_uspace_1636972998.d54022ac.jpg": {
    "type": "image/jpeg",
    "etag": "\"17b76-3p23baRy/tEnY9jZJgTNPTuIPXg\"",
    "mtime": "2026-11-01T06:53:11.573Z",
    "size": 97142,
    "path": "../public/hotel/img/qasemabadesofla_uspace_1636972998.d54022ac.jpg"
  },
  "/hotel/img/ramsar-villages.027cdc2c.jpg": {
    "type": "image/jpeg",
    "etag": "\"44ad3-btpiRjaCX0utVBAwjMQ62j7QTbg\"",
    "mtime": "2026-11-01T06:53:11.575Z",
    "size": 281299,
    "path": "../public/hotel/img/ramsar-villages.027cdc2c.jpg"
  },
  "/hotel/img/rules.f3b7bb2c.jpg": {
    "type": "image/jpeg",
    "etag": "\"106c8-ut5EHQjL4w7VAqVWDlq4DMC2iTI\"",
    "mtime": "2026-11-01T06:53:11.576Z",
    "size": 67272,
    "path": "../public/hotel/img/rules.f3b7bb2c.jpg"
  },
  "/hotel/img/standard-quality-control-concept-m.8671486b.jpg": {
    "type": "image/jpeg",
    "etag": "\"f9a2-DZMoPnmuxlKtMvtET082MLzc/n8\"",
    "mtime": "2026-11-01T06:53:11.578Z",
    "size": 63906,
    "path": "../public/hotel/img/standard-quality-control-concept-m.8671486b.jpg"
  },
  "/hotel/img/tech-support-1.4d563bad.jpg": {
    "type": "image/jpeg",
    "etag": "\"ec98-mSRYHNRR7Qu2ySfvte/FxRjGqAk\"",
    "mtime": "2026-11-01T06:53:11.579Z",
    "size": 60568,
    "path": "../public/hotel/img/tech-support-1.4d563bad.jpg"
  },
  "/hotel/img/telecabin.40c240f8.jpg": {
    "type": "image/jpeg",
    "etag": "\"3e18f-mj70SbW41ec0OLN426paEi0qXfQ\"",
    "mtime": "2026-11-01T06:53:11.580Z",
    "size": 254351,
    "path": "../public/hotel/img/telecabin.40c240f8.jpg"
  },
  "/hotel/img/time.5a03f39f.jpg": {
    "type": "image/jpeg",
    "etag": "\"9fc0-DdIFFfyiQ19DuLxXJGTiLsp/r1w\"",
    "mtime": "2026-11-01T06:53:11.581Z",
    "size": 40896,
    "path": "../public/hotel/img/time.5a03f39f.jpg"
  },
  "/hotel/img/آهوان-.b45f6389.jpg": {
    "type": "image/jpeg",
    "etag": "\"19ede-t27Bk3OvAhcfPHgdU3Ml6rTGCjI\"",
    "mtime": "2026-11-01T06:53:11.582Z",
    "size": 106206,
    "path": "../public/hotel/img/آهوان-.b45f6389.jpg"
  },
  "/hotel/img/اشکورات.cbd024e1.jpg": {
    "type": "image/jpeg",
    "etag": "\"7e1c-b3KCVxaFTpT6tB8bn6lAsaXpNJc\"",
    "mtime": "2026-11-01T06:53:11.583Z",
    "size": 32284,
    "path": "../public/hotel/img/اشکورات.cbd024e1.jpg"
  },
  "/hotel/img/بازار.6b4faa5a.jpg": {
    "type": "image/jpeg",
    "etag": "\"1e062-BkyDeNFDq4CdWu4Yw48asA7ZBCA\"",
    "mtime": "2026-11-01T06:53:11.584Z",
    "size": 122978,
    "path": "../public/hotel/img/بازار.6b4faa5a.jpg"
  },
  "/hotel/img/سفیداب.0cf3ae9b.jpg": {
    "type": "image/jpeg",
    "etag": "\"d199-tpo8f+Mk4UPojb3TTa++P/inMy4\"",
    "mtime": "2026-11-01T06:53:11.585Z",
    "size": 53657,
    "path": "../public/hotel/img/سفیداب.0cf3ae9b.jpg"
  },
  "/hotel/img/gif-arrow.1219d009.gif": {
    "type": "image/gif",
    "etag": "\"16e94f-Va/L0Whx9PD9TNGH4DjddKq0fG0\"",
    "mtime": "2026-11-01T06:53:11.558Z",
    "size": 1501519,
    "path": "../public/hotel/img/gif-arrow.1219d009.gif"
  },
  "/hotel/img/شیطان-کوه11.805c8a5b.jpg": {
    "type": "image/jpeg",
    "etag": "\"281f3-EHI4pfFh89/Gi9bt+GtZg/PwW4o\"",
    "mtime": "2026-11-01T06:53:11.587Z",
    "size": 164339,
    "path": "../public/hotel/img/شیطان-کوه11.805c8a5b.jpg"
  },
  "/hotel/img/قلعه-بندبن-قاسم-آباد-رودسر-قلعه-بندبن-قاسم-آباد-گیلان-مسیر-قلعه-بندبن-قلعه-بندبن-چابکسر-قلعه-بندبن-قاسم-آباد.f66c4baf.png": {
    "type": "image/png",
    "etag": "\"14768-OTP5eh9RTViIjYb8WZyKZ117BzI\"",
    "mtime": "2026-11-01T06:53:11.588Z",
    "size": 83816,
    "path": "../public/hotel/img/قلعه-بندبن-قاسم-آباد-رودسر-قلعه-بندبن-قاسم-آباد-گیلان-مسیر-قلعه-بندبن-قلعه-بندبن-چابکسر-قلعه-بندبن-قاسم-آباد.f66c4baf.png"
  },
  "/hotel/img/چمخاله.eb308746.jpg": {
    "type": "image/jpeg",
    "etag": "\"166de-MAsrH+8/qRhxrezU7dpENVB7L20\"",
    "mtime": "2026-11-01T06:53:11.589Z",
    "size": 91870,
    "path": "../public/hotel/img/چمخاله.eb308746.jpg"
  },
  "/hotel/js/143.286bb8a0.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"3125-OPjCLPZxMPHSWHwS2ILr8UA8dXI\"",
    "mtime": "2026-11-01T06:53:11.602Z",
    "size": 12581,
    "path": "../public/hotel/js/143.286bb8a0.js"
  },
  "/hotel/js/143.286bb8a0.js.map": {
    "type": "application/json",
    "etag": "\"3eba-c2RtouxTBcZWSFve7paB7Zn0ClM\"",
    "mtime": "2026-11-01T06:53:11.602Z",
    "size": 16058,
    "path": "../public/hotel/js/143.286bb8a0.js.map"
  },
  "/hotel/js/218.8edcfa94.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"202cf-mqOwNzzwBsbFOD6LkNxRFuEvHAQ\"",
    "mtime": "2026-11-01T06:53:11.604Z",
    "size": 131791,
    "path": "../public/hotel/js/218.8edcfa94.js"
  },
  "/hotel/js/257.93cfad9b.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"357d-evSXmW5mZiHUePsBpspbwAG6wBM\"",
    "mtime": "2026-11-01T06:53:11.607Z",
    "size": 13693,
    "path": "../public/hotel/js/257.93cfad9b.js"
  },
  "/hotel/js/257.93cfad9b.js.map": {
    "type": "application/json",
    "etag": "\"5a9a-SPb0XB+kViZ97l/D0pr+9ho/0jo\"",
    "mtime": "2026-11-01T06:53:11.608Z",
    "size": 23194,
    "path": "../public/hotel/js/257.93cfad9b.js.map"
  },
  "/hotel/js/279.4949b5f1.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"40de-Mr3a56/7xlWdGMLFJrvcnL8e3y8\"",
    "mtime": "2026-11-01T06:53:11.609Z",
    "size": 16606,
    "path": "../public/hotel/js/279.4949b5f1.js"
  },
  "/hotel/js/279.4949b5f1.js.map": {
    "type": "application/json",
    "etag": "\"66ba-tcPvyiHkjpu/UjD/CBH2MCX5ty0\"",
    "mtime": "2026-11-01T06:53:11.610Z",
    "size": 26298,
    "path": "../public/hotel/js/279.4949b5f1.js.map"
  },
  "/hotel/js/218.8edcfa94.js.map": {
    "type": "application/json",
    "etag": "\"69e0e-XnNUpM/8/rwX3MBTOKfOObMsBhY\"",
    "mtime": "2026-11-01T06:53:11.607Z",
    "size": 433678,
    "path": "../public/hotel/js/218.8edcfa94.js.map"
  },
  "/hotel/js/319.a9eb2f14.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"3330-1FljXQVdkpSCMqO9vC75yJY+kPM\"",
    "mtime": "2026-11-01T06:53:11.611Z",
    "size": 13104,
    "path": "../public/hotel/js/319.a9eb2f14.js"
  },
  "/hotel/js/319.a9eb2f14.js.map": {
    "type": "application/json",
    "etag": "\"cfdc-ucGMqHjr9ABypPoSfyKGzx27WRM\"",
    "mtime": "2026-11-01T06:53:11.612Z",
    "size": 53212,
    "path": "../public/hotel/js/319.a9eb2f14.js.map"
  },
  "/hotel/js/34.0b641d7f.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"2c64-91e3mwFyy4XsymjHr6KyzHxvAIE\"",
    "mtime": "2026-11-01T06:53:11.612Z",
    "size": 11364,
    "path": "../public/hotel/js/34.0b641d7f.js"
  },
  "/hotel/js/34.0b641d7f.js.map": {
    "type": "application/json",
    "etag": "\"3333-VVn+lLOHmHFvRLoDKxDlSzkQPwE\"",
    "mtime": "2026-11-01T06:53:11.613Z",
    "size": 13107,
    "path": "../public/hotel/js/34.0b641d7f.js.map"
  },
  "/hotel/js/411.ef2aef98.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"695a-bJH/9VewpTpyrK3bGt9L23YdFzk\"",
    "mtime": "2026-11-01T06:53:11.613Z",
    "size": 26970,
    "path": "../public/hotel/js/411.ef2aef98.js"
  },
  "/hotel/js/411.ef2aef98.js.map": {
    "type": "application/json",
    "etag": "\"bd44-SZHeQiYpOfrqjWcRaXIZUAt009o\"",
    "mtime": "2026-11-01T06:53:11.614Z",
    "size": 48452,
    "path": "../public/hotel/js/411.ef2aef98.js.map"
  },
  "/hotel/js/453.fcfcc60c.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"2d9e-v2kGgHHX0FEPJars0na7ty1g4zo\"",
    "mtime": "2026-11-01T06:53:11.615Z",
    "size": 11678,
    "path": "../public/hotel/js/453.fcfcc60c.js"
  },
  "/hotel/img/کروکی1.ef641847.jpg": {
    "type": "image/jpeg",
    "etag": "\"b2695-HqtRk4ah29NPaRZsirO4AbV9QIo\"",
    "mtime": "2026-11-01T06:53:11.594Z",
    "size": 730773,
    "path": "../public/hotel/img/کروکی1.ef641847.jpg"
  },
  "/hotel/img/کروکی2.03e27c61.jpg": {
    "type": "image/jpeg",
    "etag": "\"ae9d2-pxbaabuEXCAgZLClNjoO++MJxY0\"",
    "mtime": "2026-11-01T06:53:11.600Z",
    "size": 715218,
    "path": "../public/hotel/img/کروکی2.03e27c61.jpg"
  },
  "/hotel/js/453.fcfcc60c.js.map": {
    "type": "application/json",
    "etag": "\"370c-5Ba8Aa2NjJvmNne5i8FmY+3nRBc\"",
    "mtime": "2026-11-01T06:53:11.615Z",
    "size": 14092,
    "path": "../public/hotel/js/453.fcfcc60c.js.map"
  },
  "/hotel/js/543.a8f4071a.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"33de-xeLn12yxtxXQX/WG+HuaTdKsqcA\"",
    "mtime": "2026-11-01T06:53:11.616Z",
    "size": 13278,
    "path": "../public/hotel/js/543.a8f4071a.js"
  },
  "/hotel/js/543.a8f4071a.js.map": {
    "type": "application/json",
    "etag": "\"442f-rFSPpddFlAekc+eAdkJ1inUE1V4\"",
    "mtime": "2026-11-01T06:53:11.617Z",
    "size": 17455,
    "path": "../public/hotel/js/543.a8f4071a.js.map"
  },
  "/hotel/js/643.a6bc499c.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"35d0-K2c6HrNTux2t7OGKRBa7HYihdfU\"",
    "mtime": "2026-11-01T06:53:11.617Z",
    "size": 13776,
    "path": "../public/hotel/js/643.a6bc499c.js"
  },
  "/hotel/js/643.a6bc499c.js.map": {
    "type": "application/json",
    "etag": "\"5111-T0DbhRqHqXzQdlpND4RcSkJUnsI\"",
    "mtime": "2026-11-01T06:53:11.618Z",
    "size": 20753,
    "path": "../public/hotel/js/643.a6bc499c.js.map"
  },
  "/hotel/js/848.112f9be8.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"3de7-JrMWueGJxVdmclFn+frsAPfhCZ4\"",
    "mtime": "2026-11-01T06:53:11.619Z",
    "size": 15847,
    "path": "../public/hotel/js/848.112f9be8.js"
  },
  "/hotel/js/848.112f9be8.js.map": {
    "type": "application/json",
    "etag": "\"580c-bYWF00witIr1WCdxzGk/sODOuLA\"",
    "mtime": "2026-11-01T06:53:11.619Z",
    "size": 22540,
    "path": "../public/hotel/js/848.112f9be8.js.map"
  },
  "/hotel/js/854.42330027.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"2fe-n8hBaKM6JoOPu00VqlEd1XuMKu0\"",
    "mtime": "2026-11-01T06:53:11.620Z",
    "size": 766,
    "path": "../public/hotel/js/854.42330027.js"
  },
  "/hotel/js/854.42330027.js.map": {
    "type": "application/json",
    "etag": "\"d40-Ebs99WSXUU9Cq7+B0p8Xo0lLZ+g\"",
    "mtime": "2026-11-01T06:53:11.620Z",
    "size": 3392,
    "path": "../public/hotel/js/854.42330027.js.map"
  },
  "/hotel/js/984.d4bb0a2e.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"3cce-t1KRczvXk/gPFy+G5DOJTRPMut8\"",
    "mtime": "2026-11-01T06:53:11.621Z",
    "size": 15566,
    "path": "../public/hotel/js/984.d4bb0a2e.js"
  },
  "/hotel/js/984.d4bb0a2e.js.map": {
    "type": "application/json",
    "etag": "\"66f4-jhzOP04XClO/Z9TF5f1VdoZwfhU\"",
    "mtime": "2026-11-01T06:53:11.622Z",
    "size": 26356,
    "path": "../public/hotel/js/984.d4bb0a2e.js.map"
  },
  "/hotel/js/app.67c841ed.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"6cd2-mhMD1M9UWtsoxLtQ65MvCD0Rbrk\"",
    "mtime": "2026-11-01T06:53:11.623Z",
    "size": 27858,
    "path": "../public/hotel/js/app.67c841ed.js"
  },
  "/hotel/js/app.67c841ed.js.map": {
    "type": "application/json",
    "etag": "\"1b682-exjzhWlvpngob8rbkSziJ/Xjh5E\"",
    "mtime": "2026-11-01T06:53:11.624Z",
    "size": 112258,
    "path": "../public/hotel/js/app.67c841ed.js.map"
  },
  "/hotel/pdf/اسپانیا - ایتالیا - ترکیه.pdf": {
    "type": "application/pdf",
    "etag": "\"68ce6-nnCa3N/bDIchQxYgWtCZ8GWPCaE\"",
    "mtime": "2026-11-01T06:53:11.650Z",
    "size": 429286,
    "path": "../public/hotel/pdf/اسپانیا - ایتالیا - ترکیه.pdf"
  },
  "/hotel/pdf/اسپانیا - ترکیه.pdf": {
    "type": "application/pdf",
    "etag": "\"67f1e-6xbHQ6nmkFKXKxPUmn2YvyLvSd8\"",
    "mtime": "2026-11-01T06:53:11.653Z",
    "size": 425758,
    "path": "../public/hotel/pdf/اسپانیا - ترکیه.pdf"
  },
  "/hotel/pdf/سوئیس - ایتالیا - امارات.pdf": {
    "type": "application/pdf",
    "etag": "\"65f9a-anXAsTGIPWEuVXwDLO7taecaEs4\"",
    "mtime": "2026-11-01T06:53:11.656Z",
    "size": 417690,
    "path": "../public/hotel/pdf/سوئیس - ایتالیا - امارات.pdf"
  },
  "/hotel/pdf/سوئیس - ترکیه.pdf": {
    "type": "application/pdf",
    "etag": "\"6580a-wMVy/P/NtwlDRP99l6IZPSn5xGo\"",
    "mtime": "2026-11-01T06:53:11.659Z",
    "size": 415754,
    "path": "../public/hotel/pdf/سوئیس - ترکیه.pdf"
  },
  "/hotel/pdf/سوئیس - فرانسه - امارات.jpeg": {
    "type": "image/jpeg",
    "etag": "\"1556d-oqfC0xoMMej0NOLMCPaiWS+LAM4\"",
    "mtime": "2026-11-01T06:53:11.660Z",
    "size": 87405,
    "path": "../public/hotel/pdf/سوئیس - فرانسه - امارات.jpeg"
  },
  "/hotel/pdf/سوئیس+اتریش+اسلواکی+مجارستان+امارات.jpeg": {
    "type": "image/jpeg",
    "etag": "\"15c21-qVo4JS2sxnt6FaX6awImzpgPhRg\"",
    "mtime": "2026-11-01T06:53:11.686Z",
    "size": 89121,
    "path": "../public/hotel/pdf/سوئیس+اتریش+اسلواکی+مجارستان+امارات.jpeg"
  },
  "/hotel/pdf/فرانسه + ایتالیا + امارات.jpeg": {
    "type": "image/jpeg",
    "etag": "\"14bcd-MTY/dMh0bPsbJM9s7FNpg27JZzQ\"",
    "mtime": "2026-11-01T06:53:11.687Z",
    "size": 84941,
    "path": "../public/hotel/pdf/فرانسه + ایتالیا + امارات.jpeg"
  },
  "/hotel/pdf/فرانسه - اسپانیا - امارات.jpeg": {
    "type": "image/jpeg",
    "etag": "\"15037-ATLjj59cGMb9tExGCu1Ab/vDXfU\"",
    "mtime": "2026-11-01T06:53:11.688Z",
    "size": 86071,
    "path": "../public/hotel/pdf/فرانسه - اسپانیا - امارات.jpeg"
  },
  "/hotel/pdf/فرانسه - اسپانیا - امارات.pdf": {
    "type": "application/pdf",
    "etag": "\"67f6e-evgRfxe6Q0KI3X8oTih4YcNVeeY\"",
    "mtime": "2026-11-01T06:53:11.692Z",
    "size": 425838,
    "path": "../public/hotel/pdf/فرانسه - اسپانیا - امارات.pdf"
  },
  "/hotel/pdf/فرانسه - ایتالیا - اسپانیا - امارات-2.jpeg": {
    "type": "image/jpeg",
    "etag": "\"1783c-b9z8E0KwJy4VtNdC/QsT+tw4+n4\"",
    "mtime": "2026-11-01T06:53:11.693Z",
    "size": 96316,
    "path": "../public/hotel/pdf/فرانسه - ایتالیا - اسپانیا - امارات-2.jpeg"
  },
  "/hotel/js/chunk-vendors.6730430e.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"c233f-8CQUYJP2OygeRh76sGV32cqowsI\"",
    "mtime": "2026-11-01T06:53:11.629Z",
    "size": 795455,
    "path": "../public/hotel/js/chunk-vendors.6730430e.js"
  },
  "/hotel/pdf/فرانسه - ایتالیا - اسپانیا - امارات.jpeg": {
    "type": "image/jpeg",
    "etag": "\"17b05-JoSs9d8cdZihjPZk9j0Q3RLMjBA\"",
    "mtime": "2026-11-01T06:53:11.695Z",
    "size": 97029,
    "path": "../public/hotel/pdf/فرانسه - ایتالیا - اسپانیا - امارات.jpeg"
  },
  "/hotel/pdf/فرانسه - بلژیک - هلند - امارات.jpeg": {
    "type": "image/jpeg",
    "etag": "\"15ad1-CO4IAmXhaeyOlrxTSZxvYdmzxfY\"",
    "mtime": "2026-11-01T06:53:11.696Z",
    "size": 88785,
    "path": "../public/hotel/pdf/فرانسه - بلژیک - هلند - امارات.jpeg"
  },
  "/hotel/pdf/فرانسه+سوئیس+ایتالیا+امارات.jpeg": {
    "type": "image/jpeg",
    "etag": "\"151a6-H8QEi/WX5F52RJNgku4ocF7BcyI\"",
    "mtime": "2026-11-01T06:53:11.697Z",
    "size": 86438,
    "path": "../public/hotel/pdf/فرانسه+سوئیس+ایتالیا+امارات.jpeg"
  },
  "/hotel/pdf/فرانسه-امارات.jpeg": {
    "type": "image/jpeg",
    "etag": "\"142d7-YJE13fLlRSWdSq4FwDbw+rrt9eE\"",
    "mtime": "2026-11-01T06:53:11.698Z",
    "size": 82647,
    "path": "../public/hotel/pdf/فرانسه-امارات.jpeg"
  },
  "/hotel/pdf/فرانسه-امارات.pdf": {
    "type": "application/pdf",
    "etag": "\"63eb0-+q3RlvNrh/msVNpw1YCzffAEV3k\"",
    "mtime": "2026-11-01T06:53:11.702Z",
    "size": 409264,
    "path": "../public/hotel/pdf/فرانسه-امارات.pdf"
  },
  "/hotel/pdf/پکیج مسکو-سنت پترزبورگ.pdf": {
    "type": "application/pdf",
    "etag": "\"2b2f0-y+pBC3kHGUYP6Bq4/ABV9k34jHc\"",
    "mtime": "2026-11-01T06:53:11.745Z",
    "size": 176880,
    "path": "../public/hotel/pdf/پکیج مسکو-سنت پترزبورگ.pdf"
  },
  "/icons/menu/appetizer.png": {
    "type": "image/png",
    "etag": "\"c13c-n0+Ix4a62v6qT48KGZOOgj7GV0w\"",
    "mtime": "2026-11-09T06:58:04.672Z",
    "size": 49468,
    "path": "../public/icons/menu/appetizer.png"
  },
  "/icons/menu/appetizer.svg": {
    "type": "image/svg+xml",
    "etag": "\"268f-KGQp6MYQd60StzX/u+VU4872roM\"",
    "mtime": "2026-11-09T06:58:04.673Z",
    "size": 9871,
    "path": "../public/icons/menu/appetizer.svg"
  },
  "/icons/menu/coffee.png": {
    "type": "image/png",
    "etag": "\"9c36-/pbwcH4VDBjYG+mBZCmpsa6Ot18\"",
    "mtime": "2026-11-09T06:58:04.674Z",
    "size": 39990,
    "path": "../public/icons/menu/coffee.png"
  },
  "/icons/menu/coffee.svg": {
    "type": "image/svg+xml",
    "etag": "\"19d6-qSRXoUPIJ+plQIAIjBPlMvCgek8\"",
    "mtime": "2026-11-09T06:58:04.675Z",
    "size": 6614,
    "path": "../public/icons/menu/coffee.svg"
  },
  "/icons/menu/cold-drinks.png": {
    "type": "image/png",
    "etag": "\"9607-TkwLFX3ZooCSLmL1yj99fBUJf8c\"",
    "mtime": "2026-11-09T06:58:04.676Z",
    "size": 38407,
    "path": "../public/icons/menu/cold-drinks.png"
  },
  "/icons/menu/cold-drinks.svg": {
    "type": "image/svg+xml",
    "etag": "\"1786-JTNTJk574mLExN9PRL0o7zxjF4U\"",
    "mtime": "2026-11-09T06:58:04.676Z",
    "size": 6022,
    "path": "../public/icons/menu/cold-drinks.svg"
  },
  "/icons/menu/dessert.png": {
    "type": "image/png",
    "etag": "\"a5c0-QCifixVqvenbOWaodKoacR1PAxA\"",
    "mtime": "2026-11-09T06:58:04.677Z",
    "size": 42432,
    "path": "../public/icons/menu/dessert.png"
  },
  "/icons/menu/dessert.svg": {
    "type": "image/svg+xml",
    "etag": "\"210f-MfYBN7TY6L+cmmZ2jUy0PVyyZrc\"",
    "mtime": "2026-11-09T06:58:04.678Z",
    "size": 8463,
    "path": "../public/icons/menu/dessert.svg"
  },
  "/icons/menu/drinks.png": {
    "type": "image/png",
    "etag": "\"7e9c-a3j1BHw+yZXuj0Bgs/raXjOgbes\"",
    "mtime": "2026-11-09T06:58:04.679Z",
    "size": 32412,
    "path": "../public/icons/menu/drinks.png"
  },
  "/icons/menu/drinks.svg": {
    "type": "image/svg+xml",
    "etag": "\"162e-Useym8OzJge8iF9VIKQES/rqLv8\"",
    "mtime": "2026-11-09T06:58:04.679Z",
    "size": 5678,
    "path": "../public/icons/menu/drinks.svg"
  },
  "/icons/menu/frappe.png": {
    "type": "image/png",
    "etag": "\"88a7-Li24yW3qBl6z9ERANKV61B+XFTk\"",
    "mtime": "2026-11-09T06:58:04.682Z",
    "size": 34983,
    "path": "../public/icons/menu/frappe.png"
  },
  "/icons/menu/frappe.svg": {
    "type": "image/svg+xml",
    "etag": "\"17a7-mkTnhzM46dQ1f2CZghVYUPXkJQU\"",
    "mtime": "2026-11-09T06:58:04.682Z",
    "size": 6055,
    "path": "../public/icons/menu/frappe.svg"
  },
  "/icons/menu/fried.png": {
    "type": "image/png",
    "etag": "\"9b28-6psfyIj5KdT6ss9oMnpoHfCKdfk\"",
    "mtime": "2026-11-09T06:58:04.683Z",
    "size": 39720,
    "path": "../public/icons/menu/fried.png"
  },
  "/icons/menu/fried.svg": {
    "type": "image/svg+xml",
    "etag": "\"1a67-gJ8DL5X30oCuBMq0+XA+IHtoIRQ\"",
    "mtime": "2026-11-09T06:58:04.684Z",
    "size": 6759,
    "path": "../public/icons/menu/fried.svg"
  },
  "/icons/menu/hot-drinks.png": {
    "type": "image/png",
    "etag": "\"9b06-diDjaNCw0x0c0/wuPzePBOz0HW4\"",
    "mtime": "2026-11-09T06:58:04.685Z",
    "size": 39686,
    "path": "../public/icons/menu/hot-drinks.png"
  },
  "/icons/menu/hot-drinks.svg": {
    "type": "image/svg+xml",
    "etag": "\"168d-l1H/E4lPxbgUi42gC69GrC50tDg\"",
    "mtime": "2026-11-09T06:58:04.685Z",
    "size": 5773,
    "path": "../public/icons/menu/hot-drinks.svg"
  },
  "/icons/menu/ice-coffee.png": {
    "type": "image/png",
    "etag": "\"a728-HSdwIY86ZjZrhS4G5I+yCZC4DIo\"",
    "mtime": "2026-11-09T06:58:04.686Z",
    "size": 42792,
    "path": "../public/icons/menu/ice-coffee.png"
  },
  "/hotel/pdf/مدارک سفارت کانادا.pdf": {
    "type": "application/pdf",
    "etag": "\"14729b-GC4yGbMYERHjgK48PfgLT2Gv7IY\"",
    "mtime": "2026-11-01T06:53:11.744Z",
    "size": 1340059,
    "path": "../public/hotel/pdf/مدارک سفارت کانادا.pdf"
  },
  "/hotel/js/chunk-vendors.6730430e.js.map": {
    "type": "application/json",
    "etag": "\"304f60-NQVQQHkmpfcTc5rMR3TUH7bM1bc\"",
    "mtime": "2026-11-01T06:53:11.646Z",
    "size": 3166048,
    "path": "../public/hotel/js/chunk-vendors.6730430e.js.map"
  },
  "/hotel/pdf/مدارک سفارت انگلستان.pdf": {
    "type": "application/pdf",
    "etag": "\"1915ba-OaHHA72ye6dWJGdQAhb/KNZ6Txw\"",
    "mtime": "2026-11-01T06:53:11.734Z",
    "size": 1643962,
    "path": "../public/hotel/pdf/مدارک سفارت انگلستان.pdf"
  },
  "/hotel/pdf/سوئیس - فرانسه - امارات.pdf": {
    "type": "application/pdf",
    "etag": "\"397df1-1U7Kd0Rw6e16m4EAVaTRbJKxXng\"",
    "mtime": "2026-11-01T06:53:11.684Z",
    "size": 3767793,
    "path": "../public/hotel/pdf/سوئیس - فرانسه - امارات.pdf"
  },
  "/icons/menu/icecream.svg": {
    "type": "image/svg+xml",
    "etag": "\"21cb-uHuOJUu8j0uik0B/HsUlMFAaTvs\"",
    "mtime": "2026-11-09T06:58:04.688Z",
    "size": 8651,
    "path": "../public/icons/menu/icecream.svg"
  },
  "/icons/menu/icecream.png": {
    "type": "image/png",
    "etag": "\"a91f-nRC+BKQCdYJCRwRMTjZ7JRMz6Yc\"",
    "mtime": "2026-11-09T06:58:04.688Z",
    "size": 43295,
    "path": "../public/icons/menu/icecream.png"
  },
  "/icons/menu/ice-coffee.svg": {
    "type": "image/svg+xml",
    "etag": "\"1bb4-edNJcCZRtxHNoYaSTDzgKu6w6tg\"",
    "mtime": "2026-11-09T06:58:04.687Z",
    "size": 7092,
    "path": "../public/icons/menu/ice-coffee.svg"
  },
  "/icons/menu/kebab.png": {
    "type": "image/png",
    "etag": "\"b6e0-XSA18/LwVgzycLE/+oFqrwDHAYs\"",
    "mtime": "2026-11-09T06:58:04.689Z",
    "size": 46816,
    "path": "../public/icons/menu/kebab.png"
  },
  "/icons/menu/kebab.svg": {
    "type": "image/svg+xml",
    "etag": "\"19ea-MY/3AvHmuYxSfq2Ur14Pu+2IYt8\"",
    "mtime": "2026-11-09T06:58:04.690Z",
    "size": 6634,
    "path": "../public/icons/menu/kebab.svg"
  },
  "/icons/menu/main.png": {
    "type": "image/png",
    "etag": "\"a771-BK0TwlyqsnHsnV4OucikY2H/qVU\"",
    "mtime": "2026-11-09T06:58:04.691Z",
    "size": 42865,
    "path": "../public/icons/menu/main.png"
  },
  "/icons/menu/main.svg": {
    "type": "image/svg+xml",
    "etag": "\"2820-wPhc7xK++DcyP4BAddpp2ECUzHU\"",
    "mtime": "2026-11-09T06:58:04.691Z",
    "size": 10272,
    "path": "../public/icons/menu/main.svg"
  },
  "/icons/menu/pasta.png": {
    "type": "image/png",
    "etag": "\"b4f2-sEcxsm4y77yEtZ4sseuEcjgRd/M\"",
    "mtime": "2026-11-09T06:58:04.696Z",
    "size": 46322,
    "path": "../public/icons/menu/pasta.png"
  },
  "/icons/menu/pasta.svg": {
    "type": "image/svg+xml",
    "etag": "\"2a06-4gr6NvPwwK4lPPknNm7GmBpA78M\"",
    "mtime": "2026-11-09T06:58:04.697Z",
    "size": 10758,
    "path": "../public/icons/menu/pasta.svg"
  },
  "/icons/menu/pizza.png": {
    "type": "image/png",
    "etag": "\"cf4e-uJbjO0m3Sacb1lCCcxE6qxtOvNI\"",
    "mtime": "2026-11-09T06:58:04.698Z",
    "size": 53070,
    "path": "../public/icons/menu/pizza.png"
  },
  "/icons/menu/README.txt": {
    "type": "text/plain; charset=utf-8",
    "etag": "\"199-SOVZHD/x7+FrtoheIHqRp8zaViY\"",
    "mtime": "2026-11-09T06:58:04.672Z",
    "size": 409,
    "path": "../public/icons/menu/README.txt"
  },
  "/icons/menu/pizza.svg": {
    "type": "image/svg+xml",
    "etag": "\"2f2d-tYjtRYWhH4BZBZBSWPmUnkUyz9w\"",
    "mtime": "2026-11-09T06:58:04.699Z",
    "size": 12077,
    "path": "../public/icons/menu/pizza.svg"
  },
  "/icons/menu/salad.png": {
    "type": "image/png",
    "etag": "\"bbd5-Hvx/+RZlHNGQPw/Ys0+4EwX4z8o\"",
    "mtime": "2026-11-09T06:58:04.700Z",
    "size": 48085,
    "path": "../public/icons/menu/salad.png"
  },
  "/icons/menu/salad.svg": {
    "type": "image/svg+xml",
    "etag": "\"2986-nI9JacGSSlKTWuooU+oPKiPLY9I\"",
    "mtime": "2026-11-09T06:58:04.700Z",
    "size": 10630,
    "path": "../public/icons/menu/salad.svg"
  },
  "/icons/menu/order.png": {
    "type": "image/png",
    "etag": "\"bd893-X92S3LlUNgVK7vOwsbX3YYl/lY8\"",
    "mtime": "2026-11-09T06:58:04.695Z",
    "size": 776339,
    "path": "../public/icons/menu/order.png"
  },
  "/icons/menu/sandwich.png": {
    "type": "image/png",
    "etag": "\"7396-htbfUHMwWNcHRWnxGoSQnSZA55o\"",
    "mtime": "2026-11-09T06:58:04.701Z",
    "size": 29590,
    "path": "../public/icons/menu/sandwich.png"
  },
  "/hotel/pdf/فرم درخواست ویزای سفارت کانادا.pdf": {
    "type": "application/pdf",
    "etag": "\"328e7d-wBt5Sp+77w7kOqvCyyI/P1h4Tjs\"",
    "mtime": "2026-11-01T06:53:11.720Z",
    "size": 3313277,
    "path": "../public/hotel/pdf/فرم درخواست ویزای سفارت کانادا.pdf"
  },
  "/icons/menu/sandwich.svg": {
    "type": "image/svg+xml",
    "etag": "\"1e54-HG4li+yVgzhbNWm7xlYOZp4E5HY\"",
    "mtime": "2026-11-09T06:58:04.702Z",
    "size": 7764,
    "path": "../public/icons/menu/sandwich.svg"
  },
  "/hotel/pdf/گرندتور سوئیس.pdf": {
    "type": "application/pdf",
    "etag": "\"370f3b-FIGcwIp+T/Wf4qnPE3B44PnMpz4\"",
    "mtime": "2026-11-01T06:53:11.770Z",
    "size": 3608379,
    "path": "../public/hotel/pdf/گرندتور سوئیس.pdf"
  },
  "/icons/menu/shake.png": {
    "type": "image/png",
    "etag": "\"9d7e-wlJtYkVjwwYx2f+TGS/IfHfT5cg\"",
    "mtime": "2026-11-09T06:58:04.703Z",
    "size": 40318,
    "path": "../public/icons/menu/shake.png"
  },
  "/icons/menu/shake.svg": {
    "type": "image/svg+xml",
    "etag": "\"1f14-yNG1Icjb8OgAGUtqJcx96oUV+dQ\"",
    "mtime": "2026-11-09T06:58:04.703Z",
    "size": 7956,
    "path": "../public/icons/menu/shake.svg"
  },
  "/icons/menu/smoothie.png": {
    "type": "image/png",
    "etag": "\"a26b-bIZLpjKu+ps2G33DeS3CBHgoOdo\"",
    "mtime": "2026-11-09T06:58:04.704Z",
    "size": 41579,
    "path": "../public/icons/menu/smoothie.png"
  },
  "/icons/menu/smoothie.svg": {
    "type": "image/svg+xml",
    "etag": "\"1c9e-NP9ffL9dUl5iOTPLq1Z+YymVkt4\"",
    "mtime": "2026-11-09T06:58:04.705Z",
    "size": 7326,
    "path": "../public/icons/menu/smoothie.svg"
  },
  "/imgs/flight/Ahoo.png": {
    "type": "image/png",
    "etag": "\"ac0-UztWSUTqgT7G2bpn1v33ioVQZF4\"",
    "mtime": "2026-11-01T06:39:54.095Z",
    "size": 2752,
    "path": "../public/imgs/flight/Ahoo.png"
  },
  "/imgs/flight/background-profile.png": {
    "type": "image/png",
    "etag": "\"202b7-TbWmUEIywO/lJ5cL+08Qz+xP1gg\"",
    "mtime": "2026-08-22T08:50:43.178Z",
    "size": 131767,
    "path": "../public/imgs/flight/background-profile.png"
  },
  "/imgs/flight/header logo.png": {
    "type": "image/png",
    "etag": "\"2ec5-jvtlULAn7mv8/RhtxLjdrHDL74I\"",
    "mtime": "2026-11-01T06:39:55.066Z",
    "size": 11973,
    "path": "../public/imgs/flight/header logo.png"
  },
  "/imgs/flight/header.png": {
    "type": "image/png",
    "etag": "\"bb7c-z488cQzw6oIua4kVRsVZX795VfU\"",
    "mtime": "2026-07-13T06:00:39.854Z",
    "size": 47996,
    "path": "../public/imgs/flight/header.png"
  },
  "/imgs/header/logo.png": {
    "type": "image/png",
    "etag": "\"15d68-C36XfMFcX09MoJ437YQyYqzzhIA\"",
    "mtime": "2026-07-13T06:00:39.857Z",
    "size": 89448,
    "path": "../public/imgs/header/logo.png"
  },
  "/imgs/hotel/about-us.jpg": {
    "type": "image/jpeg",
    "etag": "\"56c15-t1PujJNrr4Ry858AkB268637FrY\"",
    "mtime": "2026-09-05T08:34:30.990Z",
    "size": 355349,
    "path": "../public/imgs/hotel/about-us.jpg"
  },
  "/imgs/hotel/ca.png": {
    "type": "image/png",
    "etag": "\"e726-j5vtCDFTMZOfoHmxUPaEuhcFuiA\"",
    "mtime": "2026-10-20T08:31:16.847Z",
    "size": 59174,
    "path": "../public/imgs/hotel/ca.png"
  },
  "/imgs/hotel/cabaner.png": {
    "type": "image/png",
    "etag": "\"66499-q9n5/OI/kYO0Vl8W504+SY8PjwY\"",
    "mtime": "2026-10-20T08:31:16.852Z",
    "size": 418969,
    "path": "../public/imgs/hotel/cabaner.png"
  },
  "/imgs/hotel/cao.png": {
    "type": "image/png",
    "etag": "\"67e2-cclxTvvl6elLfjjFtBOLJrRmWtA\"",
    "mtime": "2026-09-05T08:34:30.991Z",
    "size": 26594,
    "path": "../public/imgs/hotel/cao.png"
  },
  "/imgs/hotel/caslider.png": {
    "type": "image/png",
    "etag": "\"66499-q9n5/OI/kYO0Vl8W504+SY8PjwY\"",
    "mtime": "2026-10-20T08:31:16.855Z",
    "size": 418969,
    "path": "../public/imgs/hotel/caslider.png"
  },
  "/imgs/hotel/england1.png": {
    "type": "image/png",
    "etag": "\"42a0-UWK157wNCAXFkEACsUKhPnU8B8g\"",
    "mtime": "2026-10-20T08:31:17.024Z",
    "size": 17056,
    "path": "../public/imgs/hotel/england1.png"
  },
  "/imgs/hotel/england2.png": {
    "type": "image/png",
    "etag": "\"4b5c-nxUnaK2AQvTNmxRFYuJls2tcTLg\"",
    "mtime": "2026-10-20T08:31:17.026Z",
    "size": 19292,
    "path": "../public/imgs/hotel/england2.png"
  },
  "/imgs/hotel/england3.png": {
    "type": "image/png",
    "etag": "\"4a34-SvxmXPmPnZWuS/eRJpN2hVRGdQc\"",
    "mtime": "2026-10-20T08:31:17.027Z",
    "size": 18996,
    "path": "../public/imgs/hotel/england3.png"
  },
  "/imgs/hotel/eu.png": {
    "type": "image/png",
    "etag": "\"142f8-ocCux30OZlS1QiuUvsCh2yJA0/g\"",
    "mtime": "2026-10-20T08:31:17.031Z",
    "size": 82680,
    "path": "../public/imgs/hotel/eu.png"
  },
  "/imgs/hotel/eubaner.png": {
    "type": "image/png",
    "etag": "\"7e66c-Ot0xz5dCR+07EawFpfMqUU8Q5zs\"",
    "mtime": "2026-10-20T08:31:17.037Z",
    "size": 517740,
    "path": "../public/imgs/hotel/eubaner.png"
  },
  "/imgs/hotel/euslider.png": {
    "type": "image/png",
    "etag": "\"7e66c-Ot0xz5dCR+07EawFpfMqUU8Q5zs\"",
    "mtime": "2026-10-20T08:31:17.040Z",
    "size": 517740,
    "path": "../public/imgs/hotel/euslider.png"
  },
  "/imgs/hotel/hotel-main-page-1.jpg": {
    "type": "image/jpeg",
    "etag": "\"9147-tmgMM7RzLNg2wY23A4OrvnJKnoo\"",
    "mtime": "2026-09-05T08:34:30.992Z",
    "size": 37191,
    "path": "../public/imgs/hotel/hotel-main-page-1.jpg"
  },
  "/imgs/hotel/hotel-main-page-2.jpg": {
    "type": "image/jpeg",
    "etag": "\"19dd4-l4ID1Na+yl6Tq2lxHhScH8f21oE\"",
    "mtime": "2026-09-05T08:34:30.993Z",
    "size": 105940,
    "path": "../public/imgs/hotel/hotel-main-page-2.jpg"
  },
  "/imgs/hotel/hotel-main-page-3.jpg": {
    "type": "image/jpeg",
    "etag": "\"285e9-mAOdhmFQu/0aC0eoaKXBeXM7Pg0\"",
    "mtime": "2026-09-05T08:34:30.995Z",
    "size": 165353,
    "path": "../public/imgs/hotel/hotel-main-page-3.jpg"
  },
  "/imgs/hotel/knews.png": {
    "type": "image/png",
    "etag": "\"41963-YICkLX3rNXwoP8Eju9f5lJcpVtI\"",
    "mtime": "2026-09-05T08:34:30.996Z",
    "size": 268643,
    "path": "../public/imgs/hotel/knews.png"
  },
  "/imgs/hotel/knews1.png": {
    "type": "image/png",
    "etag": "\"14a83-RLuro/jp04W2PO2Gm8A9TzE8a84\"",
    "mtime": "2026-09-05T08:34:30.997Z",
    "size": 84611,
    "path": "../public/imgs/hotel/knews1.png"
  },
  "/imgs/hotel/knews2.png": {
    "type": "image/png",
    "etag": "\"13dc0-ocGbg/sj8VMyWvK03bcJxLtJoj4\"",
    "mtime": "2026-09-05T08:34:30.998Z",
    "size": 81344,
    "path": "../public/imgs/hotel/knews2.png"
  },
  "/imgs/flight/puzzled_stag_animated_original_color.gif": {
    "type": "image/gif",
    "etag": "\"1dac2f-fSPQYcSErTuLdmFj+69mvJxK+5c\"",
    "mtime": "2026-11-01T06:39:55.088Z",
    "size": 1944623,
    "path": "../public/imgs/flight/puzzled_stag_animated_original_color.gif"
  },
  "/imgs/hotel/knews3.png": {
    "type": "image/png",
    "etag": "\"1eeab-zR5l7PY+mNfDEUBQk2VUBx3XDvM\"",
    "mtime": "2026-09-05T08:34:30.999Z",
    "size": 126635,
    "path": "../public/imgs/hotel/knews3.png"
  },
  "/imgs/hotel/knews4.png": {
    "type": "image/png",
    "etag": "\"14660-ZnYMusHOadxOxgOyoYBMGjNIR1w\"",
    "mtime": "2026-09-05T08:34:31.000Z",
    "size": 83552,
    "path": "../public/imgs/hotel/knews4.png"
  },
  "/imgs/hotel/logo (1).png": {
    "type": "image/png",
    "etag": "\"96f-MdLBU8obYR3Ay7DP8YH+6d+bHko\"",
    "mtime": "2026-09-05T08:34:31.001Z",
    "size": 2415,
    "path": "../public/imgs/hotel/logo (1).png"
  },
  "/imgs/hotel/logo.png": {
    "type": "image/png",
    "etag": "\"23f2-Kk/51nr61TpeQIz7CxVqyL8GCDU\"",
    "mtime": "2026-09-05T08:34:31.001Z",
    "size": 9202,
    "path": "../public/imgs/hotel/logo.png"
  },
  "/imgs/hotel/lohoaira.png": {
    "type": "image/png",
    "etag": "\"dad-N4tuEvx7KmRHo6XoexgseW3ohQY\"",
    "mtime": "2026-09-05T08:34:31.002Z",
    "size": 3501,
    "path": "../public/imgs/hotel/lohoaira.png"
  },
  "/imgs/hotel/customer-rights.png": {
    "type": "image/png",
    "etag": "\"1a669d-LhTH56ROwdd8lnXrOeKNZ1OrxSs\"",
    "mtime": "2026-10-20T08:31:17.023Z",
    "size": 1730205,
    "path": "../public/imgs/hotel/customer-rights.png"
  },
  "/imgs/hotel/Passenger.png": {
    "type": "image/png",
    "etag": "\"5248-MdxaH0aSTJFHF4NXTQwz+h0QwnA\"",
    "mtime": "2026-09-05T08:34:30.986Z",
    "size": 21064,
    "path": "../public/imgs/hotel/Passenger.png"
  },
  "/imgs/hotel/suggest-hotel-main-page-1.svg": {
    "type": "image/svg+xml",
    "etag": "\"7a9b1-Jlnm8h16PPBWIIrff8SkzM8vfQ4\"",
    "mtime": "2026-09-05T08:34:31.007Z",
    "size": 502193,
    "path": "../public/imgs/hotel/suggest-hotel-main-page-1.svg"
  },
  "/imgs/hotel/contactus.jpg": {
    "type": "image/jpeg",
    "etag": "\"22557d-pdFeuMf98Fv+A921pAIGHueHy1o\"",
    "mtime": "2026-10-20T08:31:16.877Z",
    "size": 2250109,
    "path": "../public/imgs/hotel/contactus.jpg"
  },
  "/imgs/hotel/contactus.png": {
    "type": "image/png",
    "etag": "\"22557d-8swhD75JGjmVNgsz9GQ+/byFpRE\"",
    "mtime": "2026-10-20T08:31:16.905Z",
    "size": 2250109,
    "path": "../public/imgs/hotel/contactus.png"
  },
  "/imgs/hotel/opportunities.png": {
    "type": "image/png",
    "etag": "\"d827a-LNlG7w6VWBbk65LzgaY0kpUGavU\"",
    "mtime": "2026-10-20T08:31:17.050Z",
    "size": 885370,
    "path": "../public/imgs/hotel/opportunities.png"
  },
  "/imgs/hotel/uk.png": {
    "type": "image/png",
    "etag": "\"14fee-h5jWQXu5oURUEXD3l3vq11qnagA\"",
    "mtime": "2026-10-20T08:31:17.052Z",
    "size": 85998,
    "path": "../public/imgs/hotel/uk.png"
  },
  "/imgs/hotel/ukbaner.png": {
    "type": "image/png",
    "etag": "\"7e4dc-DTs9j85+61cduK31V+AS5RID1SQ\"",
    "mtime": "2026-10-20T08:31:17.058Z",
    "size": 517340,
    "path": "../public/imgs/hotel/ukbaner.png"
  },
  "/imgs/hotel/suggest-hotel-main-page-2.svg": {
    "type": "image/svg+xml",
    "etag": "\"cf399-PqiFUepmqm953dORNZClkpY1dB8\"",
    "mtime": "2026-09-05T08:34:31.013Z",
    "size": 848793,
    "path": "../public/imgs/hotel/suggest-hotel-main-page-2.svg"
  },
  "/imgs/hotel/us.png": {
    "type": "image/png",
    "etag": "\"148d1-wO3Q14CljjeVQsGVuuiO8feU7aI\"",
    "mtime": "2026-10-20T08:31:17.060Z",
    "size": 84177,
    "path": "../public/imgs/hotel/us.png"
  },
  "/imgs/hotel/usbaner.png": {
    "type": "image/png",
    "etag": "\"6a7de-rTOA/PPUF8WH306HzueW//xPgBA\"",
    "mtime": "2026-10-20T08:31:17.067Z",
    "size": 436190,
    "path": "../public/imgs/hotel/usbaner.png"
  },
  "/imgs/hotel/usslider.png": {
    "type": "image/png",
    "etag": "\"7e4dc-DTs9j85+61cduK31V+AS5RID1SQ\"",
    "mtime": "2026-10-20T08:31:17.069Z",
    "size": 517340,
    "path": "../public/imgs/hotel/usslider.png"
  },
  "/imgs/hotel/visalinebot.png": {
    "type": "image/png",
    "etag": "\"4b88c-XpxIpLszMX0jMDk+k5/pLSkxVZY\"",
    "mtime": "2026-10-20T08:31:17.091Z",
    "size": 309388,
    "path": "../public/imgs/hotel/visalinebot.png"
  },
  "/imgs/hotel/visalinemob.png": {
    "type": "image/png",
    "etag": "\"2f705-0IP+SiqGemCO6KunDx4HGdRxI9Y\"",
    "mtime": "2026-10-20T08:31:17.094Z",
    "size": 194309,
    "path": "../public/imgs/hotel/visalinemob.png"
  },
  "/imgs/hotel/suggest-hotel-main-page-3.svg": {
    "type": "image/svg+xml",
    "etag": "\"beb62-c1cd5JBmGa1vqlpwxIQ45Yg3QK4\"",
    "mtime": "2026-09-05T08:34:31.019Z",
    "size": 781154,
    "path": "../public/imgs/hotel/suggest-hotel-main-page-3.svg"
  },
  "/imgs/hotel/visalineside.png": {
    "type": "image/png",
    "etag": "\"1412e-02odkrDv9n+nRUnyM7D/AXdRNvI\"",
    "mtime": "2026-10-20T08:31:17.110Z",
    "size": 82222,
    "path": "../public/imgs/hotel/visalineside.png"
  },
  "/imgs/hotel/visaca.png": {
    "type": "image/png",
    "etag": "\"887cb-18s6YCGDLSQsigMe9AZUwbvKUro\"",
    "mtime": "2026-10-20T08:31:17.078Z",
    "size": 559051,
    "path": "../public/imgs/hotel/visaca.png"
  },
  "/imgs/hotel/visaeu.png": {
    "type": "image/png",
    "etag": "\"889fb-lIkiMO8+eomuNFUyvnHyU8wqnVA\"",
    "mtime": "2026-10-20T08:31:17.086Z",
    "size": 559611,
    "path": "../public/imgs/hotel/visaeu.png"
  },
  "/imgs/hotel/suggest-hotel-main-page-4.svg": {
    "type": "image/svg+xml",
    "etag": "\"116bd5-Ey5XQIiUiGljX5ZPW+N/BmXAsDc\"",
    "mtime": "2026-09-05T08:34:31.028Z",
    "size": 1141717,
    "path": "../public/imgs/hotel/suggest-hotel-main-page-4.svg"
  },
  "/imgs/hotel/بنر اصلی.jpg": {
    "type": "image/jpeg",
    "etag": "\"76116-FHBxSkSCkIkPCBQLFW904AeJtOI\"",
    "mtime": "2026-11-01T06:39:55.120Z",
    "size": 483606,
    "path": "../public/imgs/hotel/بنر اصلی.jpg"
  },
  "/imgs/hotel/visauk.png": {
    "type": "image/png",
    "etag": "\"88e2c-7XtxtYZaTE7dk6uR+8/BguThGTw\"",
    "mtime": "2026-10-20T08:31:17.117Z",
    "size": 560684,
    "path": "../public/imgs/hotel/visauk.png"
  },
  "/imgs/hotel/visalineside.gif": {
    "type": "image/gif",
    "etag": "\"148a0e-Tpq7wbXXhRyzUO8QpV0OxsdHhmY\"",
    "mtime": "2026-10-20T08:31:17.108Z",
    "size": 1346062,
    "path": "../public/imgs/hotel/visalineside.gif"
  },
  "/imgs/hotel/visaus.png": {
    "type": "image/png",
    "etag": "\"87297-CGzRl2ssuO4ULbtCCuyWgwAvem4\"",
    "mtime": "2026-10-20T08:31:17.124Z",
    "size": 553623,
    "path": "../public/imgs/hotel/visaus.png"
  },
  "/imgs/hotel/هدر سایت موبایل.jpg": {
    "type": "image/jpeg",
    "etag": "\"224b4-VkPJyeiLJCJ9VRq34nXau/wUbTs\"",
    "mtime": "2026-09-05T08:34:31.029Z",
    "size": 140468,
    "path": "../public/imgs/hotel/هدر سایت موبایل.jpg"
  },
  "/imgs/hotel/هدر سایت.jpg": {
    "type": "image/jpeg",
    "etag": "\"38be6-7ljSRA9tGPL71PAD4NGmfL2eMtE\"",
    "mtime": "2026-09-05T08:34:31.031Z",
    "size": 232422,
    "path": "../public/imgs/hotel/هدر سایت.jpg"
  },
  "/imgs/hotel/Vouchersnap.jpg": {
    "type": "image/jpeg",
    "etag": "\"ef943-KsJrqMBh5GfxCyZtgOlwKirQta4\"",
    "mtime": "2026-11-01T06:39:55.114Z",
    "size": 981315,
    "path": "../public/imgs/hotel/Vouchersnap.jpg"
  },
  "/imgs/hotel/کانادا اسلایدر.jpg": {
    "type": "image/jpeg",
    "etag": "\"36d00-xinIYh2qT5iYDhzGyUZN24+ijtE\"",
    "mtime": "2026-10-20T08:31:17.272Z",
    "size": 224512,
    "path": "../public/imgs/hotel/کانادا اسلایدر.jpg"
  },
  "/imgs/ticketbooking/flightbackground.png": {
    "type": "image/png",
    "etag": "\"33c7e-w5qxiWS1EbPCdJ39yKzs2+2a2vY\"",
    "mtime": "2026-07-13T06:00:39.863Z",
    "size": 212094,
    "path": "../public/imgs/ticketbooking/flightbackground.png"
  },
  "/imgs/ticketbooking/flightbackground2.png": {
    "type": "image/png",
    "etag": "\"37dda-lRCxDYIHBce/gxTvI4vzwm/eLH8\"",
    "mtime": "2026-07-13T06:00:39.867Z",
    "size": 228826,
    "path": "../public/imgs/ticketbooking/flightbackground2.png"
  },
  "/imgs/hotel/Voucher.jpg": {
    "type": "image/jpeg",
    "etag": "\"10ddfb-tpDjweX99hEUarMidYRvLvXW+lg\"",
    "mtime": "2026-11-01T06:39:55.102Z",
    "size": 1105403,
    "path": "../public/imgs/hotel/Voucher.jpg"
  },
  "/imgs/ticketbooking/flightbackground3.png": {
    "type": "image/png",
    "etag": "\"2b3b3-fZMk1UuaeQRXTQU8/rBj0yzOuVs\"",
    "mtime": "2026-07-13T06:00:39.873Z",
    "size": 177075,
    "path": "../public/imgs/ticketbooking/flightbackground3.png"
  },
  "/imgs/ticketbooking/flightbackground4.png": {
    "type": "image/png",
    "etag": "\"37ae6-oJEegvBOU/SlIDoNv6eRDdGplZw\"",
    "mtime": "2026-07-13T06:00:39.878Z",
    "size": 228070,
    "path": "../public/imgs/ticketbooking/flightbackground4.png"
  },
  "/imgs/ticketbooking/flightbackground5.png": {
    "type": "image/png",
    "etag": "\"2f5f4-Ms3P3L1KCrozBo2AVR1QIfCXMaY\"",
    "mtime": "2026-07-13T06:00:39.883Z",
    "size": 194036,
    "path": "../public/imgs/ticketbooking/flightbackground5.png"
  },
  "/imgs/ticketbooking/flightbackground6.png": {
    "type": "image/png",
    "etag": "\"4b345-zIwk8LwfhnTdKX3NNXIaUiIMI5Q\"",
    "mtime": "2026-07-13T06:00:39.907Z",
    "size": 308037,
    "path": "../public/imgs/ticketbooking/flightbackground6.png"
  },
  "/imgs/ticketbooking/flightbackground7.png": {
    "type": "image/png",
    "etag": "\"2f80b-jMhjnHt7Il+CgkFd5j1vWSXbc44\"",
    "mtime": "2026-07-13T06:00:39.912Z",
    "size": 194571,
    "path": "../public/imgs/ticketbooking/flightbackground7.png"
  },
  "/_nuxt/builds/latest.json": {
    "type": "application/json",
    "etag": "\"47-a9pkflJS4t2ln5Q3AAUOAu4/OzQ\"",
    "mtime": "2026-11-09T11:13:55.496Z",
    "size": 71,
    "path": "../public/_nuxt/builds/latest.json"
  },
  "/imgs/hotel/مدارک سفارت کانادا.pdf": {
    "type": "application/pdf",
    "etag": "\"14729b-GC4yGbMYERHjgK48PfgLT2Gv7IY\"",
    "mtime": "2026-10-20T08:31:17.217Z",
    "size": 1340059,
    "path": "../public/imgs/hotel/مدارک سفارت کانادا.pdf"
  },
  "/imgs/flight/airlines/0A.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.097Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/0A.png"
  },
  "/imgs/flight/airlines/0B.png": {
    "type": "image/png",
    "etag": "\"99e-2XJDFpo9oAgbnG7rH5pYcFC/aPQ\"",
    "mtime": "2026-11-01T06:39:54.098Z",
    "size": 2462,
    "path": "../public/imgs/flight/airlines/0B.png"
  },
  "/imgs/flight/airlines/0D.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.098Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/0D.png"
  },
  "/imgs/hotel/مبایل اصلی.jpg": {
    "type": "image/jpeg",
    "etag": "\"19c429-BPVFOWefPfc6+2FG1ENzaLRhm2Y\"",
    "mtime": "2026-11-01T06:39:55.135Z",
    "size": 1688617,
    "path": "../public/imgs/hotel/مبایل اصلی.jpg"
  },
  "/imgs/flight/airlines/2B.png": {
    "type": "image/png",
    "etag": "\"18ee-Fgzy+NKXfdo0e7AmgYZKKcueuHc\"",
    "mtime": "2026-11-01T06:39:54.099Z",
    "size": 6382,
    "path": "../public/imgs/flight/airlines/2B.png"
  },
  "/imgs/hotel/مدارک سفارت انگلستان.pdf": {
    "type": "application/pdf",
    "etag": "\"1915ba-OaHHA72ye6dWJGdQAhb/KNZ6Txw\"",
    "mtime": "2026-10-20T08:31:17.198Z",
    "size": 1643962,
    "path": "../public/imgs/hotel/مدارک سفارت انگلستان.pdf"
  },
  "/imgs/flight/airlines/2C.png": {
    "type": "image/png",
    "etag": "\"1647-tMJiMtIGHRqA+iUpZ0UkO2EouDQ\"",
    "mtime": "2026-11-01T06:39:54.101Z",
    "size": 5703,
    "path": "../public/imgs/flight/airlines/2C.png"
  },
  "/imgs/flight/airlines/2J.png": {
    "type": "image/png",
    "etag": "\"1d04-XrbrUZY1jM6namVs/nNfaMBDfTg\"",
    "mtime": "2026-11-01T06:39:54.102Z",
    "size": 7428,
    "path": "../public/imgs/flight/airlines/2J.png"
  },
  "/imgs/flight/airlines/2K.png": {
    "type": "image/png",
    "etag": "\"34f1-do43Lezy7SO0AJpVShIiGG4Cs1Q\"",
    "mtime": "2026-11-01T06:39:54.104Z",
    "size": 13553,
    "path": "../public/imgs/flight/airlines/2K.png"
  },
  "/imgs/flight/airlines/2L.png": {
    "type": "image/png",
    "etag": "\"98e-GGOqJzNgRrjfsV/Jzj8/CbkNVH4\"",
    "mtime": "2026-11-01T06:39:54.105Z",
    "size": 2446,
    "path": "../public/imgs/flight/airlines/2L.png"
  },
  "/imgs/flight/airlines/2M.png": {
    "type": "image/png",
    "etag": "\"126d-mNtDSmIeTVR5fMCK1qTJeotax6I\"",
    "mtime": "2026-11-01T06:39:54.106Z",
    "size": 4717,
    "path": "../public/imgs/flight/airlines/2M.png"
  },
  "/imgs/flight/airlines/2N.png": {
    "type": "image/png",
    "etag": "\"170e-54hgLWzvyeHjG2D0gtxMdN/sW0c\"",
    "mtime": "2026-11-01T06:39:54.107Z",
    "size": 5902,
    "path": "../public/imgs/flight/airlines/2N.png"
  },
  "/imgs/flight/airlines/2O.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.144Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/2O.png"
  },
  "/imgs/flight/airlines/2Q.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.168Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/2Q.png"
  },
  "/imgs/flight/airlines/2U.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.169Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/2U.png"
  },
  "/imgs/flight/airlines/2W.png": {
    "type": "image/png",
    "etag": "\"104f-9MvAW4pLXji3LwU6WbDQJfR1rHY\"",
    "mtime": "2026-11-01T06:39:54.170Z",
    "size": 4175,
    "path": "../public/imgs/flight/airlines/2W.png"
  },
  "/imgs/flight/airlines/2Z.png": {
    "type": "image/png",
    "etag": "\"c81-sJsAvTeANAUNGdDlath5e9gdRJc\"",
    "mtime": "2026-11-01T06:39:54.173Z",
    "size": 3201,
    "path": "../public/imgs/flight/airlines/2Z.png"
  },
  "/imgs/flight/airlines/3B.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.173Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/3B.png"
  },
  "/imgs/flight/airlines/3C.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.174Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/3C.png"
  },
  "/imgs/flight/airlines/3E.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.175Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/3E.png"
  },
  "/imgs/flight/airlines/3F.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.176Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/3F.png"
  },
  "/imgs/hotel/فرم درخواست ویزای سفارت کانادا.pdf": {
    "type": "application/pdf",
    "etag": "\"328e7d-wBt5Sp+77w7kOqvCyyI/P1h4Tjs\"",
    "mtime": "2026-10-20T08:31:17.162Z",
    "size": 3313277,
    "path": "../public/imgs/hotel/فرم درخواست ویزای سفارت کانادا.pdf"
  },
  "/imgs/flight/airlines/3H.png": {
    "type": "image/png",
    "etag": "\"195b-IUgAU1WtaKl4MB7rLcxSL5Xa7zs\"",
    "mtime": "2026-11-01T06:39:54.177Z",
    "size": 6491,
    "path": "../public/imgs/flight/airlines/3H.png"
  },
  "/imgs/flight/airlines/3K.png": {
    "type": "image/png",
    "etag": "\"db5-xetqW5s9gXnM+MvRITrjU3YD71E\"",
    "mtime": "2026-11-01T06:39:54.178Z",
    "size": 3509,
    "path": "../public/imgs/flight/airlines/3K.png"
  },
  "/imgs/flight/airlines/3L.png": {
    "type": "image/png",
    "etag": "\"e46-ET+0kn61rsrk6q5BaeE5Uw51lwk\"",
    "mtime": "2026-11-01T06:39:54.179Z",
    "size": 3654,
    "path": "../public/imgs/flight/airlines/3L.png"
  },
  "/imgs/flight/airlines/3M.png": {
    "type": "image/png",
    "etag": "\"f37-YfN3vl49ADcHtSfp55fQLMUx/Fs\"",
    "mtime": "2026-11-01T06:39:54.180Z",
    "size": 3895,
    "path": "../public/imgs/flight/airlines/3M.png"
  },
  "/imgs/flight/airlines/3O.png": {
    "type": "image/png",
    "etag": "\"1e67-hlmfw16xzPIvZo7YvnaXuqd0qW0\"",
    "mtime": "2026-11-01T06:39:54.182Z",
    "size": 7783,
    "path": "../public/imgs/flight/airlines/3O.png"
  },
  "/imgs/flight/airlines/3P.png": {
    "type": "image/png",
    "etag": "\"6aa-I/yd6II4jbuAIpXPG0UyJM/4eNc\"",
    "mtime": "2026-11-01T06:39:54.183Z",
    "size": 1706,
    "path": "../public/imgs/flight/airlines/3P.png"
  },
  "/imgs/flight/airlines/3R.png": {
    "type": "image/png",
    "etag": "\"c20-dab2a5u9k1shJrkFDPKmAlCxlEs\"",
    "mtime": "2026-11-01T06:39:54.184Z",
    "size": 3104,
    "path": "../public/imgs/flight/airlines/3R.png"
  },
  "/imgs/flight/airlines/3S.png": {
    "type": "image/png",
    "etag": "\"9e0-yG5UL3QithAiFr5+zzeg+YOeBno\"",
    "mtime": "2026-11-01T06:39:54.185Z",
    "size": 2528,
    "path": "../public/imgs/flight/airlines/3S.png"
  },
  "/imgs/flight/airlines/3T.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.186Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/3T.png"
  },
  "/imgs/flight/airlines/3U.png": {
    "type": "image/png",
    "etag": "\"ded-9HIMWISXt7zlAOxdIIm6JUM1TZ8\"",
    "mtime": "2026-11-01T06:39:54.187Z",
    "size": 3565,
    "path": "../public/imgs/flight/airlines/3U.png"
  },
  "/imgs/flight/airlines/3W.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.209Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/3W.png"
  },
  "/imgs/flight/airlines/4C.png": {
    "type": "image/png",
    "etag": "\"949-wRzHnuSC/JWm9pPxFn/nMQzvAa4\"",
    "mtime": "2026-11-01T06:39:54.211Z",
    "size": 2377,
    "path": "../public/imgs/flight/airlines/4C.png"
  },
  "/imgs/flight/airlines/4D.png": {
    "type": "image/png",
    "etag": "\"12b5-fuYDVU4QjjGK/Eak3cONn84qFeI\"",
    "mtime": "2026-11-01T06:39:54.213Z",
    "size": 4789,
    "path": "../public/imgs/flight/airlines/4D.png"
  },
  "/imgs/flight/airlines/4G.png": {
    "type": "image/png",
    "etag": "\"8e1-AiMvQtDadupSclED5U6Qu3Gu8ao\"",
    "mtime": "2026-11-01T06:39:54.214Z",
    "size": 2273,
    "path": "../public/imgs/flight/airlines/4G.png"
  },
  "/imgs/flight/airlines/4H.png": {
    "type": "image/png",
    "etag": "\"1249-q+eqrXPhR3UcP5uQZTVWHCTOX24\"",
    "mtime": "2026-11-01T06:39:54.215Z",
    "size": 4681,
    "path": "../public/imgs/flight/airlines/4H.png"
  },
  "/imgs/flight/airlines/4K.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.216Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/4K.png"
  },
  "/imgs/flight/airlines/4M.png": {
    "type": "image/png",
    "etag": "\"949-wRzHnuSC/JWm9pPxFn/nMQzvAa4\"",
    "mtime": "2026-11-01T06:39:54.216Z",
    "size": 2377,
    "path": "../public/imgs/flight/airlines/4M.png"
  },
  "/imgs/flight/airlines/4N.png": {
    "type": "image/png",
    "etag": "\"24f1-E47UU1Jp1dw2zx5ard2oMtW7zPw\"",
    "mtime": "2026-11-01T06:39:54.217Z",
    "size": 9457,
    "path": "../public/imgs/flight/airlines/4N.png"
  },
  "/imgs/flight/airlines/4O.png": {
    "type": "image/png",
    "etag": "\"9ba-+O67jCRgkyKm7vJBYNIepHnCwjk\"",
    "mtime": "2026-11-01T06:39:54.218Z",
    "size": 2490,
    "path": "../public/imgs/flight/airlines/4O.png"
  },
  "/imgs/flight/airlines/4Q.png": {
    "type": "image/png",
    "etag": "\"1727-yRsc/MoGCYxInFmIVXBXG9ZYQSQ\"",
    "mtime": "2026-11-01T06:39:54.220Z",
    "size": 5927,
    "path": "../public/imgs/flight/airlines/4Q.png"
  },
  "/imgs/flight/airlines/4R.png": {
    "type": "image/png",
    "etag": "\"1902-UJ4LaoLHWOizk5upqyZXdzIu2to\"",
    "mtime": "2026-11-01T06:39:54.222Z",
    "size": 6402,
    "path": "../public/imgs/flight/airlines/4R.png"
  },
  "/imgs/flight/airlines/4T.png": {
    "type": "image/png",
    "etag": "\"86b-WAa+uvKn04tjHgBppd7NEWTSEz8\"",
    "mtime": "2026-11-01T06:39:54.224Z",
    "size": 2155,
    "path": "../public/imgs/flight/airlines/4T.png"
  },
  "/imgs/flight/airlines/4U.png": {
    "type": "image/png",
    "etag": "\"14ba-K1GD+satEOha+dkKEw6qgn9TOG0\"",
    "mtime": "2026-11-01T06:39:54.225Z",
    "size": 5306,
    "path": "../public/imgs/flight/airlines/4U.png"
  },
  "/imgs/flight/airlines/4Y.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.226Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/4Y.png"
  },
  "/imgs/flight/airlines/5C.png": {
    "type": "image/png",
    "etag": "\"1304-2bU4w7fRzN1mV4GKiO5lYo9kTHo\"",
    "mtime": "2026-11-01T06:39:54.227Z",
    "size": 4868,
    "path": "../public/imgs/flight/airlines/5C.png"
  },
  "/imgs/flight/airlines/5G.png": {
    "type": "image/png",
    "etag": "\"278c-sPn1jsTLIibcZDbqWHj3uHvzARo\"",
    "mtime": "2026-11-01T06:39:54.229Z",
    "size": 10124,
    "path": "../public/imgs/flight/airlines/5G.png"
  },
  "/imgs/flight/airlines/5H.png": {
    "type": "image/png",
    "etag": "\"f10-k+YsovdEk1dXzAM2xqFB6xg7DEI\"",
    "mtime": "2026-11-01T06:39:54.230Z",
    "size": 3856,
    "path": "../public/imgs/flight/airlines/5H.png"
  },
  "/imgs/flight/airlines/5J.png": {
    "type": "image/png",
    "etag": "\"10a9-N4UwuxJbAJaeFm1LMls/P162At4\"",
    "mtime": "2026-11-01T06:39:54.231Z",
    "size": 4265,
    "path": "../public/imgs/flight/airlines/5J.png"
  },
  "/imgs/flight/airlines/5k.png": {
    "type": "image/png",
    "etag": "\"22aa-vqkHX0G1sbYKi7foWuW+EumamBg\"",
    "mtime": "2026-11-01T06:39:54.241Z",
    "size": 8874,
    "path": "../public/imgs/flight/airlines/5k.png"
  },
  "/imgs/flight/airlines/5L.png": {
    "type": "image/png",
    "etag": "\"a7a-YGniy8xTZb2w4jGm7e6NVMUyN8w\"",
    "mtime": "2026-11-01T06:39:54.232Z",
    "size": 2682,
    "path": "../public/imgs/flight/airlines/5L.png"
  },
  "/imgs/flight/airlines/5M.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.232Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/5M.png"
  },
  "/imgs/flight/airlines/5N.png": {
    "type": "image/png",
    "etag": "\"ea0-Kdz6VXK9iJLFU3bO1pGcZissj1w\"",
    "mtime": "2026-11-01T06:39:54.234Z",
    "size": 3744,
    "path": "../public/imgs/flight/airlines/5N.png"
  },
  "/imgs/flight/airlines/5O.png": {
    "type": "image/png",
    "etag": "\"903-SHsf+3jI/XzlPLSYXAWKHjZS3wY\"",
    "mtime": "2026-11-01T06:39:54.235Z",
    "size": 2307,
    "path": "../public/imgs/flight/airlines/5O.png"
  },
  "/imgs/flight/airlines/5T.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.236Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/5T.png"
  },
  "/imgs/flight/airlines/5V.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.236Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/5V.png"
  },
  "/imgs/flight/airlines/5W.png": {
    "type": "image/png",
    "etag": "\"dbf-RVq8yftdfPC8w6bIzjwX4hCFfIY\"",
    "mtime": "2026-11-01T06:39:54.237Z",
    "size": 3519,
    "path": "../public/imgs/flight/airlines/5W.png"
  },
  "/imgs/flight/airlines/5Y.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.238Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/5Y.png"
  },
  "/imgs/flight/airlines/5Z.png": {
    "type": "image/png",
    "etag": "\"15ac-BEjHF5Tvw2eU+cRTDYcQPDuZGbY\"",
    "mtime": "2026-11-01T06:39:54.240Z",
    "size": 5548,
    "path": "../public/imgs/flight/airlines/5Z.png"
  },
  "/imgs/flight/airlines/6A.png": {
    "type": "image/png",
    "etag": "\"3aaa-2O0HhVRxruYOE3yN6G5P2qmnljQ\"",
    "mtime": "2026-11-01T06:39:54.242Z",
    "size": 15018,
    "path": "../public/imgs/flight/airlines/6A.png"
  },
  "/imgs/flight/airlines/6E.png": {
    "type": "image/png",
    "etag": "\"dbc-QgdjAhsJvASKCYHkWHb8QRjDF9o\"",
    "mtime": "2026-11-01T06:39:54.243Z",
    "size": 3516,
    "path": "../public/imgs/flight/airlines/6E.png"
  },
  "/imgs/flight/airlines/6G.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.244Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/6G.png"
  },
  "/imgs/flight/airlines/6H.png": {
    "type": "image/png",
    "etag": "\"92b-+ViV9m3Zud6k8cQQqIs58nwWQQ0\"",
    "mtime": "2026-11-01T06:39:54.245Z",
    "size": 2347,
    "path": "../public/imgs/flight/airlines/6H.png"
  },
  "/imgs/flight/airlines/6I.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.245Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/6I.png"
  },
  "/imgs/flight/airlines/6J.png": {
    "type": "image/png",
    "etag": "\"1165-b/x3uvNsvCg/Dv9Aq3tN+G1WUpw\"",
    "mtime": "2026-11-01T06:39:54.246Z",
    "size": 4453,
    "path": "../public/imgs/flight/airlines/6J.png"
  },
  "/imgs/flight/airlines/6K.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.247Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/6K.png"
  },
  "/imgs/flight/airlines/6N.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.248Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/6N.png"
  },
  "/imgs/flight/airlines/6P.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.248Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/6P.png"
  },
  "/imgs/flight/airlines/6Q.png": {
    "type": "image/png",
    "etag": "\"3bc8-zeSxiZRlcEXygZ0DtXvqyQz9QDo\"",
    "mtime": "2026-11-01T06:39:54.249Z",
    "size": 15304,
    "path": "../public/imgs/flight/airlines/6Q.png"
  },
  "/imgs/flight/airlines/6R.png": {
    "type": "image/png",
    "etag": "\"11c8-lGl+uO39b05JoN00EILjRo9VwrY\"",
    "mtime": "2026-11-01T06:39:54.251Z",
    "size": 4552,
    "path": "../public/imgs/flight/airlines/6R.png"
  },
  "/imgs/flight/airlines/6V.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.251Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/6V.png"
  },
  "/imgs/flight/airlines/6W.png": {
    "type": "image/png",
    "etag": "\"1e6c-+AvfvHtebBZ5FUWs5SEgGnzst08\"",
    "mtime": "2026-11-01T06:39:54.252Z",
    "size": 7788,
    "path": "../public/imgs/flight/airlines/6W.png"
  },
  "/imgs/flight/airlines/6Y.png": {
    "type": "image/png",
    "etag": "\"e1d-q5QDfIApclZs8JLhAZEI82gfZHk\"",
    "mtime": "2026-11-01T06:39:54.253Z",
    "size": 3613,
    "path": "../public/imgs/flight/airlines/6Y.png"
  },
  "/imgs/flight/airlines/6Z.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.254Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/6Z.png"
  },
  "/imgs/flight/airlines/7C.png": {
    "type": "image/png",
    "etag": "\"1a15-c22GOlBBinzcBVyN3fiN5aYQDfk\"",
    "mtime": "2026-11-01T06:39:54.257Z",
    "size": 6677,
    "path": "../public/imgs/flight/airlines/7C.png"
  },
  "/imgs/flight/airlines/7E.png": {
    "type": "image/png",
    "etag": "\"3f0-ONDcGoEb1vPPaywvj28d84PWf3g\"",
    "mtime": "2026-11-01T06:39:54.258Z",
    "size": 1008,
    "path": "../public/imgs/flight/airlines/7E.png"
  },
  "/imgs/flight/airlines/7F.png": {
    "type": "image/png",
    "etag": "\"a7c-Nd+mE3JJHy3EaffizyzX2CvDJ80\"",
    "mtime": "2026-11-01T06:39:54.259Z",
    "size": 2684,
    "path": "../public/imgs/flight/airlines/7F.png"
  },
  "/imgs/flight/airlines/7G.png": {
    "type": "image/png",
    "etag": "\"e5a-0AmqPg8VAYRQKiQJc4EU68Ez5Cg\"",
    "mtime": "2026-11-01T06:39:54.259Z",
    "size": 3674,
    "path": "../public/imgs/flight/airlines/7G.png"
  },
  "/imgs/flight/airlines/7H.png": {
    "type": "image/png",
    "etag": "\"a16-QaZuoivvNgbbGnROmRfIh1t34Pc\"",
    "mtime": "2026-11-01T06:39:54.260Z",
    "size": 2582,
    "path": "../public/imgs/flight/airlines/7H.png"
  },
  "/imgs/flight/airlines/7I.png": {
    "type": "image/png",
    "etag": "\"90b-Bo8LjlWOao7VV6UyIgfFmrE9WYI\"",
    "mtime": "2026-11-01T06:39:54.261Z",
    "size": 2315,
    "path": "../public/imgs/flight/airlines/7I.png"
  },
  "/imgs/flight/airlines/7K.png": {
    "type": "image/png",
    "etag": "\"1d76-8xklqd+2Jca2thaNsEkG34Sg2NA\"",
    "mtime": "2026-11-01T06:39:54.262Z",
    "size": 7542,
    "path": "../public/imgs/flight/airlines/7K.png"
  },
  "/imgs/flight/airlines/7L.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.263Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/7L.png"
  },
  "/imgs/flight/airlines/7M.png": {
    "type": "image/png",
    "etag": "\"329b-0wAvny24wNsMODbyAm27fkIIsBE\"",
    "mtime": "2026-11-01T06:39:54.264Z",
    "size": 12955,
    "path": "../public/imgs/flight/airlines/7M.png"
  },
  "/imgs/flight/airlines/7N.png": {
    "type": "image/png",
    "etag": "\"15d1-me+5uuHQB/6hpQV6So4J/EECdR4\"",
    "mtime": "2026-11-01T06:39:54.265Z",
    "size": 5585,
    "path": "../public/imgs/flight/airlines/7N.png"
  },
  "/imgs/flight/airlines/7R.png": {
    "type": "image/png",
    "etag": "\"3248-qliQZVKAY/lC7mJIQCISwE0uxFA\"",
    "mtime": "2026-11-01T06:39:54.266Z",
    "size": 12872,
    "path": "../public/imgs/flight/airlines/7R.png"
  },
  "/imgs/flight/airlines/7W.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.266Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/7W.png"
  },
  "/imgs/flight/airlines/8B.png": {
    "type": "image/png",
    "etag": "\"8b8-ffL1NudMDQqad3s+jFSqn49OOq4\"",
    "mtime": "2026-11-01T06:39:54.267Z",
    "size": 2232,
    "path": "../public/imgs/flight/airlines/8B.png"
  },
  "/imgs/flight/airlines/8D.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.268Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/8D.png"
  },
  "/imgs/flight/airlines/8E.png": {
    "type": "image/png",
    "etag": "\"16bd-JiLstqAfItOW67uhNx2IAEAj9gA\"",
    "mtime": "2026-11-01T06:39:54.269Z",
    "size": 5821,
    "path": "../public/imgs/flight/airlines/8E.png"
  },
  "/imgs/flight/airlines/8F.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.269Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/8F.png"
  },
  "/imgs/flight/airlines/8J.png": {
    "type": "image/png",
    "etag": "\"b4f-+VbHoDIvgm0Xh/RRXnxAWEKDBGg\"",
    "mtime": "2026-11-01T06:39:54.270Z",
    "size": 2895,
    "path": "../public/imgs/flight/airlines/8J.png"
  },
  "/imgs/flight/airlines/8L.png": {
    "type": "image/png",
    "etag": "\"1060-mtLimaz/Fq0yF4xXp880GY3eF9s\"",
    "mtime": "2026-11-01T06:39:54.271Z",
    "size": 4192,
    "path": "../public/imgs/flight/airlines/8L.png"
  },
  "/imgs/flight/airlines/8M.png": {
    "type": "image/png",
    "etag": "\"18b5-//5gu41L97EIFTsDeOQwCdm6ogU\"",
    "mtime": "2026-11-01T06:39:54.273Z",
    "size": 6325,
    "path": "../public/imgs/flight/airlines/8M.png"
  },
  "/imgs/flight/airlines/8N.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.274Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/8N.png"
  },
  "/imgs/flight/airlines/8O.png": {
    "type": "image/png",
    "etag": "\"220f-WfZATBezUbTt2ZPM+5Sa/SlvQ/Q\"",
    "mtime": "2026-11-01T06:39:54.275Z",
    "size": 8719,
    "path": "../public/imgs/flight/airlines/8O.png"
  },
  "/imgs/flight/airlines/8P.png": {
    "type": "image/png",
    "etag": "\"370e-Ca8UKer5Jg9unlzin6tpePp/6Jo\"",
    "mtime": "2026-11-01T06:39:54.286Z",
    "size": 14094,
    "path": "../public/imgs/flight/airlines/8P.png"
  },
  "/imgs/flight/airlines/8Q.png": {
    "type": "image/png",
    "etag": "\"8fb-Cfckzznk9fmE0H5nINexW7svt/o\"",
    "mtime": "2026-11-01T06:39:54.287Z",
    "size": 2299,
    "path": "../public/imgs/flight/airlines/8Q.png"
  },
  "/imgs/flight/airlines/8T.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.288Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/8T.png"
  },
  "/imgs/flight/airlines/8U.png": {
    "type": "image/png",
    "etag": "\"2c72-ktb+ytD2If7rb5FhhhUeS4Zwsuo\"",
    "mtime": "2026-11-01T06:39:54.290Z",
    "size": 11378,
    "path": "../public/imgs/flight/airlines/8U.png"
  },
  "/imgs/flight/airlines/8V.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.290Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/8V.png"
  },
  "/imgs/flight/airlines/8W.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.291Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/8W.png"
  },
  "/imgs/flight/airlines/9B.png": {
    "type": "image/png",
    "etag": "\"ef2-n9+zPsJ0G22VIrQVoBd48xmDuP4\"",
    "mtime": "2026-11-01T06:39:54.292Z",
    "size": 3826,
    "path": "../public/imgs/flight/airlines/9B.png"
  },
  "/imgs/flight/airlines/9C.png": {
    "type": "image/png",
    "etag": "\"a47-No/ZZU+OWWU4SamMPzdbH4pAQWs\"",
    "mtime": "2026-11-01T06:39:54.293Z",
    "size": 2631,
    "path": "../public/imgs/flight/airlines/9C.png"
  },
  "/imgs/flight/airlines/9E.png": {
    "type": "image/png",
    "etag": "\"64b-x75ofUd/p1MRkP3hKLnQn7yfvUA\"",
    "mtime": "2026-11-01T06:39:54.294Z",
    "size": 1611,
    "path": "../public/imgs/flight/airlines/9E.png"
  },
  "/imgs/flight/airlines/9F.png": {
    "type": "image/png",
    "etag": "\"37c9-9bNo5KEj8oPqGI+Zf8ea6ZJ6GnE\"",
    "mtime": "2026-11-01T06:39:54.295Z",
    "size": 14281,
    "path": "../public/imgs/flight/airlines/9F.png"
  },
  "/imgs/flight/airlines/9K.png": {
    "type": "image/png",
    "etag": "\"83b-pmrKuNqSQvORqGww/USVBHDS9os\"",
    "mtime": "2026-11-01T06:39:54.296Z",
    "size": 2107,
    "path": "../public/imgs/flight/airlines/9K.png"
  },
  "/imgs/flight/airlines/9L.png": {
    "type": "image/png",
    "etag": "\"3a05-sVHZrzZbowiA58AhsNH5fyIvQkw\"",
    "mtime": "2026-11-01T06:39:54.297Z",
    "size": 14853,
    "path": "../public/imgs/flight/airlines/9L.png"
  },
  "/imgs/flight/airlines/9M.png": {
    "type": "image/png",
    "etag": "\"848-TYChQec3cI6oJ9P8oQvFtEANOhw\"",
    "mtime": "2026-11-01T06:39:54.298Z",
    "size": 2120,
    "path": "../public/imgs/flight/airlines/9M.png"
  },
  "/imgs/flight/airlines/9O.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.302Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/9O.png"
  },
  "/imgs/flight/airlines/9R.png": {
    "type": "image/png",
    "etag": "\"7ee-RlSUOlzGHNmC+7LGtrS74ikriv4\"",
    "mtime": "2026-11-01T06:39:54.303Z",
    "size": 2030,
    "path": "../public/imgs/flight/airlines/9R.png"
  },
  "/imgs/flight/airlines/9U.png": {
    "type": "image/png",
    "etag": "\"17f5-QVAlFOC4jrBbThItSA8CGF9YSPQ\"",
    "mtime": "2026-11-01T06:39:54.304Z",
    "size": 6133,
    "path": "../public/imgs/flight/airlines/9U.png"
  },
  "/imgs/flight/airlines/9V.png": {
    "type": "image/png",
    "etag": "\"e69-Mv/dD9QS53CVF7eXkeKrFm8ap24\"",
    "mtime": "2026-11-01T06:39:54.307Z",
    "size": 3689,
    "path": "../public/imgs/flight/airlines/9V.png"
  },
  "/imgs/flight/airlines/9W.png": {
    "type": "image/png",
    "etag": "\"924-hz394Nc1ILcczhPPqjkXZH9BONM\"",
    "mtime": "2026-11-01T06:39:54.307Z",
    "size": 2340,
    "path": "../public/imgs/flight/airlines/9W.png"
  },
  "/imgs/flight/airlines/9Y.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.308Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/9Y.png"
  },
  "/imgs/flight/airlines/A2.png": {
    "type": "image/png",
    "etag": "\"884-5iL+R3enVZaP5jbk3M6pD9NCjgg\"",
    "mtime": "2026-11-01T06:39:54.309Z",
    "size": 2180,
    "path": "../public/imgs/flight/airlines/A2.png"
  },
  "/imgs/flight/airlines/A3.png": {
    "type": "image/png",
    "etag": "\"114f-IfDSxkcAdnXdLT6quue1NC2mtpA\"",
    "mtime": "2026-11-01T06:39:54.311Z",
    "size": 4431,
    "path": "../public/imgs/flight/airlines/A3.png"
  },
  "/imgs/flight/airlines/A4.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.312Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/A4.png"
  },
  "/imgs/flight/airlines/A5.png": {
    "type": "image/png",
    "etag": "\"8b6-7OWXaM88FqgiIMUfxgSnOzRfy/4\"",
    "mtime": "2026-11-01T06:39:54.313Z",
    "size": 2230,
    "path": "../public/imgs/flight/airlines/A5.png"
  },
  "/imgs/flight/airlines/A6.png": {
    "type": "image/png",
    "etag": "\"1c7a-Gsa8z/wlbNYdj4XX5OijauBXkh8\"",
    "mtime": "2026-11-01T06:39:54.314Z",
    "size": 7290,
    "path": "../public/imgs/flight/airlines/A6.png"
  },
  "/imgs/flight/airlines/A7.png": {
    "type": "image/png",
    "etag": "\"11c0-q688IKnMoiqKP6Ynrxefj4+1X3g\"",
    "mtime": "2026-11-01T06:39:54.315Z",
    "size": 4544,
    "path": "../public/imgs/flight/airlines/A7.png"
  },
  "/imgs/flight/airlines/A8.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.315Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/A8.png"
  },
  "/imgs/flight/airlines/A9.png": {
    "type": "image/png",
    "etag": "\"256a-jDFO5DosE8Vw8YMm1/KnGeXE2zU\"",
    "mtime": "2026-11-01T06:39:54.316Z",
    "size": 9578,
    "path": "../public/imgs/flight/airlines/A9.png"
  },
  "/imgs/flight/airlines/AA.png": {
    "type": "image/png",
    "etag": "\"1070-EtamFP6F0pv1Uvt2aC3o1BzDbCY\"",
    "mtime": "2026-11-01T06:39:54.317Z",
    "size": 4208,
    "path": "../public/imgs/flight/airlines/AA.png"
  },
  "/imgs/flight/airlines/AB.png": {
    "type": "image/png",
    "etag": "\"1756-1h91AQLo031EMXA6T8Q5k1nTouM\"",
    "mtime": "2026-11-01T06:39:54.318Z",
    "size": 5974,
    "path": "../public/imgs/flight/airlines/AB.png"
  },
  "/imgs/flight/airlines/AC.png": {
    "type": "image/png",
    "etag": "\"1c4b-V1TU3bn1zq2QPxrbjuodxref7lU\"",
    "mtime": "2026-11-01T06:39:54.319Z",
    "size": 7243,
    "path": "../public/imgs/flight/airlines/AC.png"
  },
  "/imgs/flight/airlines/AD.png": {
    "type": "image/png",
    "etag": "\"dc0-y4SD4SKvSzsRsBHowWnQoFUqNqs\"",
    "mtime": "2026-11-01T06:39:54.320Z",
    "size": 3520,
    "path": "../public/imgs/flight/airlines/AD.png"
  },
  "/imgs/flight/airlines/AE.png": {
    "type": "image/png",
    "etag": "\"165e-bBpV8ZUqhNJfMqrdYjEZE11PuWs\"",
    "mtime": "2026-11-01T06:39:54.321Z",
    "size": 5726,
    "path": "../public/imgs/flight/airlines/AE.png"
  },
  "/imgs/flight/airlines/aeroflot.png": {
    "type": "image/png",
    "etag": "\"5829-gNwVMJRzTmJDn7zkq6PVhlRWFEk\"",
    "mtime": "2026-08-24T08:29:56.286Z",
    "size": 22569,
    "path": "../public/imgs/flight/airlines/aeroflot.png"
  },
  "/imgs/flight/airlines/AF.png": {
    "type": "image/png",
    "etag": "\"184e-NXpnCWtCsPfmR/lkZ5REMq4/Mcs\"",
    "mtime": "2026-11-01T06:39:54.324Z",
    "size": 6222,
    "path": "../public/imgs/flight/airlines/AF.png"
  },
  "/imgs/flight/airlines/AH.png": {
    "type": "image/png",
    "etag": "\"14e1-J1jqw4p4CWnyQfER4cEOoXSEWSc\"",
    "mtime": "2026-11-01T06:39:54.325Z",
    "size": 5345,
    "path": "../public/imgs/flight/airlines/AH.png"
  },
  "/imgs/flight/airlines/AI.png": {
    "type": "image/png",
    "etag": "\"1824-PBrLuRUvPy3xznvWzZO3kRzwyFc\"",
    "mtime": "2026-11-01T06:39:54.326Z",
    "size": 6180,
    "path": "../public/imgs/flight/airlines/AI.png"
  },
  "/imgs/flight/airlines/aircanada.png": {
    "type": "image/png",
    "etag": "\"2186-sVFF0c4ASYK31q5CylprfRHrXfo\"",
    "mtime": "2026-08-24T08:29:56.288Z",
    "size": 8582,
    "path": "../public/imgs/flight/airlines/aircanada.png"
  },
  "/imgs/flight/airlines/airfrance.png": {
    "type": "image/png",
    "etag": "\"5c8e-fNd9dyHsMEusdx9FCKZxnQJGvcI\"",
    "mtime": "2026-08-24T08:29:56.289Z",
    "size": 23694,
    "path": "../public/imgs/flight/airlines/airfrance.png"
  },
  "/imgs/flight/airlines/airindia.png": {
    "type": "image/png",
    "etag": "\"8aee-78lcTjqIEs/qLDfBGEypiGDWNX4\"",
    "mtime": "2026-08-24T08:29:56.291Z",
    "size": 35566,
    "path": "../public/imgs/flight/airlines/airindia.png"
  },
  "/imgs/flight/airlines/airtour.png": {
    "type": "image/png",
    "etag": "\"1e59e-ksZqbjXOKG7Wjt/y1Ph0rVUxQYw\"",
    "mtime": "2026-07-13T06:00:39.772Z",
    "size": 124318,
    "path": "../public/imgs/flight/airlines/airtour.png"
  },
  "/imgs/flight/airlines/AJ.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.327Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/AJ.png"
  },
  "/imgs/flight/airlines/AK.png": {
    "type": "image/png",
    "etag": "\"ece-URBey1bOEXpq1ROPyY6kfSgMYxs\"",
    "mtime": "2026-11-01T06:39:54.327Z",
    "size": 3790,
    "path": "../public/imgs/flight/airlines/AK.png"
  },
  "/imgs/flight/airlines/allnippon.png": {
    "type": "image/png",
    "etag": "\"8b93-siXcQ0+KI00U5gJ5xI8fxiQDMo0\"",
    "mtime": "2026-08-24T08:29:56.294Z",
    "size": 35731,
    "path": "../public/imgs/flight/airlines/allnippon.png"
  },
  "/imgs/flight/airlines/AM.png": {
    "type": "image/png",
    "etag": "\"349e-YVbfVd3JcU9tywV2mChPWRqDeJU\"",
    "mtime": "2026-11-01T06:39:54.328Z",
    "size": 13470,
    "path": "../public/imgs/flight/airlines/AM.png"
  },
  "/imgs/flight/airlines/anadolujet.png": {
    "type": "image/png",
    "etag": "\"907-ybb9OyjjAcPT2aw3h1OmPBB5ySA\"",
    "mtime": "2026-08-24T08:29:56.295Z",
    "size": 2311,
    "path": "../public/imgs/flight/airlines/anadolujet.png"
  },
  "/imgs/flight/airlines/AO.png": {
    "type": "image/png",
    "etag": "\"1fa4-2yJCEvX+nZPTjtcjNTnYB5B6+T4\"",
    "mtime": "2026-11-01T06:39:54.329Z",
    "size": 8100,
    "path": "../public/imgs/flight/airlines/AO.png"
  },
  "/imgs/flight/airlines/AP.png": {
    "type": "image/png",
    "etag": "\"1e63-xv6mtXWheUYIOd16js+Au0i6gYk\"",
    "mtime": "2026-11-01T06:39:54.330Z",
    "size": 7779,
    "path": "../public/imgs/flight/airlines/AP.png"
  },
  "/imgs/flight/airlines/AQ.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.330Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/AQ.png"
  },
  "/imgs/flight/airlines/AR.png": {
    "type": "image/png",
    "etag": "\"13e4-mXKEcLtOGyQZ+9mP+DJ3x3zJGkQ\"",
    "mtime": "2026-11-01T06:39:54.331Z",
    "size": 5092,
    "path": "../public/imgs/flight/airlines/AR.png"
  },
  "/imgs/flight/airlines/AS.png": {
    "type": "image/png",
    "etag": "\"2441-0c6WK2zJKytcL3SQGf8lZcWmn4Q\"",
    "mtime": "2026-11-01T06:39:54.332Z",
    "size": 9281,
    "path": "../public/imgs/flight/airlines/AS.png"
  },
  "/imgs/flight/airlines/asajet.png": {
    "type": "image/png",
    "etag": "\"109bd-T43jTVzyz/soOEzLjLf25jAfk7g\"",
    "mtime": "2026-07-13T06:00:39.775Z",
    "size": 68029,
    "path": "../public/imgs/flight/airlines/asajet.png"
  },
  "/imgs/flight/airlines/aseman.png": {
    "type": "image/png",
    "etag": "\"30e8-pNRoxdYohF/V8sfbcnMVDvOaxV0\"",
    "mtime": "2026-07-13T06:00:39.825Z",
    "size": 12520,
    "path": "../public/imgs/flight/airlines/aseman.png"
  },
  "/imgs/flight/airlines/at.png": {
    "type": "image/png",
    "etag": "\"272c-8C2eG7GhnC3mCDkM4dff8lKT7e0\"",
    "mtime": "2026-11-01T06:39:55.063Z",
    "size": 10028,
    "path": "../public/imgs/flight/airlines/at.png"
  },
  "/imgs/flight/airlines/ata.png": {
    "type": "image/png",
    "etag": "\"b8f0-8Kf5wQ8eBwk86w+jUScHBPOvdsY\"",
    "mtime": "2026-07-13T06:00:39.826Z",
    "size": 47344,
    "path": "../public/imgs/flight/airlines/ata.png"
  },
  "/imgs/flight/airlines/atlasair.png": {
    "type": "image/png",
    "etag": "\"fc45-5Ma2Riss9Nn4fEZMYeyiOM2Zzm4\"",
    "mtime": "2026-08-24T08:29:56.298Z",
    "size": 64581,
    "path": "../public/imgs/flight/airlines/atlasair.png"
  },
  "/imgs/flight/airlines/atlasglobal.png": {
    "type": "image/png",
    "etag": "\"7643-/uynVWDAwYNtHsIxRL49VD47V5I\"",
    "mtime": "2026-08-24T08:29:56.300Z",
    "size": 30275,
    "path": "../public/imgs/flight/airlines/atlasglobal.png"
  },
  "/imgs/flight/airlines/AU.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.332Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/AU.png"
  },
  "/imgs/flight/airlines/austrian.png": {
    "type": "image/png",
    "etag": "\"46b7-s0TQwUXaLrQ3XrNu55X10z6h53o\"",
    "mtime": "2026-08-24T08:29:56.301Z",
    "size": 18103,
    "path": "../public/imgs/flight/airlines/austrian.png"
  },
  "/imgs/flight/airlines/AV.png": {
    "type": "image/png",
    "etag": "\"c46-stV+jLkTfhcwI8WAC6yWBrtg9hg\"",
    "mtime": "2026-11-01T06:39:54.333Z",
    "size": 3142,
    "path": "../public/imgs/flight/airlines/AV.png"
  },
  "/imgs/flight/airlines/avaair.png": {
    "type": "image/png",
    "etag": "\"131f4-EtS1p1186gezQiFqOsfOxvDb4q0\"",
    "mtime": "2026-07-13T06:00:39.827Z",
    "size": 78324,
    "path": "../public/imgs/flight/airlines/avaair.png"
  },
  "/imgs/flight/airlines/AW.png": {
    "type": "image/png",
    "etag": "\"89d-owrPA7plAM+ZGGYbfDFZcFVY2zA\"",
    "mtime": "2026-11-01T06:39:54.333Z",
    "size": 2205,
    "path": "../public/imgs/flight/airlines/AW.png"
  },
  "/imgs/flight/airlines/AX.png": {
    "type": "image/png",
    "etag": "\"7b1-hL4nFeoDojjXoHDZfBUeKvZGVec\"",
    "mtime": "2026-11-01T06:39:54.334Z",
    "size": 1969,
    "path": "../public/imgs/flight/airlines/AX.png"
  },
  "/imgs/flight/airlines/AY.png": {
    "type": "image/png",
    "etag": "\"214f-bJWfJG8TdIBHJy86X0j0eUuxJjQ\"",
    "mtime": "2026-11-01T06:39:54.335Z",
    "size": 8527,
    "path": "../public/imgs/flight/airlines/AY.png"
  },
  "/imgs/flight/airlines/AZ.png": {
    "type": "image/png",
    "etag": "\"2863-WaCwQpVj9T/fUvfjjnMcoGrs0AU\"",
    "mtime": "2026-11-01T06:39:54.336Z",
    "size": 10339,
    "path": "../public/imgs/flight/airlines/AZ.png"
  },
  "/imgs/flight/airlines/azerbaijan.png": {
    "type": "image/png",
    "etag": "\"3ea6-a6l186lSbpUZy4HSf9h7zliEcs0\"",
    "mtime": "2026-08-24T08:29:56.303Z",
    "size": 16038,
    "path": "../public/imgs/flight/airlines/azerbaijan.png"
  },
  "/imgs/flight/airlines/B2.png": {
    "type": "image/png",
    "etag": "\"19e2-97PBdE6bP8md11PUEVimaGNa9C0\"",
    "mtime": "2026-11-01T06:39:54.338Z",
    "size": 6626,
    "path": "../public/imgs/flight/airlines/B2.png"
  },
  "/imgs/flight/airlines/B3.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.338Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/B3.png"
  },
  "/imgs/flight/airlines/B5.png": {
    "type": "image/png",
    "etag": "\"2184-KLfTAzkr7nzqgR7pvewCLiJO8xo\"",
    "mtime": "2026-11-01T06:39:54.339Z",
    "size": 8580,
    "path": "../public/imgs/flight/airlines/B5.png"
  },
  "/imgs/flight/airlines/B6.png": {
    "type": "image/png",
    "etag": "\"6f0-kLUD9iUKHv82wc7lYcqNb6GMv+0\"",
    "mtime": "2026-11-01T06:39:54.340Z",
    "size": 1776,
    "path": "../public/imgs/flight/airlines/B6.png"
  },
  "/imgs/flight/airlines/B7.png": {
    "type": "image/png",
    "etag": "\"2493-YS9bu96nZqlgtXpG2yEmjqY8u2Q\"",
    "mtime": "2026-11-01T06:39:54.342Z",
    "size": 9363,
    "path": "../public/imgs/flight/airlines/B7.png"
  },
  "/imgs/flight/airlines/B8.png": {
    "type": "image/png",
    "etag": "\"1772-dYEhBYA4OfpPwe6lGdJ5Nt7QaRI\"",
    "mtime": "2026-11-01T06:39:54.343Z",
    "size": 6002,
    "path": "../public/imgs/flight/airlines/B8.png"
  },
  "/imgs/flight/airlines/B9.png": {
    "type": "image/png",
    "etag": "\"687d-cD7llwBZwlUsEajVt2ZWEvLKbbc\"",
    "mtime": "2026-11-01T06:39:54.344Z",
    "size": 26749,
    "path": "../public/imgs/flight/airlines/B9.png"
  },
  "/imgs/flight/airlines/BA.png": {
    "type": "image/png",
    "etag": "\"713-M1tiH6ycgpzisNwzOD+6LxcqB6Y\"",
    "mtime": "2026-11-01T06:39:54.346Z",
    "size": 1811,
    "path": "../public/imgs/flight/airlines/BA.png"
  },
  "/imgs/flight/airlines/bangkok.png": {
    "type": "image/png",
    "etag": "\"50f3-sNsWDJW+BQJSSpU+8305qYvWNCU\"",
    "mtime": "2026-08-24T08:29:56.308Z",
    "size": 20723,
    "path": "../public/imgs/flight/airlines/bangkok.png"
  },
  "/imgs/flight/airlines/BB.png": {
    "type": "image/png",
    "etag": "\"588-dOpHw2rwlf7IqtZKOKFfT6ool1Y\"",
    "mtime": "2026-11-01T06:39:54.347Z",
    "size": 1416,
    "path": "../public/imgs/flight/airlines/BB.png"
  },
  "/imgs/flight/airlines/BC.png": {
    "type": "image/png",
    "etag": "\"18a9-QeKtWQ+7TVguc9FKEweOzqnIAxY\"",
    "mtime": "2026-11-01T06:39:54.348Z",
    "size": 6313,
    "path": "../public/imgs/flight/airlines/BC.png"
  },
  "/imgs/flight/airlines/BD.png": {
    "type": "image/png",
    "etag": "\"4f8-HjDO/pIV4RaDDgw6/iirwDR2ICg\"",
    "mtime": "2026-11-01T06:39:54.349Z",
    "size": 1272,
    "path": "../public/imgs/flight/airlines/BD.png"
  },
  "/imgs/flight/airlines/BE.png": {
    "type": "image/png",
    "etag": "\"1349-P6vOVQL1LJRb6dkAKS9mz+z5T/M\"",
    "mtime": "2026-11-01T06:39:54.349Z",
    "size": 4937,
    "path": "../public/imgs/flight/airlines/BE.png"
  },
  "/imgs/flight/airlines/BF.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.350Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/BF.png"
  },
  "/imgs/flight/airlines/BG.png": {
    "type": "image/png",
    "etag": "\"1606-YF6APB9jdjnjaCkJUgph6hnGy7s\"",
    "mtime": "2026-11-01T06:39:54.351Z",
    "size": 5638,
    "path": "../public/imgs/flight/airlines/BG.png"
  },
  "/imgs/flight/airlines/BH.png": {
    "type": "image/png",
    "etag": "\"2053-IcJTmDEdbCGyEt8Ey2AaJAZSgG0\"",
    "mtime": "2026-11-01T06:39:54.352Z",
    "size": 8275,
    "path": "../public/imgs/flight/airlines/BH.png"
  },
  "/imgs/flight/airlines/BI.png": {
    "type": "image/png",
    "etag": "\"b2f-vUoWfs1Wt2MeG2mKreaDV/G5pmY\"",
    "mtime": "2026-11-01T06:39:54.353Z",
    "size": 2863,
    "path": "../public/imgs/flight/airlines/BI.png"
  },
  "/imgs/flight/airlines/BJ.png": {
    "type": "image/png",
    "etag": "\"1982-TYIwpwZBFnXnSxwi8gFsKuDK0aU\"",
    "mtime": "2026-11-01T06:39:54.355Z",
    "size": 6530,
    "path": "../public/imgs/flight/airlines/BJ.png"
  },
  "/imgs/flight/airlines/BK.png": {
    "type": "image/png",
    "etag": "\"c90-tPtV9UQnoL6nJOz8xUtylaRTE28\"",
    "mtime": "2026-11-01T06:39:54.356Z",
    "size": 3216,
    "path": "../public/imgs/flight/airlines/BK.png"
  },
  "/imgs/flight/airlines/BL.png": {
    "type": "image/png",
    "etag": "\"db5-xetqW5s9gXnM+MvRITrjU3YD71E\"",
    "mtime": "2026-11-01T06:39:54.356Z",
    "size": 3509,
    "path": "../public/imgs/flight/airlines/BL.png"
  },
  "/imgs/flight/airlines/BN.png": {
    "type": "image/png",
    "etag": "\"1a06-L0o48l6tFxlIDFyvsmk/sDzOPqM\"",
    "mtime": "2026-11-01T06:39:54.366Z",
    "size": 6662,
    "path": "../public/imgs/flight/airlines/BN.png"
  },
  "/imgs/flight/airlines/BP.png": {
    "type": "image/png",
    "etag": "\"43cb-/fdpJW1NJklMKMTb1gKOmIHwqk8\"",
    "mtime": "2026-11-01T06:39:54.367Z",
    "size": 17355,
    "path": "../public/imgs/flight/airlines/BP.png"
  },
  "/imgs/flight/airlines/BR.png": {
    "type": "image/png",
    "etag": "\"2497-lGge14vI2EzIfFc82Snsm0xCLCo\"",
    "mtime": "2026-11-01T06:39:54.368Z",
    "size": 9367,
    "path": "../public/imgs/flight/airlines/BR.png"
  },
  "/imgs/flight/airlines/british.png": {
    "type": "image/png",
    "etag": "\"44e6-ATqzraSALaNAxh6TKT5cBd7akts\"",
    "mtime": "2026-08-24T08:29:56.310Z",
    "size": 17638,
    "path": "../public/imgs/flight/airlines/british.png"
  },
  "/imgs/flight/airlines/BS.png": {
    "type": "image/png",
    "etag": "\"9ae-ERuLZ2lqQkpIHkwtm0KUDZ+AZqc\"",
    "mtime": "2026-11-01T06:39:54.369Z",
    "size": 2478,
    "path": "../public/imgs/flight/airlines/BS.png"
  },
  "/imgs/flight/airlines/BT.png": {
    "type": "image/png",
    "etag": "\"14c7-mj2Fx4wDZELP37SRdHMpkObu5lM\"",
    "mtime": "2026-11-01T06:39:54.370Z",
    "size": 5319,
    "path": "../public/imgs/flight/airlines/BT.png"
  },
  "/imgs/flight/airlines/BU.png": {
    "type": "image/png",
    "etag": "\"b8b-LK+BbZr1ILPWCMd3jk0bJbwQYCs\"",
    "mtime": "2026-11-01T06:39:54.371Z",
    "size": 2955,
    "path": "../public/imgs/flight/airlines/BU.png"
  },
  "/imgs/flight/airlines/BV.png": {
    "type": "image/png",
    "etag": "\"25b9-7T4e8di2pwfrN0KSLgQWHtoMq30\"",
    "mtime": "2026-11-01T06:39:54.372Z",
    "size": 9657,
    "path": "../public/imgs/flight/airlines/BV.png"
  },
  "/imgs/flight/airlines/BX.png": {
    "type": "image/png",
    "etag": "\"4ad-3bJ3ij62UCOt+gMetvNDGzumfF4\"",
    "mtime": "2026-11-01T06:39:54.372Z",
    "size": 1197,
    "path": "../public/imgs/flight/airlines/BX.png"
  },
  "/imgs/flight/airlines/C3.png": {
    "type": "image/png",
    "etag": "\"13e4-A/qz3aKbbAFcl01cxXxR+tZvxyo\"",
    "mtime": "2026-11-01T06:39:54.373Z",
    "size": 5092,
    "path": "../public/imgs/flight/airlines/C3.png"
  },
  "/imgs/flight/airlines/C4.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.374Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/C4.png"
  },
  "/imgs/flight/airlines/C7.png": {
    "type": "image/png",
    "etag": "\"1b3e-vHgAktcpXBlI63ZsLClqPR0s/hE\"",
    "mtime": "2026-11-01T06:39:54.375Z",
    "size": 6974,
    "path": "../public/imgs/flight/airlines/C7.png"
  },
  "/imgs/flight/airlines/C5.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.374Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/C5.png"
  },
  "/imgs/flight/airlines/C8.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.376Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/C8.png"
  },
  "/imgs/flight/airlines/CA.png": {
    "type": "image/png",
    "etag": "\"3035-LbTmikvoGcMyHUQ7boUoIBIXCoY\"",
    "mtime": "2026-11-01T06:39:54.378Z",
    "size": 12341,
    "path": "../public/imgs/flight/airlines/CA.png"
  },
  "/imgs/flight/airlines/caspian.png": {
    "type": "image/png",
    "etag": "\"207a4-ynzTMJ0pbU2nfsSwNFwzGl1QSJE\"",
    "mtime": "2026-07-13T06:00:39.829Z",
    "size": 133028,
    "path": "../public/imgs/flight/airlines/caspian.png"
  },
  "/imgs/flight/airlines/CB.png": {
    "type": "image/png",
    "etag": "\"3a5c-n6rI/+bTYHOwsONC3mgpVGBwBcA\"",
    "mtime": "2026-11-01T06:39:54.379Z",
    "size": 14940,
    "path": "../public/imgs/flight/airlines/CB.png"
  },
  "/imgs/flight/airlines/C9.png": {
    "type": "image/png",
    "etag": "\"1137-JfCbvUnK8ONJ52I30OQm6DxL6wQ\"",
    "mtime": "2026-11-01T06:39:54.377Z",
    "size": 4407,
    "path": "../public/imgs/flight/airlines/C9.png"
  },
  "/imgs/flight/airlines/CC.png": {
    "type": "image/png",
    "etag": "\"e4f-C8AlG9doGgK1Uyqy9ua2qYtAP9Y\"",
    "mtime": "2026-11-01T06:39:54.380Z",
    "size": 3663,
    "path": "../public/imgs/flight/airlines/CC.png"
  },
  "/imgs/flight/airlines/CE.png": {
    "type": "image/png",
    "etag": "\"12a0-vJx2JfX6qCtrFGygMP9pHy1WMbE\"",
    "mtime": "2026-11-01T06:39:54.381Z",
    "size": 4768,
    "path": "../public/imgs/flight/airlines/CE.png"
  },
  "/imgs/flight/airlines/CF.png": {
    "type": "image/png",
    "etag": "\"34c5-PXnuVSkZDSvXza+/KZPLpcmruUY\"",
    "mtime": "2026-11-01T06:39:54.382Z",
    "size": 13509,
    "path": "../public/imgs/flight/airlines/CF.png"
  },
  "/imgs/flight/airlines/CG.png": {
    "type": "image/png",
    "etag": "\"10fa-npYx+56YNi1Ppa+JKWp03/nWSc0\"",
    "mtime": "2026-11-01T06:39:54.383Z",
    "size": 4346,
    "path": "../public/imgs/flight/airlines/CG.png"
  },
  "/imgs/flight/airlines/CH.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.383Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/CH.png"
  },
  "/imgs/flight/airlines/chabahar.png": {
    "type": "image/png",
    "etag": "\"1d49d-vFTR7Bo4o8MPZmVXrjowralsE1Q\"",
    "mtime": "2026-07-13T06:00:39.830Z",
    "size": 119965,
    "path": "../public/imgs/flight/airlines/chabahar.png"
  },
  "/imgs/flight/airlines/china.png": {
    "type": "image/png",
    "etag": "\"ebd5-3LBceta/4r1+XueR/vyj2Tvoapk\"",
    "mtime": "2026-08-24T08:29:56.313Z",
    "size": 60373,
    "path": "../public/imgs/flight/airlines/china.png"
  },
  "/imgs/flight/airlines/CI.png": {
    "type": "image/png",
    "etag": "\"46d0-+xiRgbjPs6sxFq10DMnXoOOOL4o\"",
    "mtime": "2026-11-01T06:39:54.384Z",
    "size": 18128,
    "path": "../public/imgs/flight/airlines/CI.png"
  },
  "/imgs/flight/airlines/CJ.png": {
    "type": "image/png",
    "etag": "\"6a7-jiFa7tNdMCwyVexVKRpz6x/wot4\"",
    "mtime": "2026-11-01T06:39:54.385Z",
    "size": 1703,
    "path": "../public/imgs/flight/airlines/CJ.png"
  },
  "/imgs/flight/airlines/CL.png": {
    "type": "image/png",
    "etag": "\"24e9-6g1mrbKwDy4FUjh3+hjYIicebh8\"",
    "mtime": "2026-11-01T06:39:54.386Z",
    "size": 9449,
    "path": "../public/imgs/flight/airlines/CL.png"
  },
  "/imgs/flight/airlines/CM.png": {
    "type": "image/png",
    "etag": "\"1d30-+NrV6IdkqNbkYy7teZmsJJBShTY\"",
    "mtime": "2026-11-01T06:39:54.387Z",
    "size": 7472,
    "path": "../public/imgs/flight/airlines/CM.png"
  },
  "/imgs/flight/airlines/CN.png": {
    "type": "image/png",
    "etag": "\"1bae-VWaETOyPKCn47EN1UJZH4u9ThJo\"",
    "mtime": "2026-11-01T06:39:54.388Z",
    "size": 7086,
    "path": "../public/imgs/flight/airlines/CN.png"
  },
  "/imgs/flight/airlines/CO.png": {
    "type": "image/png",
    "etag": "\"251d-yEDNOwJOx3SzZz6IE2kHcz/5AmI\"",
    "mtime": "2026-11-01T06:39:54.389Z",
    "size": 9501,
    "path": "../public/imgs/flight/airlines/CO.png"
  },
  "/imgs/flight/airlines/corendon.png": {
    "type": "image/png",
    "etag": "\"3f3e-wskreSyjAoCoJmZBDRijWLZm7vg\"",
    "mtime": "2026-08-24T08:29:56.315Z",
    "size": 16190,
    "path": "../public/imgs/flight/airlines/corendon.png"
  },
  "/imgs/flight/airlines/CQ.png": {
    "type": "image/png",
    "etag": "\"d9f-D5zd+Mmxs749kCkzaFQQiRUhBKM\"",
    "mtime": "2026-11-01T06:39:54.390Z",
    "size": 3487,
    "path": "../public/imgs/flight/airlines/CQ.png"
  },
  "/imgs/flight/airlines/CR.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.390Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/CR.png"
  },
  "/imgs/flight/airlines/CT.png": {
    "type": "image/png",
    "etag": "\"267d-ieEs138v0RnJyyUI4ASL41X9mLs\"",
    "mtime": "2026-11-01T06:39:54.391Z",
    "size": 9853,
    "path": "../public/imgs/flight/airlines/CT.png"
  },
  "/imgs/flight/airlines/CU.png": {
    "type": "image/png",
    "etag": "\"c22-yVNMrrgwFMN2f2IYRd8/s2Zvs1Q\"",
    "mtime": "2026-11-01T06:39:54.392Z",
    "size": 3106,
    "path": "../public/imgs/flight/airlines/CU.png"
  },
  "/imgs/flight/airlines/CW.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.393Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/CW.png"
  },
  "/imgs/flight/airlines/CX.png": {
    "type": "image/png",
    "etag": "\"ccd-QE8RNreqFga1/ZpMeklAvlwYUtg\"",
    "mtime": "2026-11-01T06:39:54.394Z",
    "size": 3277,
    "path": "../public/imgs/flight/airlines/CX.png"
  },
  "/imgs/flight/airlines/CY.png": {
    "type": "image/png",
    "etag": "\"a14-YyxvsYj/XYbfwy0/NfMMgShzp4M\"",
    "mtime": "2026-11-01T06:39:54.395Z",
    "size": 2580,
    "path": "../public/imgs/flight/airlines/CY.png"
  },
  "/imgs/flight/airlines/CZ.png": {
    "type": "image/png",
    "etag": "\"19f9-gvnrTUGMkwMSiERdOg2l9px3n2U\"",
    "mtime": "2026-11-01T06:39:54.396Z",
    "size": 6649,
    "path": "../public/imgs/flight/airlines/CZ.png"
  },
  "/imgs/flight/airlines/D2.png": {
    "type": "image/png",
    "etag": "\"218a-12iBPwwkMWianztzDWOrtzFi7kM\"",
    "mtime": "2026-11-01T06:39:54.397Z",
    "size": 8586,
    "path": "../public/imgs/flight/airlines/D2.png"
  },
  "/imgs/flight/airlines/D3.png": {
    "type": "image/png",
    "etag": "\"25bc-c7P07fTy68WZu6rUUePd2rzcSv4\"",
    "mtime": "2026-11-01T06:39:54.398Z",
    "size": 9660,
    "path": "../public/imgs/flight/airlines/D3.png"
  },
  "/imgs/flight/airlines/D4.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.398Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/D4.png"
  },
  "/imgs/flight/airlines/D6.png": {
    "type": "image/png",
    "etag": "\"188f-qCoLUK7Eifj1clZ6FPa4frt6gYI\"",
    "mtime": "2026-11-01T06:39:54.399Z",
    "size": 6287,
    "path": "../public/imgs/flight/airlines/D6.png"
  },
  "/imgs/flight/airlines/D7.png": {
    "type": "image/png",
    "etag": "\"1b28-Lharq+E7hvu1F+gXmDhR1xQ4chI\"",
    "mtime": "2026-11-01T06:39:54.400Z",
    "size": 6952,
    "path": "../public/imgs/flight/airlines/D7.png"
  },
  "/imgs/flight/airlines/D9.png": {
    "type": "image/png",
    "etag": "\"2d86-9T51nlg1PPQh57wsCRPDIxJjQtc\"",
    "mtime": "2026-11-01T06:39:54.401Z",
    "size": 11654,
    "path": "../public/imgs/flight/airlines/D9.png"
  },
  "/imgs/flight/airlines/DB.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.402Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/DB.png"
  },
  "/imgs/flight/airlines/DC.png": {
    "type": "image/png",
    "etag": "\"197d-6kXVn3g1WtSy6a0Ij7HCjpSXOIc\"",
    "mtime": "2026-11-01T06:39:54.403Z",
    "size": 6525,
    "path": "../public/imgs/flight/airlines/DC.png"
  },
  "/imgs/flight/airlines/DD.png": {
    "type": "image/png",
    "etag": "\"1158-l9Uz2WtRr0MMLNfepjNrCE+TKVA\"",
    "mtime": "2026-11-01T06:39:54.404Z",
    "size": 4440,
    "path": "../public/imgs/flight/airlines/DD.png"
  },
  "/imgs/flight/airlines/DE.png": {
    "type": "image/png",
    "etag": "\"174d-tJNQwofYnQdTVne1vgCZmkvzXUo\"",
    "mtime": "2026-11-01T06:39:54.405Z",
    "size": 5965,
    "path": "../public/imgs/flight/airlines/DE.png"
  },
  "/imgs/flight/airlines/DG.png": {
    "type": "image/png",
    "etag": "\"1b51-ECzLob8JFittzWJC0zfqPQi0H1I\"",
    "mtime": "2026-11-01T06:39:54.406Z",
    "size": 6993,
    "path": "../public/imgs/flight/airlines/DG.png"
  },
  "/imgs/flight/airlines/DH.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.407Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/DH.png"
  },
  "/imgs/flight/airlines/DI.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.407Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/DI.png"
  },
  "/imgs/flight/airlines/DJ.png": {
    "type": "image/png",
    "etag": "\"bb8-Wyqi4ZcPnVYwOw45pznDTLJ+q+U\"",
    "mtime": "2026-11-01T06:39:54.408Z",
    "size": 3000,
    "path": "../public/imgs/flight/airlines/DJ.png"
  },
  "/imgs/flight/airlines/DL.png": {
    "type": "image/png",
    "etag": "\"ee7-QEF/BMKtv+aT6wnG6CCfcY8kPc8\"",
    "mtime": "2026-11-01T06:39:54.409Z",
    "size": 3815,
    "path": "../public/imgs/flight/airlines/DL.png"
  },
  "/imgs/flight/airlines/DN.png": {
    "type": "image/png",
    "etag": "\"1003-gVIR1nUYn/r0w5MFH/QC0bVGA34\"",
    "mtime": "2026-11-01T06:39:54.410Z",
    "size": 4099,
    "path": "../public/imgs/flight/airlines/DN.png"
  },
  "/imgs/flight/airlines/DO.png": {
    "type": "image/png",
    "etag": "\"f15-QuJlXstWgF5RiIcLb0osnTrQtJ8\"",
    "mtime": "2026-11-01T06:39:54.415Z",
    "size": 3861,
    "path": "../public/imgs/flight/airlines/DO.png"
  },
  "/imgs/flight/airlines/DT.png": {
    "type": "image/png",
    "etag": "\"43fc-B54Hkoq8pYZKFaD9PFbP6rs4m24\"",
    "mtime": "2026-11-01T06:39:54.420Z",
    "size": 17404,
    "path": "../public/imgs/flight/airlines/DT.png"
  },
  "/imgs/flight/airlines/DU.png": {
    "type": "image/png",
    "etag": "\"c36-5gvCnVxkUM6P46GZjydP+aG8HZg\"",
    "mtime": "2026-11-01T06:39:54.432Z",
    "size": 3126,
    "path": "../public/imgs/flight/airlines/DU.png"
  },
  "/imgs/flight/airlines/DV.png": {
    "type": "image/png",
    "etag": "\"201c-qeTd0UaeP54qwifwzaAwnymdAyE\"",
    "mtime": "2026-11-01T06:39:54.433Z",
    "size": 8220,
    "path": "../public/imgs/flight/airlines/DV.png"
  },
  "/imgs/flight/airlines/DX.png": {
    "type": "image/png",
    "etag": "\"4540-QOBFR19cDoN+wD1kUnrS3HfLMMA\"",
    "mtime": "2026-11-01T06:39:54.434Z",
    "size": 17728,
    "path": "../public/imgs/flight/airlines/DX.png"
  },
  "/imgs/flight/airlines/DY.png": {
    "type": "image/png",
    "etag": "\"b84-KhIP1gOgeAyA8FkURmIVWkGKgLc\"",
    "mtime": "2026-11-01T06:39:54.435Z",
    "size": 2948,
    "path": "../public/imgs/flight/airlines/DY.png"
  },
  "/imgs/flight/airlines/E0.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.435Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/E0.png"
  },
  "/imgs/flight/airlines/E3.png": {
    "type": "image/png",
    "etag": "\"2052-fl0+Zy57R8LEwu7wIR6xpDAMf98\"",
    "mtime": "2026-11-01T06:39:54.436Z",
    "size": 8274,
    "path": "../public/imgs/flight/airlines/E3.png"
  },
  "/imgs/flight/airlines/E4.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.437Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/E4.png"
  },
  "/imgs/flight/airlines/E5.png": {
    "type": "image/png",
    "etag": "\"182d-9F5vJ8sSr611OLq0Qdg8ACnoU9g\"",
    "mtime": "2026-11-01T06:39:54.439Z",
    "size": 6189,
    "path": "../public/imgs/flight/airlines/E5.png"
  },
  "/imgs/flight/airlines/E8.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.440Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/E8.png"
  },
  "/imgs/flight/airlines/EA.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.440Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/EA.png"
  },
  "/imgs/flight/airlines/easyjet.png": {
    "type": "image/png",
    "etag": "\"999c-Sn4Fn7wws8gGmbO6TybFOor13sM\"",
    "mtime": "2026-08-24T08:29:56.317Z",
    "size": 39324,
    "path": "../public/imgs/flight/airlines/easyjet.png"
  },
  "/imgs/flight/airlines/EC.png": {
    "type": "image/png",
    "etag": "\"10c0-d+ONW8/ip1tNLj39XxrSUQPRAAY\"",
    "mtime": "2026-11-01T06:39:54.441Z",
    "size": 4288,
    "path": "../public/imgs/flight/airlines/EC.png"
  },
  "/imgs/flight/airlines/EE.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.442Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/EE.png"
  },
  "/imgs/flight/airlines/EF.png": {
    "type": "image/png",
    "etag": "\"55b-xSfFwYjy9Hpr6IQqg9myO9bcCr0\"",
    "mtime": "2026-11-01T06:39:54.443Z",
    "size": 1371,
    "path": "../public/imgs/flight/airlines/EF.png"
  },
  "/imgs/flight/airlines/EG.png": {
    "type": "image/png",
    "etag": "\"13fd-ZEXFyfOyF8uO+Ekf4w2N/qeCqxk\"",
    "mtime": "2026-11-01T06:39:54.444Z",
    "size": 5117,
    "path": "../public/imgs/flight/airlines/EG.png"
  },
  "/imgs/flight/airlines/egyptair.png": {
    "type": "image/png",
    "etag": "\"74f3-cNhv+DoJIvMNEj8HFlwTDYoiL5o\"",
    "mtime": "2026-08-24T08:29:56.319Z",
    "size": 29939,
    "path": "../public/imgs/flight/airlines/egyptair.png"
  },
  "/imgs/flight/airlines/EI.png": {
    "type": "image/png",
    "etag": "\"3488-ziAf+zXFGj0cyFLw2QTkmQ4ADKw\"",
    "mtime": "2026-11-01T06:39:54.445Z",
    "size": 13448,
    "path": "../public/imgs/flight/airlines/EI.png"
  },
  "/imgs/flight/airlines/EJ.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.445Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/EJ.png"
  },
  "/imgs/flight/airlines/EK.png": {
    "type": "image/png",
    "etag": "\"39cd-7lv/0dPGOgREykFzZZMqpPaWMns\"",
    "mtime": "2026-11-01T06:39:54.446Z",
    "size": 14797,
    "path": "../public/imgs/flight/airlines/EK.png"
  },
  "/imgs/flight/airlines/EL.png": {
    "type": "image/png",
    "etag": "\"803-2mBXkQvOQ6CFRaYaWJdFBuf4PY8\"",
    "mtime": "2026-11-01T06:39:54.447Z",
    "size": 2051,
    "path": "../public/imgs/flight/airlines/EL.png"
  },
  "/imgs/flight/airlines/emirates.png": {
    "type": "image/png",
    "etag": "\"bdd-yypxvwvw/gjbOd4sRC4Ba7kbp60\"",
    "mtime": "2026-08-24T08:29:56.320Z",
    "size": 3037,
    "path": "../public/imgs/flight/airlines/emirates.png"
  },
  "/imgs/flight/airlines/EN.png": {
    "type": "image/png",
    "etag": "\"2d00-Tk+NIlA0lW2+QalRQNBv63fZWKA\"",
    "mtime": "2026-11-01T06:39:54.448Z",
    "size": 11520,
    "path": "../public/imgs/flight/airlines/EN.png"
  },
  "/imgs/flight/airlines/EO.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.449Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/EO.png"
  },
  "/imgs/flight/airlines/EP.png": {
    "type": "image/png",
    "etag": "\"1555-Oxri2RkGCwYL4jOEc+lGA7mRUO8\"",
    "mtime": "2026-11-01T06:39:54.450Z",
    "size": 5461,
    "path": "../public/imgs/flight/airlines/EP.png"
  },
  "/imgs/flight/airlines/EQ.png": {
    "type": "image/png",
    "etag": "\"ac4-EnjztavC6blz44gCg+/FZbORQBo\"",
    "mtime": "2026-11-01T06:39:54.451Z",
    "size": 2756,
    "path": "../public/imgs/flight/airlines/EQ.png"
  },
  "/imgs/flight/airlines/ET.png": {
    "type": "image/png",
    "etag": "\"1283-ujLcNAOJn7tX0haOZJEIUC1OA0Y\"",
    "mtime": "2026-11-01T06:39:54.452Z",
    "size": 4739,
    "path": "../public/imgs/flight/airlines/ET.png"
  },
  "/imgs/flight/airlines/ethiopian.png": {
    "type": "image/png",
    "etag": "\"36cb-v8Ng1pzAClaFgPnCSQHVzZB4NzI\"",
    "mtime": "2026-08-24T08:29:56.321Z",
    "size": 14027,
    "path": "../public/imgs/flight/airlines/ethiopian.png"
  },
  "/imgs/flight/airlines/etihad.png": {
    "type": "image/png",
    "etag": "\"3457-fjqE3kJWx6/F8/YDIqWC8qxG6XE\"",
    "mtime": "2026-08-24T08:29:56.323Z",
    "size": 13399,
    "path": "../public/imgs/flight/airlines/etihad.png"
  },
  "/imgs/flight/airlines/EU.png": {
    "type": "image/png",
    "etag": "\"12e5-2LP89tl1CN6rbA+2j1JEKfBtlnA\"",
    "mtime": "2026-11-01T06:39:54.453Z",
    "size": 4837,
    "path": "../public/imgs/flight/airlines/EU.png"
  },
  "/imgs/flight/airlines/EW.png": {
    "type": "image/png",
    "etag": "\"14ba-K1GD+satEOha+dkKEw6qgn9TOG0\"",
    "mtime": "2026-11-01T06:39:54.453Z",
    "size": 5306,
    "path": "../public/imgs/flight/airlines/EW.png"
  },
  "/imgs/flight/airlines/EY.png": {
    "type": "image/png",
    "etag": "\"183c-3tj3o79jZuBrYGc9jSDBcXA0Nhg\"",
    "mtime": "2026-11-01T06:39:54.455Z",
    "size": 6204,
    "path": "../public/imgs/flight/airlines/EY.png"
  },
  "/imgs/flight/airlines/EZ.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.456Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/EZ.png"
  },
  "/imgs/flight/airlines/F2.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.456Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/F2.png"
  },
  "/imgs/flight/airlines/F5.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.457Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/F5.png"
  },
  "/imgs/flight/airlines/F7.png": {
    "type": "image/png",
    "etag": "\"e78-aeeJ6AFpkXxvExp4USNGinItzbM\"",
    "mtime": "2026-11-01T06:39:54.458Z",
    "size": 3704,
    "path": "../public/imgs/flight/airlines/F7.png"
  },
  "/imgs/flight/airlines/F9.png": {
    "type": "image/png",
    "etag": "\"805-ktCXBhDxD/JqoN+YAEZLdAdE9Y4\"",
    "mtime": "2026-11-01T06:39:54.458Z",
    "size": 2053,
    "path": "../public/imgs/flight/airlines/F9.png"
  },
  "/imgs/flight/airlines/FB.png": {
    "type": "image/png",
    "etag": "\"821-QOTtLqDUEHdYgVTYKj9BbL2O07M\"",
    "mtime": "2026-11-01T06:39:54.459Z",
    "size": 2081,
    "path": "../public/imgs/flight/airlines/FB.png"
  },
  "/imgs/flight/airlines/FD.png": {
    "type": "image/png",
    "etag": "\"1b28-Lharq+E7hvu1F+gXmDhR1xQ4chI\"",
    "mtime": "2026-11-01T06:39:54.459Z",
    "size": 6952,
    "path": "../public/imgs/flight/airlines/FD.png"
  },
  "/imgs/flight/airlines/FE.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.460Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/FE.png"
  },
  "/imgs/flight/airlines/FG.png": {
    "type": "image/png",
    "etag": "\"778-YLLRaxdaihMLsEh2NLks54elksg\"",
    "mtime": "2026-11-01T06:39:54.461Z",
    "size": 1912,
    "path": "../public/imgs/flight/airlines/FG.png"
  },
  "/imgs/flight/airlines/FH.png": {
    "type": "image/png",
    "etag": "\"828-tRImEirvV2nH0fz3x0zXiE0U+7M\"",
    "mtime": "2026-11-01T06:39:54.462Z",
    "size": 2088,
    "path": "../public/imgs/flight/airlines/FH.png"
  },
  "/imgs/flight/airlines/FI.png": {
    "type": "image/png",
    "etag": "\"2eb7-Fl/MkTKuYq9Dtyjv7QRmGowmLxw\"",
    "mtime": "2026-11-01T06:39:54.463Z",
    "size": 11959,
    "path": "../public/imgs/flight/airlines/FI.png"
  },
  "/imgs/flight/airlines/FJ.png": {
    "type": "image/png",
    "etag": "\"eff-XM7OpZrLiXzd2myceLFfDKwQLRI\"",
    "mtime": "2026-11-01T06:39:54.464Z",
    "size": 3839,
    "path": "../public/imgs/flight/airlines/FJ.png"
  },
  "/imgs/flight/airlines/FL.png": {
    "type": "image/png",
    "etag": "\"4088-a2BkoS3q0I/oB6/jlcpplHMDGbo\"",
    "mtime": "2026-11-01T06:39:54.465Z",
    "size": 16520,
    "path": "../public/imgs/flight/airlines/FL.png"
  },
  "/imgs/flight/airlines/flydubai.png": {
    "type": "image/png",
    "etag": "\"46ba-kVjAwvwbJFbbUSgjN09Zj4d5j7M\"",
    "mtime": "2026-08-24T08:29:56.325Z",
    "size": 18106,
    "path": "../public/imgs/flight/airlines/flydubai.png"
  },
  "/imgs/flight/airlines/flypersia.png": {
    "type": "image/png",
    "etag": "\"10e1a-gJIhNN7PIKlAc3dkDNciR4tRJac\"",
    "mtime": "2026-07-13T06:00:39.831Z",
    "size": 69146,
    "path": "../public/imgs/flight/airlines/flypersia.png"
  },
  "/imgs/flight/airlines/FM.png": {
    "type": "image/png",
    "etag": "\"798-3oj+rpNPoLa9n48WKfDhun6rfoQ\"",
    "mtime": "2026-11-01T06:39:54.466Z",
    "size": 1944,
    "path": "../public/imgs/flight/airlines/FM.png"
  },
  "/imgs/flight/airlines/FN.png": {
    "type": "image/png",
    "etag": "\"bf6-eCqpTc++Ew/doqlUmivgaw7tGa0\"",
    "mtime": "2026-11-01T06:39:54.467Z",
    "size": 3062,
    "path": "../public/imgs/flight/airlines/FN.png"
  },
  "/imgs/flight/airlines/FO.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.467Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/FO.png"
  },
  "/imgs/flight/airlines/fp.png": {
    "type": "image/png",
    "etag": "\"168e-BMZ40Ve7oe8Pai5HuBp3j5142ek\"",
    "mtime": "2026-11-01T06:39:55.064Z",
    "size": 5774,
    "path": "../public/imgs/flight/airlines/fp.png"
  },
  "/imgs/flight/airlines/FR.png": {
    "type": "image/png",
    "etag": "\"20d2-Rtx4FRp6Glp8NhdNKEXYGLSYaUs\"",
    "mtime": "2026-11-01T06:39:54.468Z",
    "size": 8402,
    "path": "../public/imgs/flight/airlines/FR.png"
  },
  "/imgs/flight/airlines/FT.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.470Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/FT.png"
  },
  "/imgs/flight/airlines/FS.png": {
    "type": "image/png",
    "etag": "\"241c-DH0YaL9ZSGkjVvtA8LF1ambUoos\"",
    "mtime": "2026-11-01T06:39:54.469Z",
    "size": 9244,
    "path": "../public/imgs/flight/airlines/FS.png"
  },
  "/imgs/flight/airlines/FV.png": {
    "type": "image/png",
    "etag": "\"20ed-qIT2O7p1VpYeZQQjJ4u6Xv/5aag\"",
    "mtime": "2026-11-01T06:39:54.471Z",
    "size": 8429,
    "path": "../public/imgs/flight/airlines/FV.png"
  },
  "/imgs/flight/airlines/FW.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.472Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/FW.png"
  },
  "/imgs/flight/airlines/FZ.png": {
    "type": "image/png",
    "etag": "\"61c-4OOsuczOkdFKBCRX4LeU4gLhyNo\"",
    "mtime": "2026-11-01T06:39:54.509Z",
    "size": 1564,
    "path": "../public/imgs/flight/airlines/FZ.png"
  },
  "/imgs/flight/airlines/G0.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.510Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/G0.png"
  },
  "/imgs/flight/airlines/FY.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.473Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/FY.png"
  },
  "/imgs/flight/airlines/G3.png": {
    "type": "image/png",
    "etag": "\"f75-+AW40ObroFheJ6qU/kX9Sb30qJM\"",
    "mtime": "2026-11-01T06:39:54.511Z",
    "size": 3957,
    "path": "../public/imgs/flight/airlines/G3.png"
  },
  "/imgs/flight/airlines/G4.png": {
    "type": "image/png",
    "etag": "\"2e08-Oslt8XFVjF1hhOa8nn9Wxd2+ZZw\"",
    "mtime": "2026-11-01T06:39:54.512Z",
    "size": 11784,
    "path": "../public/imgs/flight/airlines/G4.png"
  },
  "/imgs/flight/airlines/G8.png": {
    "type": "image/png",
    "etag": "\"23b8-uVmu28LPwP7QQvA5GjG+dMSW/00\"",
    "mtime": "2026-11-01T06:39:54.513Z",
    "size": 9144,
    "path": "../public/imgs/flight/airlines/G8.png"
  },
  "/imgs/flight/airlines/G9.png": {
    "type": "image/png",
    "etag": "\"33c8-KVxKxhqJA15fRmV4MlxqOJ2T/s8\"",
    "mtime": "2026-11-01T06:39:54.514Z",
    "size": 13256,
    "path": "../public/imgs/flight/airlines/G9.png"
  },
  "/imgs/flight/airlines/GA.png": {
    "type": "image/png",
    "etag": "\"ed6-vjrtXjGvK5y3UOUnbHL86gNFlX4\"",
    "mtime": "2026-11-01T06:39:54.515Z",
    "size": 3798,
    "path": "../public/imgs/flight/airlines/GA.png"
  },
  "/imgs/flight/airlines/GE.png": {
    "type": "image/png",
    "etag": "\"5183-SUU0/QSMMc+LIcRtYqw1+N3c4UY\"",
    "mtime": "2026-11-01T06:39:54.516Z",
    "size": 20867,
    "path": "../public/imgs/flight/airlines/GE.png"
  },
  "/imgs/flight/airlines/GF.png": {
    "type": "image/png",
    "etag": "\"14c5-We08A3rww1FIcTVesFvRP+4d/hc\"",
    "mtime": "2026-11-01T06:39:54.518Z",
    "size": 5317,
    "path": "../public/imgs/flight/airlines/GF.png"
  },
  "/imgs/flight/airlines/gheshm.png": {
    "type": "image/png",
    "etag": "\"28ad4-6J8n/6DZTJ7Znhgy5oAjrBwps24\"",
    "mtime": "2026-07-13T06:00:39.833Z",
    "size": 166612,
    "path": "../public/imgs/flight/airlines/gheshm.png"
  },
  "/imgs/flight/airlines/GI.png": {
    "type": "image/png",
    "etag": "\"147d-wMf+rWl8QLrAaWp2fpjiUJd9qJc\"",
    "mtime": "2026-11-01T06:39:54.519Z",
    "size": 5245,
    "path": "../public/imgs/flight/airlines/GI.png"
  },
  "/imgs/flight/airlines/GJ.png": {
    "type": "image/png",
    "etag": "\"2d54-3mSPO/zWHQId7aJotaRrHohB2sc\"",
    "mtime": "2026-11-01T06:39:54.520Z",
    "size": 11604,
    "path": "../public/imgs/flight/airlines/GJ.png"
  },
  "/imgs/flight/airlines/GL.png": {
    "type": "image/png",
    "etag": "\"3350-uXatytzm6oszh/cYOYzRVvUXa20\"",
    "mtime": "2026-11-01T06:39:54.521Z",
    "size": 13136,
    "path": "../public/imgs/flight/airlines/GL.png"
  },
  "/imgs/flight/airlines/GQ.png": {
    "type": "image/png",
    "etag": "\"d3f-xb6mwa4YDJtZDjvEu3phihIg9Do\"",
    "mtime": "2026-11-01T06:39:54.522Z",
    "size": 3391,
    "path": "../public/imgs/flight/airlines/GQ.png"
  },
  "/imgs/flight/airlines/GR.png": {
    "type": "image/png",
    "etag": "\"114d-W4GjJuQzgG2jQQgXslP2kZOSNhg\"",
    "mtime": "2026-11-01T06:39:54.524Z",
    "size": 4429,
    "path": "../public/imgs/flight/airlines/GR.png"
  },
  "/imgs/flight/airlines/GS.png": {
    "type": "image/png",
    "etag": "\"106f-qZ4G/JpJOwCZPTnGC8AlwMDC5xA\"",
    "mtime": "2026-11-01T06:39:54.525Z",
    "size": 4207,
    "path": "../public/imgs/flight/airlines/GS.png"
  },
  "/imgs/flight/airlines/GV.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.526Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/GV.png"
  },
  "/imgs/flight/airlines/GT.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.525Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/GT.png"
  },
  "/imgs/flight/airlines/GZ.png": {
    "type": "image/png",
    "etag": "\"13b0-4Kld/i8DFXNPrJhj8PG+ZgGKSIU\"",
    "mtime": "2026-11-01T06:39:54.529Z",
    "size": 5040,
    "path": "../public/imgs/flight/airlines/GZ.png"
  },
  "/imgs/flight/airlines/GW.png": {
    "type": "image/png",
    "etag": "\"11dc-mqJBUIxfvsT0Q0t+J5W1GuztMfM\"",
    "mtime": "2026-11-01T06:39:54.527Z",
    "size": 4572,
    "path": "../public/imgs/flight/airlines/GW.png"
  },
  "/imgs/flight/airlines/H4.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.530Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/H4.png"
  },
  "/imgs/flight/airlines/GY.png": {
    "type": "image/png",
    "etag": "\"5e6-UN25L5+cl1jfQ0Lh4hyKLxjGc4o\"",
    "mtime": "2026-11-01T06:39:54.528Z",
    "size": 1510,
    "path": "../public/imgs/flight/airlines/GY.png"
  },
  "/imgs/flight/airlines/H2.png": {
    "type": "image/png",
    "etag": "\"a17-vujdSyMR4s7Ip/6cpNCnHSv0JJY\"",
    "mtime": "2026-11-01T06:39:54.530Z",
    "size": 2583,
    "path": "../public/imgs/flight/airlines/H2.png"
  },
  "/imgs/flight/airlines/H7.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.531Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/H7.png"
  },
  "/imgs/flight/airlines/H9.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.532Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/H9.png"
  },
  "/imgs/flight/airlines/HA.png": {
    "type": "image/png",
    "etag": "\"18b6-Uy+jGmWwjsbVc+z4qiegz/zvPZQ\"",
    "mtime": "2026-11-01T06:39:54.533Z",
    "size": 6326,
    "path": "../public/imgs/flight/airlines/HA.png"
  },
  "/imgs/flight/airlines/H8.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.531Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/H8.png"
  },
  "/imgs/flight/airlines/HB.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.533Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/HB.png"
  },
  "/imgs/flight/airlines/HE.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.534Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/HE.png"
  },
  "/imgs/flight/airlines/HG.png": {
    "type": "image/png",
    "etag": "\"26ce-IklbOyFZ4SVfZC/ge9U4r7YmpB4\"",
    "mtime": "2026-11-01T06:39:54.536Z",
    "size": 9934,
    "path": "../public/imgs/flight/airlines/HG.png"
  },
  "/imgs/flight/airlines/HD.png": {
    "type": "image/png",
    "etag": "\"2b9d-zI6o5SW391YviQXBJrfT5up+uqM\"",
    "mtime": "2026-11-01T06:39:54.534Z",
    "size": 11165,
    "path": "../public/imgs/flight/airlines/HD.png"
  },
  "/imgs/flight/airlines/HH.png": {
    "type": "image/png",
    "etag": "\"1a22-n8LBy2gtj/8TNk2/fN00jMRWfF4\"",
    "mtime": "2026-11-01T06:39:54.537Z",
    "size": 6690,
    "path": "../public/imgs/flight/airlines/HH.png"
  },
  "/imgs/flight/airlines/HM.png": {
    "type": "image/png",
    "etag": "\"2c18-BCVbsaaCYXp9U8qgENvcb/zI6W8\"",
    "mtime": "2026-11-01T06:39:54.539Z",
    "size": 11288,
    "path": "../public/imgs/flight/airlines/HM.png"
  },
  "/imgs/flight/airlines/HO.png": {
    "type": "image/png",
    "etag": "\"3e33-IJ7HN8OpZidWYNRrhvwcYzqvYwI\"",
    "mtime": "2026-11-01T06:39:54.541Z",
    "size": 15923,
    "path": "../public/imgs/flight/airlines/HO.png"
  },
  "/imgs/flight/airlines/HR.png": {
    "type": "image/png",
    "etag": "\"2f40-Pjd0yqwOeAkrf543i1mP7TZ9Jn4\"",
    "mtime": "2026-11-01T06:39:54.543Z",
    "size": 12096,
    "path": "../public/imgs/flight/airlines/HR.png"
  },
  "/imgs/flight/airlines/HT.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.543Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/HT.png"
  },
  "/imgs/flight/airlines/HV.png": {
    "type": "image/png",
    "etag": "\"13ed-M36MmdFdsUDvd/tb2QrEsePC/Sw\"",
    "mtime": "2026-11-01T06:39:54.545Z",
    "size": 5101,
    "path": "../public/imgs/flight/airlines/HV.png"
  },
  "/imgs/flight/airlines/HU.png": {
    "type": "image/png",
    "etag": "\"ee2-s54tPzlQpsgI9T/yJdgnBAAamBc\"",
    "mtime": "2026-11-01T06:39:54.544Z",
    "size": 3810,
    "path": "../public/imgs/flight/airlines/HU.png"
  },
  "/imgs/flight/airlines/HW.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.546Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/HW.png"
  },
  "/imgs/flight/airlines/HY.png": {
    "type": "image/png",
    "etag": "\"2aef-XXqTZA8CIof87ef3NR/n6r+lkb4\"",
    "mtime": "2026-11-01T06:39:54.548Z",
    "size": 10991,
    "path": "../public/imgs/flight/airlines/HY.png"
  },
  "/imgs/flight/airlines/HX.png": {
    "type": "image/png",
    "etag": "\"172c-LAQigCTsE4T4WN/2lyA969SvBzE\"",
    "mtime": "2026-11-01T06:39:54.547Z",
    "size": 5932,
    "path": "../public/imgs/flight/airlines/HX.png"
  },
  "/imgs/flight/airlines/I2.png": {
    "type": "image/png",
    "etag": "\"700-rM1IO/0zJvm13gqI7KQtNptLTlo\"",
    "mtime": "2026-11-01T06:39:54.550Z",
    "size": 1792,
    "path": "../public/imgs/flight/airlines/I2.png"
  },
  "/imgs/flight/airlines/HZ.png": {
    "type": "image/png",
    "etag": "\"1179-EPZtJ45WCMQmWgFKRRdCHG2mN8c\"",
    "mtime": "2026-11-01T06:39:54.549Z",
    "size": 4473,
    "path": "../public/imgs/flight/airlines/HZ.png"
  },
  "/imgs/flight/airlines/I4.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.552Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/I4.png"
  },
  "/imgs/flight/airlines/I3.png": {
    "type": "image/png",
    "etag": "\"1a1c-stRfub+rfDsHEzO/+oa1fupI0kA\"",
    "mtime": "2026-11-01T06:39:54.551Z",
    "size": 6684,
    "path": "../public/imgs/flight/airlines/I3.png"
  },
  "/imgs/flight/airlines/I7.png": {
    "type": "image/png",
    "etag": "\"1a71-mm96x7rWN/Og2Pd4jeqIoHFgoGQ\"",
    "mtime": "2026-11-01T06:39:54.553Z",
    "size": 6769,
    "path": "../public/imgs/flight/airlines/I7.png"
  },
  "/imgs/flight/airlines/I9.png": {
    "type": "image/png",
    "etag": "\"34a4-pIMhQjUFtbWbaqXmNi/eslAsewM\"",
    "mtime": "2026-11-01T06:39:54.554Z",
    "size": 13476,
    "path": "../public/imgs/flight/airlines/I9.png"
  },
  "/imgs/flight/airlines/I5.png": {
    "type": "image/png",
    "etag": "\"1b28-Lharq+E7hvu1F+gXmDhR1xQ4chI\"",
    "mtime": "2026-11-01T06:39:54.552Z",
    "size": 6952,
    "path": "../public/imgs/flight/airlines/I5.png"
  },
  "/imgs/flight/airlines/IA.png": {
    "type": "image/png",
    "etag": "\"c73-658EiYYtkpkzhdr1o7LhV9EEjLU\"",
    "mtime": "2026-11-01T06:39:54.558Z",
    "size": 3187,
    "path": "../public/imgs/flight/airlines/IA.png"
  },
  "/imgs/flight/airlines/IB.png": {
    "type": "image/png",
    "etag": "\"269f-xDKuvCkEe9bWb9Hl/seLMIZU8tA\"",
    "mtime": "2026-11-01T06:39:54.559Z",
    "size": 9887,
    "path": "../public/imgs/flight/airlines/IB.png"
  },
  "/imgs/flight/airlines/iberia.png": {
    "type": "image/png",
    "etag": "\"45ac-NE2g+dVtIMMwDr4u1YlmDORjPXM\"",
    "mtime": "2026-08-24T08:29:56.328Z",
    "size": 17836,
    "path": "../public/imgs/flight/airlines/iberia.png"
  },
  "/imgs/flight/airlines/IC.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.559Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/IC.png"
  },
  "/imgs/flight/airlines/IE.png": {
    "type": "image/png",
    "etag": "\"fed-POSPoVmdNSbOzNEWlMGSsICWiDY\"",
    "mtime": "2026-11-01T06:39:54.560Z",
    "size": 4077,
    "path": "../public/imgs/flight/airlines/IE.png"
  },
  "/imgs/flight/airlines/IF.png": {
    "type": "image/png",
    "etag": "\"d8a-/VpwmUMg7RDZbhGfH0Qc/yhHk6s\"",
    "mtime": "2026-11-01T06:39:54.561Z",
    "size": 3466,
    "path": "../public/imgs/flight/airlines/IF.png"
  },
  "/imgs/flight/airlines/IG.png": {
    "type": "image/png",
    "etag": "\"396d-who9Lq1WCzYCi48FZzIlfb01Kis\"",
    "mtime": "2026-11-01T06:39:54.581Z",
    "size": 14701,
    "path": "../public/imgs/flight/airlines/IG.png"
  },
  "/imgs/flight/airlines/IH.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.581Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/IH.png"
  },
  "/imgs/flight/airlines/IK.png": {
    "type": "image/png",
    "etag": "\"c61-qDJc03bcwLQcMtmt9C7GsYZLdgI\"",
    "mtime": "2026-11-01T06:39:54.582Z",
    "size": 3169,
    "path": "../public/imgs/flight/airlines/IK.png"
  },
  "/imgs/flight/airlines/IN.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.583Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/IN.png"
  },
  "/imgs/flight/airlines/IP.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.584Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/IP.png"
  },
  "/imgs/flight/airlines/IQ.png": {
    "type": "image/png",
    "etag": "\"b20-nr/zAlaQN4kX6mkuUk+Q9CwRXC4\"",
    "mtime": "2026-11-01T06:39:54.585Z",
    "size": 2848,
    "path": "../public/imgs/flight/airlines/IQ.png"
  },
  "/imgs/flight/airlines/IR.png": {
    "type": "image/png",
    "etag": "\"2170-3C85IFgIbJUZDaNKELc3uWr37gI\"",
    "mtime": "2026-11-01T06:39:54.586Z",
    "size": 8560,
    "path": "../public/imgs/flight/airlines/IR.png"
  },
  "/imgs/flight/airlines/iranair.png": {
    "type": "image/png",
    "etag": "\"66ac-DXsAo0W/OcKtKhHnTRy9SbDt3sA\"",
    "mtime": "2026-07-13T06:00:39.834Z",
    "size": 26284,
    "path": "../public/imgs/flight/airlines/iranair.png"
  },
  "/imgs/flight/airlines/IRU.png": {
    "type": "image/png",
    "etag": "\"2f0b-N2X+TowLkYHM0wzk+0OR2ZLl+oQ\"",
    "mtime": "2026-11-01T06:39:54.587Z",
    "size": 12043,
    "path": "../public/imgs/flight/airlines/IRU.png"
  },
  "/imgs/flight/airlines/IS.png": {
    "type": "image/png",
    "etag": "\"171e-dq28+IdYlCTWjIE9B3FukSdzJAU\"",
    "mtime": "2026-11-01T06:39:54.588Z",
    "size": 5918,
    "path": "../public/imgs/flight/airlines/IS.png"
  },
  "/imgs/flight/airlines/IT.png": {
    "type": "image/png",
    "etag": "\"4ae-cmNhpXNto/fvp7f2FRzLZmTlfYg\"",
    "mtime": "2026-11-01T06:39:54.590Z",
    "size": 1198,
    "path": "../public/imgs/flight/airlines/IT.png"
  },
  "/imgs/flight/airlines/IV.png": {
    "type": "image/png",
    "etag": "\"1c4b-5OAHW31vTFpTNxGBjx5lUhX/X0c\"",
    "mtime": "2026-11-01T06:39:54.592Z",
    "size": 7243,
    "path": "../public/imgs/flight/airlines/IV.png"
  },
  "/imgs/flight/airlines/IX.png": {
    "type": "image/png",
    "etag": "\"1f43-eZzsQKl00b+67Ga7KC4zlBgbA04\"",
    "mtime": "2026-11-01T06:39:54.593Z",
    "size": 8003,
    "path": "../public/imgs/flight/airlines/IX.png"
  },
  "/imgs/flight/airlines/IY.png": {
    "type": "image/png",
    "etag": "\"1fa1-/54pngGtXybzOCauTy19WsrlsFU\"",
    "mtime": "2026-11-01T06:39:54.594Z",
    "size": 8097,
    "path": "../public/imgs/flight/airlines/IY.png"
  },
  "/imgs/flight/airlines/IZ.png": {
    "type": "image/png",
    "etag": "\"9cd-Ith6q1gKWJhMkZafUeujISC5BNk\"",
    "mtime": "2026-11-01T06:39:54.595Z",
    "size": 2509,
    "path": "../public/imgs/flight/airlines/IZ.png"
  },
  "/imgs/flight/airlines/J2.png": {
    "type": "image/png",
    "etag": "\"1113-Q864LwfeYEBRZKFgsVZWw90Xm/U\"",
    "mtime": "2026-11-01T06:39:54.596Z",
    "size": 4371,
    "path": "../public/imgs/flight/airlines/J2.png"
  },
  "/imgs/flight/airlines/J3.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.596Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/J3.png"
  },
  "/imgs/flight/airlines/J4.png": {
    "type": "image/png",
    "etag": "\"1756-g3UsJ0YOYybU/AW2YMf5Jx/eDwU\"",
    "mtime": "2026-11-01T06:39:54.597Z",
    "size": 5974,
    "path": "../public/imgs/flight/airlines/J4.png"
  },
  "/imgs/flight/airlines/J6.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.598Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/J6.png"
  },
  "/imgs/flight/airlines/J7.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.598Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/J7.png"
  },
  "/imgs/flight/airlines/J8.png": {
    "type": "image/png",
    "etag": "\"3a3a-3V8m1mCia8gMg3r1lcLqruZFbrM\"",
    "mtime": "2026-11-01T06:39:54.599Z",
    "size": 14906,
    "path": "../public/imgs/flight/airlines/J8.png"
  },
  "/imgs/flight/airlines/J9.png": {
    "type": "image/png",
    "etag": "\"1eda-8rJeQALrur5WKNGl67ygp40V1Fc\"",
    "mtime": "2026-11-01T06:39:54.600Z",
    "size": 7898,
    "path": "../public/imgs/flight/airlines/J9.png"
  },
  "/imgs/flight/airlines/JA.png": {
    "type": "image/png",
    "etag": "\"21d9-ss44NmxqmulhCiqp8Plfs5jjBHI\"",
    "mtime": "2026-11-01T06:39:54.601Z",
    "size": 8665,
    "path": "../public/imgs/flight/airlines/JA.png"
  },
  "/imgs/flight/airlines/japan.png": {
    "type": "image/png",
    "etag": "\"21580-kIGIwTqNQhINwIxV4JZ2Qr4wvJI\"",
    "mtime": "2026-08-24T08:29:56.335Z",
    "size": 136576,
    "path": "../public/imgs/flight/airlines/japan.png"
  },
  "/imgs/flight/airlines/jaziira.png": {
    "type": "image/png",
    "etag": "\"17fd-LFgau0deTRbyTapBtxOqN33b4fY\"",
    "mtime": "2026-08-24T08:29:56.353Z",
    "size": 6141,
    "path": "../public/imgs/flight/airlines/jaziira.png"
  },
  "/imgs/flight/airlines/JB.png": {
    "type": "image/png",
    "etag": "\"23e6-ch6Y49rRpRuyIrsweGYtn10sc68\"",
    "mtime": "2026-11-01T06:39:54.602Z",
    "size": 9190,
    "path": "../public/imgs/flight/airlines/JB.png"
  },
  "/imgs/flight/airlines/JD.png": {
    "type": "image/png",
    "etag": "\"1538-kvssnoxKcZfRWm+jvTtwm/riC/s\"",
    "mtime": "2026-11-01T06:39:54.603Z",
    "size": 5432,
    "path": "../public/imgs/flight/airlines/JD.png"
  },
  "/imgs/flight/airlines/JE.png": {
    "type": "image/png",
    "etag": "\"1f4c-xRqblLSY7d6bTRGIico6q0LmEGY\"",
    "mtime": "2026-11-01T06:39:54.604Z",
    "size": 8012,
    "path": "../public/imgs/flight/airlines/JE.png"
  },
  "/imgs/flight/airlines/JH.png": {
    "type": "image/png",
    "etag": "\"cba-xRG/qHQzxYDrLgRR5WsB9c42XLI\"",
    "mtime": "2026-11-01T06:39:54.606Z",
    "size": 3258,
    "path": "../public/imgs/flight/airlines/JH.png"
  },
  "/imgs/flight/airlines/JI.png": {
    "type": "image/png",
    "etag": "\"230a-hf/sF8sWp3H6e+gFmgFclzq4rlM\"",
    "mtime": "2026-11-01T06:39:54.606Z",
    "size": 8970,
    "path": "../public/imgs/flight/airlines/JI.png"
  },
  "/imgs/flight/airlines/JJ.png": {
    "type": "image/png",
    "etag": "\"949-wRzHnuSC/JWm9pPxFn/nMQzvAa4\"",
    "mtime": "2026-11-01T06:39:54.607Z",
    "size": 2377,
    "path": "../public/imgs/flight/airlines/JJ.png"
  },
  "/imgs/flight/airlines/JK.png": {
    "type": "image/png",
    "etag": "\"1233-l09kFPjsI91oUy+K46247q7AYRk\"",
    "mtime": "2026-11-01T06:39:54.608Z",
    "size": 4659,
    "path": "../public/imgs/flight/airlines/JK.png"
  },
  "/imgs/flight/airlines/JL.png": {
    "type": "image/png",
    "etag": "\"1a67-3j0A9q90CG9dgXdPuZoxa8y94aM\"",
    "mtime": "2026-11-01T06:39:54.609Z",
    "size": 6759,
    "path": "../public/imgs/flight/airlines/JL.png"
  },
  "/imgs/flight/airlines/JM.png": {
    "type": "image/png",
    "etag": "\"4434-xoGWQDEfDtW1uO/Ea+qZ+HkOWE0\"",
    "mtime": "2026-11-01T06:39:54.610Z",
    "size": 17460,
    "path": "../public/imgs/flight/airlines/JM.png"
  },
  "/imgs/flight/airlines/JN.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.611Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/JN.png"
  },
  "/imgs/flight/airlines/JO.png": {
    "type": "image/png",
    "etag": "\"1a67-3j0A9q90CG9dgXdPuZoxa8y94aM\"",
    "mtime": "2026-11-01T06:39:54.611Z",
    "size": 6759,
    "path": "../public/imgs/flight/airlines/JO.png"
  },
  "/imgs/flight/airlines/JP.png": {
    "type": "image/png",
    "etag": "\"11f8-b2UFbZ8MdiP/aFaD0rJcnggbNcI\"",
    "mtime": "2026-11-01T06:39:54.612Z",
    "size": 4600,
    "path": "../public/imgs/flight/airlines/JP.png"
  },
  "/imgs/flight/airlines/JQ.png": {
    "type": "image/png",
    "etag": "\"db5-xetqW5s9gXnM+MvRITrjU3YD71E\"",
    "mtime": "2026-11-01T06:39:54.613Z",
    "size": 3509,
    "path": "../public/imgs/flight/airlines/JQ.png"
  },
  "/imgs/flight/airlines/JR.png": {
    "type": "image/png",
    "etag": "\"fce-UUFwWL6G+xXZpwwfbOvg+rZdVPs\"",
    "mtime": "2026-11-01T06:39:54.614Z",
    "size": 4046,
    "path": "../public/imgs/flight/airlines/JR.png"
  },
  "/imgs/flight/airlines/JS.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.614Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/JS.png"
  },
  "/imgs/flight/airlines/JT.png": {
    "type": "image/png",
    "etag": "\"163c-AZeFihaGt0xOXbX2fzUrLd5KIi8\"",
    "mtime": "2026-11-01T06:39:54.615Z",
    "size": 5692,
    "path": "../public/imgs/flight/airlines/JT.png"
  },
  "/imgs/flight/airlines/JU.png": {
    "type": "image/png",
    "etag": "\"3a94-bHvcQV272hAM1cIPGKUexOIbmoo\"",
    "mtime": "2026-11-01T06:39:54.616Z",
    "size": 14996,
    "path": "../public/imgs/flight/airlines/JU.png"
  },
  "/imgs/flight/airlines/JV.png": {
    "type": "image/png",
    "etag": "\"1619-R+RRlqtnaPMn5Aca4/BRwl66VCc\"",
    "mtime": "2026-11-01T06:39:54.617Z",
    "size": 5657,
    "path": "../public/imgs/flight/airlines/JV.png"
  },
  "/imgs/flight/airlines/JX.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.618Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/JX.png"
  },
  "/imgs/flight/airlines/JY.png": {
    "type": "image/png",
    "etag": "\"21d3-Cmhtvuh983WVCjyV4dMgOK7+kjA\"",
    "mtime": "2026-11-01T06:39:54.618Z",
    "size": 8659,
    "path": "../public/imgs/flight/airlines/JY.png"
  },
  "/imgs/flight/airlines/JZ.png": {
    "type": "image/png",
    "etag": "\"13ec-ZRMKrI/bQhClifHyqNTJCQQH6og\"",
    "mtime": "2026-11-01T06:39:54.620Z",
    "size": 5100,
    "path": "../public/imgs/flight/airlines/JZ.png"
  },
  "/imgs/flight/airlines/K2.png": {
    "type": "image/png",
    "etag": "\"c72-Abm9nXaEmYY/X9EjYKawNr69KpM\"",
    "mtime": "2026-11-01T06:39:54.620Z",
    "size": 3186,
    "path": "../public/imgs/flight/airlines/K2.png"
  },
  "/imgs/flight/airlines/K5.png": {
    "type": "image/png",
    "etag": "\"2419-0qBHRVpalbEgpZDJZ1nVWKhUZy0\"",
    "mtime": "2026-11-01T06:39:54.622Z",
    "size": 9241,
    "path": "../public/imgs/flight/airlines/K5.png"
  },
  "/imgs/flight/airlines/K6.png": {
    "type": "image/png",
    "etag": "\"c17-8azRS4IBwHwdgVXh8St8ZIx6aQM\"",
    "mtime": "2026-11-01T06:39:54.623Z",
    "size": 3095,
    "path": "../public/imgs/flight/airlines/K6.png"
  },
  "/imgs/flight/airlines/K8.png": {
    "type": "image/png",
    "etag": "\"e45-S8MiIEc1by1xhBFacnTxzXSJQig\"",
    "mtime": "2026-11-01T06:39:54.624Z",
    "size": 3653,
    "path": "../public/imgs/flight/airlines/K8.png"
  },
  "/imgs/flight/airlines/K9.png": {
    "type": "image/png",
    "etag": "\"cb3-d2jh/3umbKJn9Fv9zFudNIQnE9E\"",
    "mtime": "2026-11-01T06:39:54.625Z",
    "size": 3251,
    "path": "../public/imgs/flight/airlines/K9.png"
  },
  "/imgs/flight/airlines/KA.png": {
    "type": "image/png",
    "etag": "\"183d-TZi1SzBbSacWzpJADaXLTDwQLKI\"",
    "mtime": "2026-11-01T06:39:54.626Z",
    "size": 6205,
    "path": "../public/imgs/flight/airlines/KA.png"
  },
  "/imgs/flight/airlines/KB.png": {
    "type": "image/png",
    "etag": "\"2583-eBWvedBfdkTfbYwKQ6uBXAaXdHo\"",
    "mtime": "2026-11-01T06:39:54.628Z",
    "size": 9603,
    "path": "../public/imgs/flight/airlines/KB.png"
  },
  "/imgs/flight/airlines/KC.png": {
    "type": "image/png",
    "etag": "\"e91-8NDDhBhvP4aGU96bsfXNLmkbHVc\"",
    "mtime": "2026-11-01T06:39:54.629Z",
    "size": 3729,
    "path": "../public/imgs/flight/airlines/KC.png"
  },
  "/imgs/flight/airlines/KD.png": {
    "type": "image/png",
    "etag": "\"2883-k+X6xwp8BgBzYA/pLbU8fIGdT/E\"",
    "mtime": "2026-11-01T06:39:54.629Z",
    "size": 10371,
    "path": "../public/imgs/flight/airlines/KD.png"
  },
  "/imgs/flight/airlines/KE.png": {
    "type": "image/png",
    "etag": "\"148c-8eJTYHk1FSzy6X22atK1EjyFlZQ\"",
    "mtime": "2026-11-01T06:39:54.630Z",
    "size": 5260,
    "path": "../public/imgs/flight/airlines/KE.png"
  },
  "/imgs/flight/airlines/kenya.png": {
    "type": "image/png",
    "etag": "\"ef91-h9AYgU0YAUMUsL+H1QvS88Wd56A\"",
    "mtime": "2026-08-24T08:29:56.363Z",
    "size": 61329,
    "path": "../public/imgs/flight/airlines/kenya.png"
  },
  "/imgs/flight/airlines/KF.png": {
    "type": "image/png",
    "etag": "\"d73-4x3ThO2BkdpgyP98UyxmvO3+FQs\"",
    "mtime": "2026-11-01T06:39:54.631Z",
    "size": 3443,
    "path": "../public/imgs/flight/airlines/KF.png"
  },
  "/imgs/flight/airlines/KG.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.632Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/KG.png"
  },
  "/imgs/flight/airlines/KH.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.632Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/KH.png"
  },
  "/imgs/flight/airlines/KI.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.633Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/KI.png"
  },
  "/imgs/flight/airlines/kish.png": {
    "type": "image/png",
    "etag": "\"3a6d-rmKLo5hd6PUVZgUZUBUOJxnDc94\"",
    "mtime": "2026-08-24T08:29:56.366Z",
    "size": 14957,
    "path": "../public/imgs/flight/airlines/kish.png"
  },
  "/imgs/flight/airlines/kishair.png": {
    "type": "image/png",
    "etag": "\"1b08f-pu8v0tOC/P972krhEcmmTI3zvDE\"",
    "mtime": "2026-07-13T06:00:39.835Z",
    "size": 110735,
    "path": "../public/imgs/flight/airlines/kishair.png"
  },
  "/imgs/flight/airlines/KJ.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.633Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/KJ.png"
  },
  "/imgs/flight/airlines/KK.png": {
    "type": "image/png",
    "etag": "\"a54-m1OaCX6QRZy6j4NHi2H8Q4cdsFc\"",
    "mtime": "2026-11-01T06:39:54.634Z",
    "size": 2644,
    "path": "../public/imgs/flight/airlines/KK.png"
  },
  "/imgs/flight/airlines/KL.png": {
    "type": "image/png",
    "etag": "\"c31-nRPErTCeZrFGi6MvSqU3m1Vx/Uw\"",
    "mtime": "2026-11-01T06:39:54.635Z",
    "size": 3121,
    "path": "../public/imgs/flight/airlines/KL.png"
  },
  "/imgs/flight/airlines/klm (1).png": {
    "type": "image/png",
    "etag": "\"7778-Ry/oMEBDc1IwcF1ZuFzJ6JLC5A8\"",
    "mtime": "2026-08-24T08:29:56.368Z",
    "size": 30584,
    "path": "../public/imgs/flight/airlines/klm (1).png"
  },
  "/imgs/flight/airlines/klm.png": {
    "type": "image/png",
    "etag": "\"7778-Ry/oMEBDc1IwcF1ZuFzJ6JLC5A8\"",
    "mtime": "2026-08-24T08:29:56.392Z",
    "size": 30584,
    "path": "../public/imgs/flight/airlines/klm.png"
  },
  "/imgs/flight/airlines/KM.png": {
    "type": "image/png",
    "etag": "\"2db6-EFVeIxZZLWCjIiB93hMUB9ymDqs\"",
    "mtime": "2026-11-01T06:39:54.636Z",
    "size": 11702,
    "path": "../public/imgs/flight/airlines/KM.png"
  },
  "/imgs/flight/airlines/KN.png": {
    "type": "image/png",
    "etag": "\"9e2-8tcy1qo9iKXqA9bzBInFUJKCxYo\"",
    "mtime": "2026-11-01T06:39:54.637Z",
    "size": 2530,
    "path": "../public/imgs/flight/airlines/KN.png"
  },
  "/imgs/flight/airlines/korean.png": {
    "type": "image/png",
    "etag": "\"a65c-W5gHw/K8qhyyamzvLpk24ZNPs7s\"",
    "mtime": "2026-08-24T08:29:56.394Z",
    "size": 42588,
    "path": "../public/imgs/flight/airlines/korean.png"
  },
  "/imgs/flight/airlines/KO.png": {
    "type": "image/png",
    "etag": "\"11e5-t8KfkYPwEHsK1RLWrSzc+Rbgn2w\"",
    "mtime": "2026-11-01T06:39:54.638Z",
    "size": 4581,
    "path": "../public/imgs/flight/airlines/KO.png"
  },
  "/imgs/flight/airlines/KQ.png": {
    "type": "image/png",
    "etag": "\"187b-saZVQ8jOPV8x+UcnwWtYSs90gYI\"",
    "mtime": "2026-11-01T06:39:54.640Z",
    "size": 6267,
    "path": "../public/imgs/flight/airlines/KQ.png"
  },
  "/imgs/flight/airlines/KR.png": {
    "type": "image/png",
    "etag": "\"10e8-mtlU9ooPHNfpEguaa10ll2n9cas\"",
    "mtime": "2026-11-01T06:39:54.641Z",
    "size": 4328,
    "path": "../public/imgs/flight/airlines/KR.png"
  },
  "/imgs/flight/airlines/KS.png": {
    "type": "image/png",
    "etag": "\"100e-OH+hjX7o+c9fHdAFay08nUsUP7E\"",
    "mtime": "2026-11-01T06:39:54.642Z",
    "size": 4110,
    "path": "../public/imgs/flight/airlines/KS.png"
  },
  "/imgs/flight/airlines/KU.png": {
    "type": "image/png",
    "etag": "\"bad-Ap33423Vt+XtaUp9MQnam1UBTJ8\"",
    "mtime": "2026-11-01T06:39:54.643Z",
    "size": 2989,
    "path": "../public/imgs/flight/airlines/KU.png"
  },
  "/imgs/flight/airlines/kuwait.png": {
    "type": "image/png",
    "etag": "\"467a-ZtH1xAkQ6xeHdYYJv0+dz4hRvqc\"",
    "mtime": "2026-08-24T08:29:56.395Z",
    "size": 18042,
    "path": "../public/imgs/flight/airlines/kuwait.png"
  },
  "/imgs/flight/airlines/KV.png": {
    "type": "image/png",
    "etag": "\"38ce-SQO96NUZYOZZtHrb+Mmd/n8tsxU\"",
    "mtime": "2026-11-01T06:39:54.644Z",
    "size": 14542,
    "path": "../public/imgs/flight/airlines/KV.png"
  },
  "/imgs/flight/airlines/KW.png": {
    "type": "image/png",
    "etag": "\"26a3-dUq5vQuZp3J2T98lKC03Ue39E8k\"",
    "mtime": "2026-11-01T06:39:54.645Z",
    "size": 9891,
    "path": "../public/imgs/flight/airlines/KW.png"
  },
  "/imgs/flight/airlines/KX.png": {
    "type": "image/png",
    "etag": "\"2473-vbBi9wL2vZaxqaCGx3l8DZhBuPQ\"",
    "mtime": "2026-11-01T06:39:54.646Z",
    "size": 9331,
    "path": "../public/imgs/flight/airlines/KX.png"
  },
  "/imgs/flight/airlines/KY.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.646Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/KY.png"
  },
  "/imgs/flight/airlines/L3.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.646Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/L3.png"
  },
  "/imgs/flight/airlines/L5.png": {
    "type": "image/png",
    "etag": "\"ab4-QsAeUoblfl+gsTRdiZ8oPIqCYek\"",
    "mtime": "2026-11-01T06:39:54.647Z",
    "size": 2740,
    "path": "../public/imgs/flight/airlines/L5.png"
  },
  "/imgs/flight/airlines/L6.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.648Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/L6.png"
  },
  "/imgs/flight/airlines/L9.png": {
    "type": "image/png",
    "etag": "\"2552-NclVvB2GtAKV9AAK6JadjlceJNM\"",
    "mtime": "2026-11-01T06:39:54.649Z",
    "size": 9554,
    "path": "../public/imgs/flight/airlines/L9.png"
  },
  "/imgs/flight/airlines/LA.png": {
    "type": "image/png",
    "etag": "\"949-wRzHnuSC/JWm9pPxFn/nMQzvAa4\"",
    "mtime": "2026-11-01T06:39:54.650Z",
    "size": 2377,
    "path": "../public/imgs/flight/airlines/LA.png"
  },
  "/imgs/flight/airlines/LF.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.651Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/LF.png"
  },
  "/imgs/flight/airlines/LG.png": {
    "type": "image/png",
    "etag": "\"12a1-cGofkIRM9LtwXsL1NGT5BbwFBu8\"",
    "mtime": "2026-11-01T06:39:54.651Z",
    "size": 4769,
    "path": "../public/imgs/flight/airlines/LG.png"
  },
  "/imgs/flight/airlines/LH.png": {
    "type": "image/png",
    "etag": "\"1388-iRrEbX/9Lyl3g8P0W084DdvUU4w\"",
    "mtime": "2026-11-01T06:39:54.652Z",
    "size": 5000,
    "path": "../public/imgs/flight/airlines/LH.png"
  },
  "/imgs/flight/airlines/LI.png": {
    "type": "image/png",
    "etag": "\"760-jiRd1KctBxbfsA2/cakAmqlrlII\"",
    "mtime": "2026-11-01T06:39:54.653Z",
    "size": 1888,
    "path": "../public/imgs/flight/airlines/LI.png"
  },
  "/imgs/flight/airlines/LJ.png": {
    "type": "image/png",
    "etag": "\"1709-OziEnC5DHUjW1RnY6qPrsom5UbA\"",
    "mtime": "2026-11-01T06:39:54.654Z",
    "size": 5897,
    "path": "../public/imgs/flight/airlines/LJ.png"
  },
  "/imgs/flight/airlines/LM.png": {
    "type": "image/png",
    "etag": "\"130d-X9XewkMcFHj65sM2kI3lUyiedng\"",
    "mtime": "2026-11-01T06:39:54.655Z",
    "size": 4877,
    "path": "../public/imgs/flight/airlines/LM.png"
  },
  "/imgs/flight/airlines/LN.png": {
    "type": "image/png",
    "etag": "\"1665-4cJhvvJjbJDOUua3nCazlK18MGU\"",
    "mtime": "2026-11-01T06:39:54.657Z",
    "size": 5733,
    "path": "../public/imgs/flight/airlines/LN.png"
  },
  "/imgs/flight/airlines/LO.png": {
    "type": "image/png",
    "etag": "\"add-hYRwzhryDy6nEyE3gnok73cIaWs\"",
    "mtime": "2026-11-01T06:39:54.657Z",
    "size": 2781,
    "path": "../public/imgs/flight/airlines/LO.png"
  },
  "/imgs/flight/airlines/LP.png": {
    "type": "image/png",
    "etag": "\"949-wRzHnuSC/JWm9pPxFn/nMQzvAa4\"",
    "mtime": "2026-11-01T06:39:54.658Z",
    "size": 2377,
    "path": "../public/imgs/flight/airlines/LP.png"
  },
  "/imgs/flight/airlines/LR.png": {
    "type": "image/png",
    "etag": "\"1112-kTcflXo1n2UO2wVWsSlIJKUOgjI\"",
    "mtime": "2026-11-01T06:39:54.659Z",
    "size": 4370,
    "path": "../public/imgs/flight/airlines/LR.png"
  },
  "/imgs/flight/airlines/LS.png": {
    "type": "image/png",
    "etag": "\"13ce-x8oGbm531YBPMi+QixuSoPIe7OA\"",
    "mtime": "2026-11-01T06:39:54.660Z",
    "size": 5070,
    "path": "../public/imgs/flight/airlines/LS.png"
  },
  "/imgs/flight/airlines/LT.png": {
    "type": "image/png",
    "etag": "\"423f-uGMLsaSt7bWERLjGaWSRGkl/UR0\"",
    "mtime": "2026-11-01T06:39:54.661Z",
    "size": 16959,
    "path": "../public/imgs/flight/airlines/LT.png"
  },
  "/imgs/flight/airlines/lufthansa.png": {
    "type": "image/png",
    "etag": "\"5ec4-0P8GHvYoqZi3xaDaepmPuYcBgcg\"",
    "mtime": "2026-08-24T08:29:56.397Z",
    "size": 24260,
    "path": "../public/imgs/flight/airlines/lufthansa.png"
  },
  "/imgs/flight/airlines/LW.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.662Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/LW.png"
  },
  "/imgs/flight/airlines/LV.png": {
    "type": "image/png",
    "etag": "\"11b3-ko0ytht5yZahAvE+aAqeDkKO6CA\"",
    "mtime": "2026-11-01T06:39:54.662Z",
    "size": 4531,
    "path": "../public/imgs/flight/airlines/LV.png"
  },
  "/imgs/flight/airlines/LX.png": {
    "type": "image/png",
    "etag": "\"6d5-incajGeWrqc2S661S+fbf4nPvWc\"",
    "mtime": "2026-11-01T06:39:54.663Z",
    "size": 1749,
    "path": "../public/imgs/flight/airlines/LX.png"
  },
  "/imgs/flight/airlines/LY.png": {
    "type": "image/png",
    "etag": "\"6b2-FZcD9aEpb2ooRrecRsj0MGXzbNM\"",
    "mtime": "2026-11-01T06:39:54.664Z",
    "size": 1714,
    "path": "../public/imgs/flight/airlines/LY.png"
  },
  "/imgs/flight/airlines/LZ.png": {
    "type": "image/png",
    "etag": "\"2552-NclVvB2GtAKV9AAK6JadjlceJNM\"",
    "mtime": "2026-11-01T06:39:54.664Z",
    "size": 9554,
    "path": "../public/imgs/flight/airlines/LZ.png"
  },
  "/imgs/flight/airlines/M2.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.665Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/M2.png"
  },
  "/imgs/flight/airlines/M3.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.665Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/M3.png"
  },
  "/imgs/flight/airlines/M5.png": {
    "type": "image/png",
    "etag": "\"1e1f-6QOI/efAr288a9RRuSuzWefDDGw\"",
    "mtime": "2026-11-01T06:39:54.666Z",
    "size": 7711,
    "path": "../public/imgs/flight/airlines/M5.png"
  },
  "/imgs/flight/airlines/M6.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.667Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/M6.png"
  },
  "/imgs/flight/airlines/M7.png": {
    "type": "image/png",
    "etag": "\"1487-WI60XHgNUg7Ok8gMmygFbFowjJU\"",
    "mtime": "2026-11-01T06:39:54.668Z",
    "size": 5255,
    "path": "../public/imgs/flight/airlines/M7.png"
  },
  "/imgs/flight/airlines/MA.png": {
    "type": "image/png",
    "etag": "\"e09-I+XjL2bgQveuM6Bl0lYCZ+D4skw\"",
    "mtime": "2026-11-01T06:39:54.670Z",
    "size": 3593,
    "path": "../public/imgs/flight/airlines/MA.png"
  },
  "/imgs/flight/airlines/M9.png": {
    "type": "image/png",
    "etag": "\"4d59-IKmHPnwBoCqA2WgQVSa2dq8GMGU\"",
    "mtime": "2026-11-01T06:39:54.669Z",
    "size": 19801,
    "path": "../public/imgs/flight/airlines/M9.png"
  },
  "/imgs/flight/airlines/mahan.png": {
    "type": "image/png",
    "etag": "\"1a296-Zo9uUaA0a2kWLBSnLv6RY1LMSvs\"",
    "mtime": "2026-07-13T06:00:39.836Z",
    "size": 107158,
    "path": "../public/imgs/flight/airlines/mahan.png"
  },
  "/imgs/flight/airlines/MD.png": {
    "type": "image/png",
    "etag": "\"4071-MqY1ZjlPmAyoljZrnesOsAVOgSY\"",
    "mtime": "2026-11-01T06:39:54.671Z",
    "size": 16497,
    "path": "../public/imgs/flight/airlines/MD.png"
  },
  "/imgs/flight/airlines/malaysia.png": {
    "type": "image/png",
    "etag": "\"3883-gZadNqFCc2EyzhXBn9vlMvspEM8\"",
    "mtime": "2026-08-24T08:29:56.399Z",
    "size": 14467,
    "path": "../public/imgs/flight/airlines/malaysia.png"
  },
  "/imgs/flight/airlines/ME.png": {
    "type": "image/png",
    "etag": "\"2871-dz7VpQPoOHz+nkZ/SZo2r8wMYaQ\"",
    "mtime": "2026-11-01T06:39:54.673Z",
    "size": 10353,
    "path": "../public/imgs/flight/airlines/ME.png"
  },
  "/imgs/flight/airlines/meraj.png": {
    "type": "image/png",
    "etag": "\"3b0bd-0Vt31HKGgIsx+ssxqzYK/4QfLbI\"",
    "mtime": "2026-07-13T06:00:39.837Z",
    "size": 241853,
    "path": "../public/imgs/flight/airlines/meraj.png"
  },
  "/imgs/flight/airlines/MF.png": {
    "type": "image/png",
    "etag": "\"741-hWO3f6Bd0hxo9+T0HzQ3aAurWdE\"",
    "mtime": "2026-11-01T06:39:54.695Z",
    "size": 1857,
    "path": "../public/imgs/flight/airlines/MF.png"
  },
  "/imgs/flight/airlines/MH.png": {
    "type": "image/png",
    "etag": "\"dd4-GOreN3jI/IbwtpqkTHsO/KPO7vc\"",
    "mtime": "2026-11-01T06:39:54.697Z",
    "size": 3540,
    "path": "../public/imgs/flight/airlines/MH.png"
  },
  "/imgs/flight/airlines/MI.png": {
    "type": "image/png",
    "etag": "\"f40-aAu5Ns8x506cypFyQ6ArkvkqhS8\"",
    "mtime": "2026-11-01T06:39:54.699Z",
    "size": 3904,
    "path": "../public/imgs/flight/airlines/MI.png"
  },
  "/imgs/flight/airlines/middleast (1).png": {
    "type": "image/png",
    "etag": "\"926e-m5bTstWDAojJw0QNmnjTnBiZxeM\"",
    "mtime": "2026-08-24T08:29:56.401Z",
    "size": 37486,
    "path": "../public/imgs/flight/airlines/middleast (1).png"
  },
  "/imgs/flight/airlines/middleast.png": {
    "type": "image/png",
    "etag": "\"926e-m5bTstWDAojJw0QNmnjTnBiZxeM\"",
    "mtime": "2026-08-24T08:29:56.402Z",
    "size": 37486,
    "path": "../public/imgs/flight/airlines/middleast.png"
  },
  "/imgs/flight/airlines/MJ.png": {
    "type": "image/png",
    "etag": "\"753-zbVLGgCQrw+4NRsHlRJE4NcKnsc\"",
    "mtime": "2026-11-01T06:39:54.704Z",
    "size": 1875,
    "path": "../public/imgs/flight/airlines/MJ.png"
  },
  "/imgs/flight/airlines/MK.png": {
    "type": "image/png",
    "etag": "\"132e-tHExc54i5J+lKpGDm4sNUmgzrD4\"",
    "mtime": "2026-11-01T06:39:54.709Z",
    "size": 4910,
    "path": "../public/imgs/flight/airlines/MK.png"
  },
  "/imgs/flight/airlines/ML.png": {
    "type": "image/png",
    "etag": "\"281e-qGpphUH40CNMC28jBzmkPDReaqc\"",
    "mtime": "2026-11-01T06:39:54.711Z",
    "size": 10270,
    "path": "../public/imgs/flight/airlines/ML.png"
  },
  "/imgs/flight/airlines/MM.png": {
    "type": "image/png",
    "etag": "\"682-L1BG8ul5BTiwAoXOn/e2wNY9a1s\"",
    "mtime": "2026-11-01T06:39:54.712Z",
    "size": 1666,
    "path": "../public/imgs/flight/airlines/MM.png"
  },
  "/imgs/flight/airlines/MN.png": {
    "type": "image/png",
    "etag": "\"7f6-PMictbvyobVf+KMdSX6ZMxK5PN4\"",
    "mtime": "2026-11-01T06:39:54.713Z",
    "size": 2038,
    "path": "../public/imgs/flight/airlines/MN.png"
  },
  "/imgs/flight/airlines/MO.png": {
    "type": "image/png",
    "etag": "\"2fc9-jdSQXu+uerztF/ngsAkln8T2Hoo\"",
    "mtime": "2026-11-01T06:39:54.714Z",
    "size": 12233,
    "path": "../public/imgs/flight/airlines/MO.png"
  },
  "/imgs/flight/airlines/MP.png": {
    "type": "image/png",
    "etag": "\"e14-rCMV2q1P+ApjZSI8Si0kImxtKt0\"",
    "mtime": "2026-11-01T06:39:54.715Z",
    "size": 3604,
    "path": "../public/imgs/flight/airlines/MP.png"
  },
  "/imgs/flight/airlines/MS.png": {
    "type": "image/png",
    "etag": "\"192d-67tg5sJ6lJ3dtoTNqTrlz/G2RzU\"",
    "mtime": "2026-11-01T06:39:54.716Z",
    "size": 6445,
    "path": "../public/imgs/flight/airlines/MS.png"
  },
  "/imgs/flight/airlines/MU.png": {
    "type": "image/png",
    "etag": "\"194e-/3MQ24SGSqZaP/+kAe2KB1rY2wE\"",
    "mtime": "2026-11-01T06:39:54.717Z",
    "size": 6478,
    "path": "../public/imgs/flight/airlines/MU.png"
  },
  "/imgs/flight/airlines/MW.png": {
    "type": "image/png",
    "etag": "\"97c-dLSCIBR/3Zh47mzvGYCEDOOxPFU\"",
    "mtime": "2026-11-01T06:39:54.718Z",
    "size": 2428,
    "path": "../public/imgs/flight/airlines/MW.png"
  },
  "/imgs/flight/airlines/MX.png": {
    "type": "image/png",
    "etag": "\"8a3-LjKTObGig0IEhZLJ60WWXgosz2Y\"",
    "mtime": "2026-11-01T06:39:54.718Z",
    "size": 2211,
    "path": "../public/imgs/flight/airlines/MX.png"
  },
  "/imgs/flight/airlines/MY.png": {
    "type": "image/png",
    "etag": "\"13c5-LXQHZId6O13AwqtOOnyDP0d/Fn8\"",
    "mtime": "2026-11-01T06:39:54.719Z",
    "size": 5061,
    "path": "../public/imgs/flight/airlines/MY.png"
  },
  "/imgs/flight/airlines/MZ.png": {
    "type": "image/png",
    "etag": "\"18c3-OwaWwl9P3aIOyLpZcQmir+M0e0U\"",
    "mtime": "2026-11-01T06:39:54.720Z",
    "size": 6339,
    "path": "../public/imgs/flight/airlines/MZ.png"
  },
  "/imgs/flight/airlines/N2.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.721Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/N2.png"
  },
  "/imgs/flight/airlines/N3.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.722Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/N3.png"
  },
  "/imgs/flight/airlines/N4.png": {
    "type": "image/png",
    "etag": "\"1d6d-s/XdBigo5FZEwNqbYFz899ImLyw\"",
    "mtime": "2026-11-01T06:39:54.723Z",
    "size": 7533,
    "path": "../public/imgs/flight/airlines/N4.png"
  },
  "/imgs/flight/airlines/N5.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.723Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/N5.png"
  },
  "/imgs/flight/airlines/N6.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.724Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/N6.png"
  },
  "/imgs/flight/airlines/N7.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.724Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/N7.png"
  },
  "/imgs/flight/airlines/N9.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.725Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/N9.png"
  },
  "/imgs/flight/airlines/NA.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.726Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/NA.png"
  },
  "/imgs/flight/airlines/naft.png": {
    "type": "image/png",
    "etag": "\"c1b6-1Ts4KjD4D8dLn7836ZVUqWypmiQ\"",
    "mtime": "2026-07-13T06:00:39.838Z",
    "size": 49590,
    "path": "../public/imgs/flight/airlines/naft.png"
  },
  "/imgs/flight/airlines/NC.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.727Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/NC.png"
  },
  "/imgs/flight/airlines/NF.png": {
    "type": "image/png",
    "etag": "\"14a7-fr4Fs6eiRKcqyXcHJCsaAL94y3g\"",
    "mtime": "2026-11-01T06:39:54.728Z",
    "size": 5287,
    "path": "../public/imgs/flight/airlines/NF.png"
  },
  "/imgs/flight/airlines/NG.png": {
    "type": "image/png",
    "etag": "\"145b-V4ilqNR/vYcodSNR2Y2W9/nUjzM\"",
    "mtime": "2026-11-01T06:39:54.729Z",
    "size": 5211,
    "path": "../public/imgs/flight/airlines/NG.png"
  },
  "/imgs/flight/airlines/NH.png": {
    "type": "image/png",
    "etag": "\"1c74-Nke63qilmfYeJ92PV6ip2CAvLo4\"",
    "mtime": "2026-11-01T06:39:54.730Z",
    "size": 7284,
    "path": "../public/imgs/flight/airlines/NH.png"
  },
  "/imgs/flight/airlines/NI.png": {
    "type": "image/png",
    "etag": "\"a2c-9g/hjS1AFWI9JRFQMif2cm4s07M\"",
    "mtime": "2026-11-01T06:39:54.731Z",
    "size": 2604,
    "path": "../public/imgs/flight/airlines/NI.png"
  },
  "/imgs/flight/airlines/NK.png": {
    "type": "image/png",
    "etag": "\"f27-h2AQpE94k+8G27HPKhM+K6AmOQ0\"",
    "mtime": "2026-11-01T06:39:54.732Z",
    "size": 3879,
    "path": "../public/imgs/flight/airlines/NK.png"
  },
  "/imgs/flight/airlines/NL.png": {
    "type": "image/png",
    "etag": "\"fb6-icW/IR7BA6UfsWPNWk33YmzXARk\"",
    "mtime": "2026-11-01T06:39:54.733Z",
    "size": 4022,
    "path": "../public/imgs/flight/airlines/NL.png"
  },
  "/imgs/flight/airlines/NM.png": {
    "type": "image/png",
    "etag": "\"131c-OYwHjs0FuXNa/LEmRn/wQhtxjsw\"",
    "mtime": "2026-11-01T06:39:54.734Z",
    "size": 4892,
    "path": "../public/imgs/flight/airlines/NM.png"
  },
  "/imgs/flight/airlines/NN.png": {
    "type": "image/png",
    "etag": "\"620-bIwYqJycAtyH5eF4HfO4Wwcsn7c\"",
    "mtime": "2026-11-01T06:39:54.735Z",
    "size": 1568,
    "path": "../public/imgs/flight/airlines/NN.png"
  },
  "/imgs/flight/airlines/no.png": {
    "type": "image/png",
    "etag": "\"22ae-Qsouqx66OJWMuqkTE9AJ37HKON8\"",
    "mtime": "2026-11-01T06:39:55.065Z",
    "size": 8878,
    "path": "../public/imgs/flight/airlines/no.png"
  },
  "/imgs/flight/airlines/nordwind.png": {
    "type": "image/png",
    "etag": "\"5830-J1P+aRMAVd/CHVYnsxY2zLiESeI\"",
    "mtime": "2026-08-24T08:29:56.404Z",
    "size": 22576,
    "path": "../public/imgs/flight/airlines/nordwind.png"
  },
  "/imgs/flight/airlines/NQ.png": {
    "type": "image/png",
    "etag": "\"98c-qPcu0e46mSGaGflzqEz4wez6hcY\"",
    "mtime": "2026-11-01T06:39:54.744Z",
    "size": 2444,
    "path": "../public/imgs/flight/airlines/NQ.png"
  },
  "/imgs/flight/airlines/NR.png": {
    "type": "image/png",
    "etag": "\"2429-4OiY+LEiH//TqjKwvKjT3v44mEg\"",
    "mtime": "2026-11-01T06:39:54.745Z",
    "size": 9257,
    "path": "../public/imgs/flight/airlines/NR.png"
  },
  "/imgs/flight/airlines/NS.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.746Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/NS.png"
  },
  "/imgs/flight/airlines/NT.png": {
    "type": "image/png",
    "etag": "\"1381-Fhz0Q6+pQPtEMZZIFiSg22DCnU4\"",
    "mtime": "2026-11-01T06:39:54.747Z",
    "size": 4993,
    "path": "../public/imgs/flight/airlines/NT.png"
  },
  "/imgs/flight/airlines/NU.png": {
    "type": "image/png",
    "etag": "\"1a67-3j0A9q90CG9dgXdPuZoxa8y94aM\"",
    "mtime": "2026-11-01T06:39:54.747Z",
    "size": 6759,
    "path": "../public/imgs/flight/airlines/NU.png"
  },
  "/imgs/flight/airlines/NV.png": {
    "type": "image/png",
    "etag": "\"1c69-KeiWQcpDwnKOBDZ8EK94eBSPwgk\"",
    "mtime": "2026-11-01T06:39:54.748Z",
    "size": 7273,
    "path": "../public/imgs/flight/airlines/NV.png"
  },
  "/imgs/flight/airlines/NW.png": {
    "type": "image/png",
    "etag": "\"f24-qXb8COqZXeeUFC3IRWg1kVDOmqw\"",
    "mtime": "2026-11-01T06:39:54.749Z",
    "size": 3876,
    "path": "../public/imgs/flight/airlines/NW.png"
  },
  "/imgs/flight/airlines/NX.png": {
    "type": "image/png",
    "etag": "\"6d6-YP/v1J1LiLZeRIauj+ZrSmZvUTs\"",
    "mtime": "2026-11-01T06:39:54.750Z",
    "size": 1750,
    "path": "../public/imgs/flight/airlines/NX.png"
  },
  "/imgs/flight/airlines/NY.png": {
    "type": "image/png",
    "etag": "\"f22-ECfzVq5xHwD4gqOLwu4MCLwhrlE\"",
    "mtime": "2026-11-01T06:39:54.750Z",
    "size": 3874,
    "path": "../public/imgs/flight/airlines/NY.png"
  },
  "/imgs/flight/airlines/NZ.png": {
    "type": "image/png",
    "etag": "\"eec-Sg4hlmgtzrdy8nSVKfnLn/Gk5AI\"",
    "mtime": "2026-11-01T06:39:54.751Z",
    "size": 3820,
    "path": "../public/imgs/flight/airlines/NZ.png"
  },
  "/imgs/flight/airlines/O2.png": {
    "type": "image/png",
    "etag": "\"cf3-xRXuukJqWpZ9yeGhwZtUBM5WrAQ\"",
    "mtime": "2026-11-01T06:39:54.752Z",
    "size": 3315,
    "path": "../public/imgs/flight/airlines/O2.png"
  },
  "/imgs/flight/airlines/O4.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.753Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/O4.png"
  },
  "/imgs/flight/airlines/O6.png": {
    "type": "image/png",
    "etag": "\"c46-stV+jLkTfhcwI8WAC6yWBrtg9hg\"",
    "mtime": "2026-11-01T06:39:54.753Z",
    "size": 3142,
    "path": "../public/imgs/flight/airlines/O6.png"
  },
  "/imgs/flight/airlines/O7.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.753Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/O7.png"
  },
  "/imgs/flight/airlines/OA.png": {
    "type": "image/png",
    "etag": "\"191a-jexrVTjCwktBhgzek7jdh4BRFUI\"",
    "mtime": "2026-11-01T06:39:54.754Z",
    "size": 6426,
    "path": "../public/imgs/flight/airlines/OA.png"
  },
  "/imgs/flight/airlines/OB.png": {
    "type": "image/png",
    "etag": "\"1abb-6ZzYDgnL8kGx7fDI60wnb5zhbb4\"",
    "mtime": "2026-11-01T06:39:54.774Z",
    "size": 6843,
    "path": "../public/imgs/flight/airlines/OB.png"
  },
  "/imgs/flight/airlines/OF.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.774Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/OF.png"
  },
  "/imgs/flight/airlines/OK.png": {
    "type": "image/png",
    "etag": "\"eb1-6rIDaEFQ5XMzv/wi9mzvRcnY2r4\"",
    "mtime": "2026-11-01T06:39:54.775Z",
    "size": 3761,
    "path": "../public/imgs/flight/airlines/OK.png"
  },
  "/imgs/flight/airlines/OL.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.776Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/OL.png"
  },
  "/imgs/flight/airlines/OM.png": {
    "type": "image/png",
    "etag": "\"696-kinAuBcXuzGGNG7Cg/LnTFCLmf0\"",
    "mtime": "2026-11-01T06:39:54.777Z",
    "size": 1686,
    "path": "../public/imgs/flight/airlines/OM.png"
  },
  "/imgs/flight/airlines/omanair.png": {
    "type": "image/png",
    "etag": "\"522d-dA7Kqnnp5nzreknj9TzUKqvkWWY\"",
    "mtime": "2026-08-24T08:29:56.405Z",
    "size": 21037,
    "path": "../public/imgs/flight/airlines/omanair.png"
  },
  "/imgs/flight/airlines/ON.png": {
    "type": "image/png",
    "etag": "\"bb3-x7+TFaivehIRAekz+6lvPETNgZE\"",
    "mtime": "2026-11-01T06:39:54.778Z",
    "size": 2995,
    "path": "../public/imgs/flight/airlines/ON.png"
  },
  "/imgs/flight/airlines/OP.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.778Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/OP.png"
  },
  "/imgs/flight/airlines/OR.png": {
    "type": "image/png",
    "etag": "\"71d-kLTkkXOmXE/lk0NamYSZwI9hWQI\"",
    "mtime": "2026-11-01T06:39:54.779Z",
    "size": 1821,
    "path": "../public/imgs/flight/airlines/OR.png"
  },
  "/imgs/flight/airlines/OS.png": {
    "type": "image/png",
    "etag": "\"b22-/FR4tXJAzqxt4NZsQXEqtfhaDyk\"",
    "mtime": "2026-11-01T06:39:54.780Z",
    "size": 2850,
    "path": "../public/imgs/flight/airlines/OS.png"
  },
  "/imgs/flight/airlines/OT.png": {
    "type": "image/png",
    "etag": "\"13fd-ZEXFyfOyF8uO+Ekf4w2N/qeCqxk\"",
    "mtime": "2026-11-01T06:39:54.781Z",
    "size": 5117,
    "path": "../public/imgs/flight/airlines/OT.png"
  },
  "/imgs/flight/airlines/OU.png": {
    "type": "image/png",
    "etag": "\"7ea-OVi69dZ8CZ0uQ16S9WJXwduOP9o\"",
    "mtime": "2026-11-01T06:39:54.781Z",
    "size": 2026,
    "path": "../public/imgs/flight/airlines/OU.png"
  },
  "/imgs/flight/airlines/OV.png": {
    "type": "image/png",
    "etag": "\"28e7-xUY6HKfhkQKMYcxpcnJZRktsOvo\"",
    "mtime": "2026-11-01T06:39:54.782Z",
    "size": 10471,
    "path": "../public/imgs/flight/airlines/OV.png"
  },
  "/imgs/flight/airlines/OX.png": {
    "type": "image/png",
    "etag": "\"76a-XageAU7mRJ8PSdcQapFHlbT926Q\"",
    "mtime": "2026-11-01T06:39:54.783Z",
    "size": 1898,
    "path": "../public/imgs/flight/airlines/OX.png"
  },
  "/imgs/flight/airlines/OY.png": {
    "type": "image/png",
    "etag": "\"118f-viwqDvDFuW+XqVb4mPbEcEFFuKI\"",
    "mtime": "2026-11-01T06:39:54.784Z",
    "size": 4495,
    "path": "../public/imgs/flight/airlines/OY.png"
  },
  "/imgs/flight/airlines/OZ.png": {
    "type": "image/png",
    "etag": "\"26b6-6Y/JSlsZEEFe4EiN85n5eOFW/qM\"",
    "mtime": "2026-11-01T06:39:54.785Z",
    "size": 9910,
    "path": "../public/imgs/flight/airlines/OZ.png"
  },
  "/imgs/flight/airlines/P3.png": {
    "type": "image/png",
    "etag": "\"c81-sJsAvTeANAUNGdDlath5e9gdRJc\"",
    "mtime": "2026-11-01T06:39:54.786Z",
    "size": 3201,
    "path": "../public/imgs/flight/airlines/P3.png"
  },
  "/imgs/flight/airlines/P5.png": {
    "type": "image/png",
    "etag": "\"1590-3/5eTlmQA2OqSbrQaSxkfeRQvEc\"",
    "mtime": "2026-11-01T06:39:54.787Z",
    "size": 5520,
    "path": "../public/imgs/flight/airlines/P5.png"
  },
  "/imgs/flight/airlines/P0.png": {
    "type": "image/png",
    "etag": "\"d28-pMU4dF+ahqzhy51hwVDJy+z1+qI\"",
    "mtime": "2026-11-01T06:39:54.786Z",
    "size": 3368,
    "path": "../public/imgs/flight/airlines/P0.png"
  },
  "/imgs/flight/airlines/P6.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.789Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/P6.png"
  },
  "/imgs/flight/airlines/P8.png": {
    "type": "image/png",
    "etag": "\"15d4-ggo25t9h/qIoy23JZShUi/QKX9c\"",
    "mtime": "2026-11-01T06:39:54.790Z",
    "size": 5588,
    "path": "../public/imgs/flight/airlines/P8.png"
  },
  "/imgs/flight/airlines/P9.png": {
    "type": "image/png",
    "etag": "\"13ef-MTZKSk23/NG0LW9epnr0Jhrwmjo\"",
    "mtime": "2026-11-01T06:39:54.791Z",
    "size": 5103,
    "path": "../public/imgs/flight/airlines/P9.png"
  },
  "/imgs/flight/airlines/parsair.jpg": {
    "type": "image/jpeg",
    "etag": "\"598c-IE3lV49wOhoyMTor+tt1qbUhsf4\"",
    "mtime": "2026-07-13T06:00:39.839Z",
    "size": 22924,
    "path": "../public/imgs/flight/airlines/parsair.jpg"
  },
  "/imgs/flight/airlines/parsair.png": {
    "type": "image/png",
    "etag": "\"3066-XxTUomdreU1LZYC0X3ffDKDJ+50\"",
    "mtime": "2026-08-24T08:29:56.410Z",
    "size": 12390,
    "path": "../public/imgs/flight/airlines/parsair.png"
  },
  "/imgs/flight/airlines/parsair1.png": {
    "type": "image/png",
    "etag": "\"12b2a-U2dSZKW9SzrlMdkZP65muB1mC4M\"",
    "mtime": "2026-07-13T06:00:39.840Z",
    "size": 76586,
    "path": "../public/imgs/flight/airlines/parsair1.png"
  },
  "/imgs/flight/airlines/PC.png": {
    "type": "image/png",
    "etag": "\"1a2a-ZgReLeKZWNW6dZ0porsWmxL9h9A\"",
    "mtime": "2026-11-01T06:39:54.792Z",
    "size": 6698,
    "path": "../public/imgs/flight/airlines/PC.png"
  },
  "/imgs/flight/airlines/PD.png": {
    "type": "image/png",
    "etag": "\"ed6-h//cb/3/PE/6gySwlZ5N2Z60vzo\"",
    "mtime": "2026-11-01T06:39:54.793Z",
    "size": 3798,
    "path": "../public/imgs/flight/airlines/PD.png"
  },
  "/imgs/flight/airlines/PE.png": {
    "type": "image/png",
    "etag": "\"8c5-IN6R/65izbMZRz7TK1DBO2JrEuc\"",
    "mtime": "2026-11-01T06:39:54.793Z",
    "size": 2245,
    "path": "../public/imgs/flight/airlines/PE.png"
  },
  "/imgs/flight/airlines/pegasus.png": {
    "type": "image/png",
    "etag": "\"e93e-OP1gNRCWcbEzyPim26yH/nfCo5o\"",
    "mtime": "2026-08-24T08:29:56.413Z",
    "size": 59710,
    "path": "../public/imgs/flight/airlines/pegasus.png"
  },
  "/imgs/flight/airlines/PG.png": {
    "type": "image/png",
    "etag": "\"1de4-NiJVHwf4MtlKiAGU/gRXGGPvX2o\"",
    "mtime": "2026-11-01T06:39:54.794Z",
    "size": 7652,
    "path": "../public/imgs/flight/airlines/PG.png"
  },
  "/imgs/flight/airlines/PH.png": {
    "type": "image/png",
    "etag": "\"1c57-SzH0i8QhriCcBzBHzaO2wN9CYb0\"",
    "mtime": "2026-11-01T06:39:54.795Z",
    "size": 7255,
    "path": "../public/imgs/flight/airlines/PH.png"
  },
  "/imgs/flight/airlines/Philippine.png": {
    "type": "image/png",
    "etag": "\"4c3a-nOfRJAcy4eJGj49Av5/lMQZOhhQ\"",
    "mtime": "2026-08-24T08:29:56.283Z",
    "size": 19514,
    "path": "../public/imgs/flight/airlines/Philippine.png"
  },
  "/imgs/flight/airlines/PJ.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.796Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/PJ.png"
  },
  "/imgs/flight/airlines/PK.png": {
    "type": "image/png",
    "etag": "\"c40-DIizg7fuW5xX3BwKM/LS5WmBMN8\"",
    "mtime": "2026-11-01T06:39:54.797Z",
    "size": 3136,
    "path": "../public/imgs/flight/airlines/PK.png"
  },
  "/imgs/flight/airlines/PL.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.797Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/PL.png"
  },
  "/imgs/flight/airlines/PM.png": {
    "type": "image/png",
    "etag": "\"7de-UZ+tLjPKN9ZfQWHFKfWON1gPGFw\"",
    "mtime": "2026-11-01T06:39:54.798Z",
    "size": 2014,
    "path": "../public/imgs/flight/airlines/PM.png"
  },
  "/imgs/flight/airlines/PN.png": {
    "type": "image/png",
    "etag": "\"30c6-3TOojya51U8DOXe3eVYiCUWKv7Y\"",
    "mtime": "2026-11-01T06:39:54.799Z",
    "size": 12486,
    "path": "../public/imgs/flight/airlines/PN.png"
  },
  "/imgs/flight/airlines/pouya.png": {
    "type": "image/png",
    "etag": "\"e134-s2TKg0VBRI1q2EiK1Rmops5eRxw\"",
    "mtime": "2026-08-24T08:29:56.415Z",
    "size": 57652,
    "path": "../public/imgs/flight/airlines/pouya.png"
  },
  "/imgs/flight/airlines/pouyaair.png": {
    "type": "image/png",
    "etag": "\"17787-xflZV0mwcgW0PUYa1N3/1gKPNNo\"",
    "mtime": "2026-07-13T06:00:39.841Z",
    "size": 96135,
    "path": "../public/imgs/flight/airlines/pouyaair.png"
  },
  "/imgs/flight/airlines/PR.png": {
    "type": "image/png",
    "etag": "\"13be-FNziask1ZfD72B8ZpDAEUSww8bM\"",
    "mtime": "2026-11-01T06:39:54.800Z",
    "size": 5054,
    "path": "../public/imgs/flight/airlines/PR.png"
  },
  "/imgs/flight/airlines/PS.png": {
    "type": "image/png",
    "etag": "\"d1e-41LbeKYoiedej51ARqw+/9D3Vd8\"",
    "mtime": "2026-11-01T06:39:54.801Z",
    "size": 3358,
    "path": "../public/imgs/flight/airlines/PS.png"
  },
  "/imgs/flight/airlines/PU.png": {
    "type": "image/png",
    "etag": "\"181f-QsobPERwq0S/vzem99UzHeadTm4\"",
    "mtime": "2026-11-01T06:39:54.801Z",
    "size": 6175,
    "path": "../public/imgs/flight/airlines/PU.png"
  },
  "/imgs/flight/airlines/PV.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.802Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/PV.png"
  },
  "/imgs/flight/airlines/PW.png": {
    "type": "image/png",
    "etag": "\"2a90-35CQAKcNb0GhotZJDjtsptie+g0\"",
    "mtime": "2026-11-01T06:39:54.803Z",
    "size": 10896,
    "path": "../public/imgs/flight/airlines/PW.png"
  },
  "/imgs/flight/airlines/PX.png": {
    "type": "image/png",
    "etag": "\"370f-OQqAMfZ6Le+WQCnUticfjdkYL6U\"",
    "mtime": "2026-11-01T06:39:54.805Z",
    "size": 14095,
    "path": "../public/imgs/flight/airlines/PX.png"
  },
  "/imgs/flight/airlines/PY.png": {
    "type": "image/png",
    "etag": "\"3bfb-MxysyyJSW3Al0QyvZlnKTXhfZuo\"",
    "mtime": "2026-11-01T06:39:54.806Z",
    "size": 15355,
    "path": "../public/imgs/flight/airlines/PY.png"
  },
  "/imgs/flight/airlines/PZ.png": {
    "type": "image/png",
    "etag": "\"949-wRzHnuSC/JWm9pPxFn/nMQzvAa4\"",
    "mtime": "2026-11-01T06:39:54.807Z",
    "size": 2377,
    "path": "../public/imgs/flight/airlines/PZ.png"
  },
  "/imgs/flight/airlines/Q3.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.807Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/Q3.png"
  },
  "/imgs/flight/airlines/Q4.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.808Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/Q4.png"
  },
  "/imgs/flight/airlines/Q5.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.808Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/Q5.png"
  },
  "/imgs/flight/airlines/Q6.png": {
    "type": "image/png",
    "etag": "\"d04-NKSlA84kZzA4FjHsYCtDPmIRqZk\"",
    "mtime": "2026-11-01T06:39:54.809Z",
    "size": 3332,
    "path": "../public/imgs/flight/airlines/Q6.png"
  },
  "/imgs/flight/airlines/Q8.png": {
    "type": "image/png",
    "etag": "\"77e-tYSOqQcf+NLR0GAt4ODQIABzXhg\"",
    "mtime": "2026-11-01T06:39:54.810Z",
    "size": 1918,
    "path": "../public/imgs/flight/airlines/Q8.png"
  },
  "/imgs/flight/airlines/qatar-airways.png": {
    "type": "image/png",
    "etag": "\"9816-rUz+iOoyqNdj+irHaPmnLJfZSYE\"",
    "mtime": "2026-08-24T08:29:56.417Z",
    "size": 38934,
    "path": "../public/imgs/flight/airlines/qatar-airways.png"
  },
  "/imgs/flight/airlines/qatar-airways1212.png": {
    "type": "image/png",
    "etag": "\"11f2c-sgScevvwD2MDj8V9B9k/QK58TNc\"",
    "mtime": "2026-08-24T08:29:56.420Z",
    "size": 73516,
    "path": "../public/imgs/flight/airlines/qatar-airways1212.png"
  },
  "/imgs/flight/airlines/QB.png": {
    "type": "image/png",
    "etag": "\"133d-Bsf6z9GVMhs8+STWfIoI4VDMXu8\"",
    "mtime": "2026-11-01T06:39:54.811Z",
    "size": 4925,
    "path": "../public/imgs/flight/airlines/QB.png"
  },
  "/imgs/flight/airlines/QC.png": {
    "type": "image/png",
    "etag": "\"ba5-ijyEOuqVNqoQmLEYePE3ptHHYKE\"",
    "mtime": "2026-11-01T06:39:54.811Z",
    "size": 2981,
    "path": "../public/imgs/flight/airlines/QC.png"
  },
  "/imgs/flight/airlines/qeshm.png": {
    "type": "image/png",
    "etag": "\"1fd2-GDve7S1WvB+7ngwNLemDm+vMoA0\"",
    "mtime": "2026-08-24T08:29:56.421Z",
    "size": 8146,
    "path": "../public/imgs/flight/airlines/qeshm.png"
  },
  "/imgs/flight/airlines/QF.png": {
    "type": "image/png",
    "etag": "\"d0b-Dl0FosVDQI2rKJnDOLTunEda3qA\"",
    "mtime": "2026-11-01T06:39:54.812Z",
    "size": 3339,
    "path": "../public/imgs/flight/airlines/QF.png"
  },
  "/imgs/flight/airlines/QG.png": {
    "type": "image/png",
    "etag": "\"9f1-rl2NtpN06q2ZU3s9Jq7p9bexFKY\"",
    "mtime": "2026-11-01T06:39:54.813Z",
    "size": 2545,
    "path": "../public/imgs/flight/airlines/QG.png"
  },
  "/imgs/flight/airlines/QH.png": {
    "type": "image/png",
    "etag": "\"2a2a-ZzfWGrHlrRKe1b18anw/opF5yT0\"",
    "mtime": "2026-11-01T06:39:54.814Z",
    "size": 10794,
    "path": "../public/imgs/flight/airlines/QH.png"
  },
  "/imgs/flight/airlines/QI.png": {
    "type": "image/png",
    "etag": "\"281b-NMfy1+J0U7v1Pe+L5v0pnB/E9qg\"",
    "mtime": "2026-11-01T06:39:54.815Z",
    "size": 10267,
    "path": "../public/imgs/flight/airlines/QI.png"
  },
  "/imgs/flight/airlines/QK.png": {
    "type": "image/png",
    "etag": "\"a28-hDfQL7oe7wH5KLnP1JaQlXMRMPY\"",
    "mtime": "2026-11-01T06:39:54.816Z",
    "size": 2600,
    "path": "../public/imgs/flight/airlines/QK.png"
  },
  "/imgs/flight/airlines/QL.png": {
    "type": "image/png",
    "etag": "\"114b-lylSq2yiuDwoSTu8EEmOKWI1/z0\"",
    "mtime": "2026-11-01T06:39:54.834Z",
    "size": 4427,
    "path": "../public/imgs/flight/airlines/QL.png"
  },
  "/imgs/flight/airlines/QM.png": {
    "type": "image/png",
    "etag": "\"2eb5-2DJ2yJUeOZl5jVKhPcgWoCy+YDo\"",
    "mtime": "2026-11-01T06:39:54.835Z",
    "size": 11957,
    "path": "../public/imgs/flight/airlines/QM.png"
  },
  "/imgs/flight/airlines/QR.png": {
    "type": "image/png",
    "etag": "\"1fd8-XDvDd56eaoCdYqMJcRpxLdi2myU\"",
    "mtime": "2026-11-01T06:39:54.836Z",
    "size": 8152,
    "path": "../public/imgs/flight/airlines/QR.png"
  },
  "/imgs/flight/airlines/QS.png": {
    "type": "image/png",
    "etag": "\"1cc1-Af5F0Ex5m4o+mDfx4qD5i1PGjVg\"",
    "mtime": "2026-11-01T06:39:54.837Z",
    "size": 7361,
    "path": "../public/imgs/flight/airlines/QS.png"
  },
  "/imgs/flight/airlines/QU.png": {
    "type": "image/png",
    "etag": "\"333c-YoOqPBOn/ohckLleo2MH4nbEhVI\"",
    "mtime": "2026-11-01T06:39:54.838Z",
    "size": 13116,
    "path": "../public/imgs/flight/airlines/QU.png"
  },
  "/imgs/flight/airlines/QV.png": {
    "type": "image/png",
    "etag": "\"22f1-zqKQ2mxyVPeTPwyXzBUmSIVsCP0\"",
    "mtime": "2026-11-01T06:39:54.839Z",
    "size": 8945,
    "path": "../public/imgs/flight/airlines/QV.png"
  },
  "/imgs/flight/airlines/QW.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.840Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/QW.png"
  },
  "/imgs/flight/airlines/QX.png": {
    "type": "image/png",
    "etag": "\"c9c-9CFCYjjRkAeq1dAWC19te9KqUGs\"",
    "mtime": "2026-11-01T06:39:54.841Z",
    "size": 3228,
    "path": "../public/imgs/flight/airlines/QX.png"
  },
  "/imgs/flight/airlines/QZ.png": {
    "type": "image/png",
    "etag": "\"1b28-Lharq+E7hvu1F+gXmDhR1xQ4chI\"",
    "mtime": "2026-11-01T06:39:54.841Z",
    "size": 6952,
    "path": "../public/imgs/flight/airlines/QZ.png"
  },
  "/imgs/flight/airlines/R2.png": {
    "type": "image/png",
    "etag": "\"30d6-0+FUDky1+vUIFYpo/mR0UDlAt7w\"",
    "mtime": "2026-11-01T06:39:54.842Z",
    "size": 12502,
    "path": "../public/imgs/flight/airlines/R2.png"
  },
  "/imgs/flight/airlines/R3.png": {
    "type": "image/png",
    "etag": "\"3a09-nKj+ZkAFJKqkywf20RzIjejuRCE\"",
    "mtime": "2026-11-01T06:39:54.843Z",
    "size": 14857,
    "path": "../public/imgs/flight/airlines/R3.png"
  },
  "/imgs/flight/airlines/R6.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.844Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/R6.png"
  },
  "/imgs/flight/airlines/R7.png": {
    "type": "image/png",
    "etag": "\"c75-rA34eAPQf+dLoLPa1vv60L5jqHA\"",
    "mtime": "2026-11-01T06:39:54.844Z",
    "size": 3189,
    "path": "../public/imgs/flight/airlines/R7.png"
  },
  "/imgs/flight/airlines/RA.png": {
    "type": "image/png",
    "etag": "\"131f-6GiE1YgJ5cCct5i/AH1R7y5n0S8\"",
    "mtime": "2026-11-01T06:39:54.845Z",
    "size": 4895,
    "path": "../public/imgs/flight/airlines/RA.png"
  },
  "/imgs/flight/airlines/RB.png": {
    "type": "image/png",
    "etag": "\"2cb6-scw4vm/EqlONaslS9cF9Zy+o/bQ\"",
    "mtime": "2026-11-01T06:39:54.846Z",
    "size": 11446,
    "path": "../public/imgs/flight/airlines/RB.png"
  },
  "/imgs/flight/airlines/RC.png": {
    "type": "image/png",
    "etag": "\"a26-QnXFWi2FpSbPB1k5g3nFecxwOjU\"",
    "mtime": "2026-11-01T06:39:54.847Z",
    "size": 2598,
    "path": "../public/imgs/flight/airlines/RC.png"
  },
  "/imgs/flight/airlines/RE.png": {
    "type": "image/png",
    "etag": "\"1b53-BgXPJIIxvWyhVwxZYjWNo5WQlwM\"",
    "mtime": "2026-11-01T06:39:54.848Z",
    "size": 6995,
    "path": "../public/imgs/flight/airlines/RE.png"
  },
  "/imgs/flight/airlines/RG.png": {
    "type": "image/png",
    "etag": "\"79d-juuC14ddYJesLEwhLc6EoDzpY/U\"",
    "mtime": "2026-11-01T06:39:54.849Z",
    "size": 1949,
    "path": "../public/imgs/flight/airlines/RG.png"
  },
  "/imgs/flight/airlines/RH.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.850Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/RH.png"
  },
  "/imgs/flight/airlines/RI.png": {
    "type": "image/png",
    "etag": "\"1e53-Z8QLx6O5B6t1W1snfel4Yw3RqsQ\"",
    "mtime": "2026-11-01T06:39:54.850Z",
    "size": 7763,
    "path": "../public/imgs/flight/airlines/RI.png"
  },
  "/imgs/flight/airlines/RJ.png": {
    "type": "image/png",
    "etag": "\"c86-5gS58PZxn/XL+Mxy0Wjbs+FqkyY\"",
    "mtime": "2026-11-01T06:39:54.851Z",
    "size": 3206,
    "path": "../public/imgs/flight/airlines/RJ.png"
  },
  "/imgs/flight/airlines/RK.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.851Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/RK.png"
  },
  "/imgs/flight/airlines/RL.png": {
    "type": "image/png",
    "etag": "\"ebc-Lbxm5Y1JgWWo85KnsXkare4FCh4\"",
    "mtime": "2026-11-01T06:39:54.852Z",
    "size": 3772,
    "path": "../public/imgs/flight/airlines/RL.png"
  },
  "/imgs/flight/airlines/RM.png": {
    "type": "image/png",
    "etag": "\"3b23-Y/LL1sut0V5iaoDYD4IezZOjcS0\"",
    "mtime": "2026-11-01T06:39:54.853Z",
    "size": 15139,
    "path": "../public/imgs/flight/airlines/RM.png"
  },
  "/imgs/flight/airlines/RO.png": {
    "type": "image/png",
    "etag": "\"9a5-wDyvNj3eEEJQ+0+i/viJgHnJtDU\"",
    "mtime": "2026-11-01T06:39:54.854Z",
    "size": 2469,
    "path": "../public/imgs/flight/airlines/RO.png"
  },
  "/imgs/flight/airlines/RQ.png": {
    "type": "image/png",
    "etag": "\"fd4-QcH4TXwIMKCN1khJGwuZam19GjU\"",
    "mtime": "2026-11-01T06:39:54.855Z",
    "size": 4052,
    "path": "../public/imgs/flight/airlines/RQ.png"
  },
  "/imgs/flight/airlines/RU.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.856Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/RU.png"
  },
  "/imgs/flight/airlines/rwandair.png": {
    "type": "image/png",
    "etag": "\"aad8-9iHeFY4NWBzL/UlTfghEuxx7jMU\"",
    "mtime": "2026-08-24T08:29:56.424Z",
    "size": 43736,
    "path": "../public/imgs/flight/airlines/rwandair.png"
  },
  "/imgs/flight/airlines/RX.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.856Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/RX.png"
  },
  "/imgs/flight/airlines/RZ.png": {
    "type": "image/png",
    "etag": "\"1251-B9RvaN0VKlCPaU8R5FpCY0aFV0U\"",
    "mtime": "2026-11-01T06:39:54.857Z",
    "size": 4689,
    "path": "../public/imgs/flight/airlines/RZ.png"
  },
  "/imgs/flight/airlines/S0.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.858Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/S0.png"
  },
  "/imgs/flight/airlines/S2.png": {
    "type": "image/png",
    "etag": "\"e1c-zBAzjp6vhZZ96IRDwN00o62njzU\"",
    "mtime": "2026-11-01T06:39:54.858Z",
    "size": 3612,
    "path": "../public/imgs/flight/airlines/S2.png"
  },
  "/imgs/flight/airlines/S3.png": {
    "type": "image/png",
    "etag": "\"1083-WTNpkZK5xlcQ2TDQo6KlRqv22+M\"",
    "mtime": "2026-11-01T06:39:54.859Z",
    "size": 4227,
    "path": "../public/imgs/flight/airlines/S3.png"
  },
  "/imgs/flight/airlines/S4.png": {
    "type": "image/png",
    "etag": "\"c4f-WjkwbDtMaLflE3/i0AhQDI5rLe4\"",
    "mtime": "2026-11-01T06:39:54.860Z",
    "size": 3151,
    "path": "../public/imgs/flight/airlines/S4.png"
  },
  "/imgs/flight/airlines/S5.png": {
    "type": "image/png",
    "etag": "\"116d-PttKkJZJE8yjajs3GyQKa4OHpGQ\"",
    "mtime": "2026-11-01T06:39:54.861Z",
    "size": 4461,
    "path": "../public/imgs/flight/airlines/S5.png"
  },
  "/imgs/flight/airlines/S6.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.861Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/S6.png"
  },
  "/imgs/flight/airlines/S7.png": {
    "type": "image/png",
    "etag": "\"a65-lzfvYNoa4uXfFdryfYfc5CK5fLo\"",
    "mtime": "2026-11-01T06:39:54.862Z",
    "size": 2661,
    "path": "../public/imgs/flight/airlines/S7.png"
  },
  "/imgs/flight/airlines/S9.png": {
    "type": "image/png",
    "etag": "\"e5d-X9nHmFQxh1aJs4SSG+NdnoxutqY\"",
    "mtime": "2026-11-01T06:39:54.862Z",
    "size": 3677,
    "path": "../public/imgs/flight/airlines/S9.png"
  },
  "/imgs/flight/airlines/SA.png": {
    "type": "image/png",
    "etag": "\"3be8-bIJrZa22N8gyQ5XuD7M8PFxSHp8\"",
    "mtime": "2026-11-01T06:39:54.863Z",
    "size": 15336,
    "path": "../public/imgs/flight/airlines/SA.png"
  },
  "/imgs/flight/airlines/saha.png": {
    "type": "image/png",
    "etag": "\"1b002-y7fZjrfRAY2Sno76RWTduG0P9xc\"",
    "mtime": "2026-07-13T06:00:39.843Z",
    "size": 110594,
    "path": "../public/imgs/flight/airlines/saha.png"
  },
  "/imgs/flight/airlines/SB.png": {
    "type": "image/png",
    "etag": "\"229b-kBabvktiNRbLbN1AN+Ui1/pQlhQ\"",
    "mtime": "2026-11-01T06:39:54.864Z",
    "size": 8859,
    "path": "../public/imgs/flight/airlines/SB.png"
  },
  "/imgs/flight/airlines/SC.png": {
    "type": "image/png",
    "etag": "\"158e-tFQgzanITdCbrWJN1MsRvXI5RI0\"",
    "mtime": "2026-11-01T06:39:54.865Z",
    "size": 5518,
    "path": "../public/imgs/flight/airlines/SC.png"
  },
  "/imgs/flight/airlines/SD.png": {
    "type": "image/png",
    "etag": "\"17bf-sIaH7Y0nISYQhVkjpMM+oRjeNgU\"",
    "mtime": "2026-11-01T06:39:54.866Z",
    "size": 6079,
    "path": "../public/imgs/flight/airlines/SD.png"
  },
  "/imgs/flight/airlines/SE.png": {
    "type": "image/png",
    "etag": "\"802-KlzX6jqjxlOXmf2AoEjcREU9ejc\"",
    "mtime": "2026-11-01T06:39:54.866Z",
    "size": 2050,
    "path": "../public/imgs/flight/airlines/SE.png"
  },
  "/imgs/flight/airlines/sepahan.jpg": {
    "type": "image/jpeg",
    "etag": "\"8c7b-zWHMrpyIp6WIAjMXLhFXorOI0Is\"",
    "mtime": "2026-07-13T06:00:39.844Z",
    "size": 35963,
    "path": "../public/imgs/flight/airlines/sepahan.jpg"
  },
  "/imgs/flight/airlines/sepehran.png": {
    "type": "image/png",
    "etag": "\"1d78d-g65h3g0DmAS3jszqV5cuXItHmMY\"",
    "mtime": "2026-07-13T06:00:39.845Z",
    "size": 120717,
    "path": "../public/imgs/flight/airlines/sepehran.png"
  },
  "/imgs/flight/airlines/SF.png": {
    "type": "image/png",
    "etag": "\"991-bQX8vEueA3NrTp1N0PgD87P6dgw\"",
    "mtime": "2026-11-01T06:39:54.867Z",
    "size": 2449,
    "path": "../public/imgs/flight/airlines/SF.png"
  },
  "/imgs/flight/airlines/SG.png": {
    "type": "image/png",
    "etag": "\"1c95-q10p3e2A5bETyKgi+ccYdHAM0l0\"",
    "mtime": "2026-11-01T06:39:54.868Z",
    "size": 7317,
    "path": "../public/imgs/flight/airlines/SG.png"
  },
  "/imgs/flight/airlines/SH.png": {
    "type": "image/png",
    "etag": "\"14da-SoIBsgFUHJNHcmReuZDnY1lP52c\"",
    "mtime": "2026-11-01T06:39:54.869Z",
    "size": 5338,
    "path": "../public/imgs/flight/airlines/SH.png"
  },
  "/imgs/flight/airlines/SI.png": {
    "type": "image/png",
    "etag": "\"855d-T9vbs1GRu6TkzX9Udo5NBArcs6M\"",
    "mtime": "2026-11-01T06:39:54.870Z",
    "size": 34141,
    "path": "../public/imgs/flight/airlines/SI.png"
  },
  "/imgs/flight/airlines/SJ.png": {
    "type": "image/png",
    "etag": "\"3995-VldpTumiwN8Hna5mOawZsmoFKXc\"",
    "mtime": "2026-11-01T06:39:54.871Z",
    "size": 14741,
    "path": "../public/imgs/flight/airlines/SJ.png"
  },
  "/imgs/flight/airlines/SK.png": {
    "type": "image/png",
    "etag": "\"ce6-WWDZcPkIdpBDX11Ubz9ubCAFPAw\"",
    "mtime": "2026-11-01T06:39:54.872Z",
    "size": 3302,
    "path": "../public/imgs/flight/airlines/SK.png"
  },
  "/imgs/flight/airlines/SL.png": {
    "type": "image/png",
    "etag": "\"15cb-HVdNwK/iTeaMMmjMjEw65jWAoZs\"",
    "mtime": "2026-11-01T06:39:54.873Z",
    "size": 5579,
    "path": "../public/imgs/flight/airlines/SL.png"
  },
  "/imgs/flight/airlines/SM.png": {
    "type": "image/png",
    "etag": "\"8d6-2e1ozbKV4v7ODhQzB6I9NnaIKfs\"",
    "mtime": "2026-11-01T06:39:54.874Z",
    "size": 2262,
    "path": "../public/imgs/flight/airlines/SM.png"
  },
  "/imgs/flight/airlines/SN.png": {
    "type": "image/png",
    "etag": "\"f22-6OZ6pkAcH/Fzr4G2khYv3e8Vx7o\"",
    "mtime": "2026-11-01T06:39:54.875Z",
    "size": 3874,
    "path": "../public/imgs/flight/airlines/SN.png"
  },
  "/imgs/flight/airlines/SO.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.875Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/SO.png"
  },
  "/imgs/flight/airlines/SP.png": {
    "type": "image/png",
    "etag": "\"11fb-C/cSCXtb6kONb/3ZaUNQtX1s+pU\"",
    "mtime": "2026-11-01T06:39:54.876Z",
    "size": 4603,
    "path": "../public/imgs/flight/airlines/SP.png"
  },
  "/imgs/flight/airlines/SQ.png": {
    "type": "image/png",
    "etag": "\"ab4-5FDOxsoVgVJqJNOX86ztGuRSENc\"",
    "mtime": "2026-11-01T06:39:54.877Z",
    "size": 2740,
    "path": "../public/imgs/flight/airlines/SQ.png"
  },
  "/imgs/flight/airlines/SS.png": {
    "type": "image/png",
    "etag": "\"20ff-xYOHO0LSCxy7WtWhSOxTfw7dJkg\"",
    "mtime": "2026-11-01T06:39:54.878Z",
    "size": 8447,
    "path": "../public/imgs/flight/airlines/SS.png"
  },
  "/imgs/flight/airlines/SU.png": {
    "type": "image/png",
    "etag": "\"1454-FcRgMsHD0iibTbV9Li3TYqfI3L0\"",
    "mtime": "2026-11-01T06:39:54.879Z",
    "size": 5204,
    "path": "../public/imgs/flight/airlines/SU.png"
  },
  "/imgs/flight/airlines/SV.png": {
    "type": "image/png",
    "etag": "\"13b2-o65Jr8cbfj98VEj/9ywVNrR4lIY\"",
    "mtime": "2026-11-01T06:39:54.880Z",
    "size": 5042,
    "path": "../public/imgs/flight/airlines/SV.png"
  },
  "/imgs/flight/airlines/SW.png": {
    "type": "image/png",
    "etag": "\"b44-LatPKZA+0PugJYtxwn46xNpfGOs\"",
    "mtime": "2026-11-01T06:39:54.880Z",
    "size": 2884,
    "path": "../public/imgs/flight/airlines/SW.png"
  },
  "/imgs/flight/airlines/swiss.png": {
    "type": "image/png",
    "etag": "\"22a4-8ff0JirVnfghm7h+FFSbbdQOJlo\"",
    "mtime": "2026-08-24T08:29:56.426Z",
    "size": 8868,
    "path": "../public/imgs/flight/airlines/swiss.png"
  },
  "/imgs/flight/airlines/SX.png": {
    "type": "image/png",
    "etag": "\"cba-YmEYcm9bbhlIgfaxPpgXiDTCDzc\"",
    "mtime": "2026-11-01T06:39:54.881Z",
    "size": 3258,
    "path": "../public/imgs/flight/airlines/SX.png"
  },
  "/imgs/flight/airlines/SY.png": {
    "type": "image/png",
    "etag": "\"18a1-lY91t3O+fYi3nmWZamiD7GxCNq4\"",
    "mtime": "2026-11-01T06:39:54.882Z",
    "size": 6305,
    "path": "../public/imgs/flight/airlines/SY.png"
  },
  "/imgs/flight/airlines/T3.png": {
    "type": "image/png",
    "etag": "\"85c-ipDUaCkku9yEzb1C9b76Umjb1QM\"",
    "mtime": "2026-11-01T06:39:54.883Z",
    "size": 2140,
    "path": "../public/imgs/flight/airlines/T3.png"
  },
  "/imgs/flight/airlines/T4.png": {
    "type": "image/png",
    "etag": "\"13bf-mVbxykDYoDsy8VAjvUMWPpqCM8U\"",
    "mtime": "2026-11-01T06:39:54.883Z",
    "size": 5055,
    "path": "../public/imgs/flight/airlines/T4.png"
  },
  "/imgs/flight/airlines/T5.png": {
    "type": "image/png",
    "etag": "\"b21-V7Z2J3ZzZMplGt6fHo5OhIp59g8\"",
    "mtime": "2026-11-01T06:39:54.884Z",
    "size": 2849,
    "path": "../public/imgs/flight/airlines/T5.png"
  },
  "/imgs/flight/airlines/T6.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.885Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/T6.png"
  },
  "/imgs/flight/airlines/T7.png": {
    "type": "image/png",
    "etag": "\"2c02-x0g589tAt7LwXxcvAhZuUZY90RY\"",
    "mtime": "2026-11-01T06:39:54.886Z",
    "size": 11266,
    "path": "../public/imgs/flight/airlines/T7.png"
  },
  "/imgs/flight/airlines/TA.png": {
    "type": "image/png",
    "etag": "\"1137-qGmUnW2TtOIG9Nskk1RJqwRaw5s\"",
    "mtime": "2026-11-01T06:39:54.887Z",
    "size": 4407,
    "path": "../public/imgs/flight/airlines/TA.png"
  },
  "/imgs/flight/airlines/taban.png": {
    "type": "image/png",
    "etag": "\"12876-ALWJ+unUMVJyfDbERk3taUcZ4Ic\"",
    "mtime": "2026-07-13T06:00:39.846Z",
    "size": 75894,
    "path": "../public/imgs/flight/airlines/taban.png"
  },
  "/imgs/flight/airlines/TC.png": {
    "type": "image/png",
    "etag": "\"391f-fbxv4ZuOfBdg9xoQrJo9AJ6V2qE\"",
    "mtime": "2026-11-01T06:39:54.888Z",
    "size": 14623,
    "path": "../public/imgs/flight/airlines/TC.png"
  },
  "/imgs/flight/airlines/TD.png": {
    "type": "image/png",
    "etag": "\"c12-v4nqasvERcFOf+J9/GWCqWK9SdA\"",
    "mtime": "2026-11-01T06:39:54.889Z",
    "size": 3090,
    "path": "../public/imgs/flight/airlines/TD.png"
  },
  "/imgs/flight/airlines/TE.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.890Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/TE.png"
  },
  "/imgs/flight/airlines/TF.png": {
    "type": "image/png",
    "etag": "\"6233-7pLjZ6hkghQYJChBtXhWs75iwIU\"",
    "mtime": "2026-11-01T06:39:54.891Z",
    "size": 25139,
    "path": "../public/imgs/flight/airlines/TF.png"
  },
  "/imgs/flight/airlines/TG.png": {
    "type": "image/png",
    "etag": "\"1d86-BiHXfzJzKsokQyIPb8LL6HVY2DU\"",
    "mtime": "2026-11-01T06:39:54.892Z",
    "size": 7558,
    "path": "../public/imgs/flight/airlines/TG.png"
  },
  "/imgs/flight/airlines/thaiairways.png": {
    "type": "image/png",
    "etag": "\"7c7e-+6ZAITPvmVLYEfuFg/PKazyMb2Q\"",
    "mtime": "2026-08-24T08:29:56.427Z",
    "size": 31870,
    "path": "../public/imgs/flight/airlines/thaiairways.png"
  },
  "/imgs/flight/airlines/TI.png": {
    "type": "image/png",
    "etag": "\"c1f-sydqsbPmaa2VfJBT6VBBVgLX1YU\"",
    "mtime": "2026-11-01T06:39:54.893Z",
    "size": 3103,
    "path": "../public/imgs/flight/airlines/TI.png"
  },
  "/imgs/flight/airlines/TJ.png": {
    "type": "image/png",
    "etag": "\"af5-Jnf7Z84PyBDbf7j8GDATY5QgVm0\"",
    "mtime": "2026-11-01T06:39:54.893Z",
    "size": 2805,
    "path": "../public/imgs/flight/airlines/TJ.png"
  },
  "/imgs/flight/airlines/TK.png": {
    "type": "image/png",
    "etag": "\"2607-JrSRPLrMoKSXiHgxSsRmffazfp0\"",
    "mtime": "2026-11-01T06:39:54.894Z",
    "size": 9735,
    "path": "../public/imgs/flight/airlines/TK.png"
  },
  "/imgs/flight/airlines/TL.png": {
    "type": "image/png",
    "etag": "\"17a7-q9eLKdg77F9vnyL4jP5xs+jyEcg\"",
    "mtime": "2026-11-01T06:39:54.895Z",
    "size": 6055,
    "path": "../public/imgs/flight/airlines/TL.png"
  },
  "/imgs/flight/airlines/TM.png": {
    "type": "image/png",
    "etag": "\"ec0-fkKZxmAwmQKvKAyDZiF1ydQEf8Y\"",
    "mtime": "2026-11-01T06:39:54.896Z",
    "size": 3776,
    "path": "../public/imgs/flight/airlines/TM.png"
  },
  "/imgs/flight/airlines/TN.png": {
    "type": "image/png",
    "etag": "\"e95-vkqaUzxs8uGQtR0BNpIFpZST8L0\"",
    "mtime": "2026-11-01T06:39:54.897Z",
    "size": 3733,
    "path": "../public/imgs/flight/airlines/TN.png"
  },
  "/imgs/flight/airlines/TO.png": {
    "type": "image/png",
    "etag": "\"1c57-SzH0i8QhriCcBzBHzaO2wN9CYb0\"",
    "mtime": "2026-11-01T06:39:54.898Z",
    "size": 7255,
    "path": "../public/imgs/flight/airlines/TO.png"
  },
  "/imgs/flight/airlines/TP.png": {
    "type": "image/png",
    "etag": "\"d46-RhBprQdqA3swMrjz/sdPwJO+/i4\"",
    "mtime": "2026-11-01T06:39:54.899Z",
    "size": 3398,
    "path": "../public/imgs/flight/airlines/TP.png"
  },
  "/imgs/flight/airlines/TQ.png": {
    "type": "image/png",
    "etag": "\"3702-NBE7SYGQLXIyB+pgT1TljRx7YD8\"",
    "mtime": "2026-11-01T06:39:54.900Z",
    "size": 14082,
    "path": "../public/imgs/flight/airlines/TQ.png"
  },
  "/imgs/flight/airlines/TR.png": {
    "type": "image/png",
    "etag": "\"4ae-cmNhpXNto/fvp7f2FRzLZmTlfYg\"",
    "mtime": "2026-11-01T06:39:54.900Z",
    "size": 1198,
    "path": "../public/imgs/flight/airlines/TR.png"
  },
  "/imgs/flight/airlines/TS.png": {
    "type": "image/png",
    "etag": "\"23a3-r1YwI20o7eFyR+w2S2xv91sqJD8\"",
    "mtime": "2026-11-01T06:39:54.901Z",
    "size": 9123,
    "path": "../public/imgs/flight/airlines/TS.png"
  },
  "/imgs/flight/airlines/TU.png": {
    "type": "image/png",
    "etag": "\"2410-DH9ACirFm0JnMovUZtxZYfEaVyU\"",
    "mtime": "2026-11-01T06:39:54.902Z",
    "size": 9232,
    "path": "../public/imgs/flight/airlines/TU.png"
  },
  "/imgs/flight/airlines/TT.png": {
    "type": "image/png",
    "etag": "\"4ae-cmNhpXNto/fvp7f2FRzLZmTlfYg\"",
    "mtime": "2026-11-01T06:39:54.902Z",
    "size": 1198,
    "path": "../public/imgs/flight/airlines/TT.png"
  },
  "/imgs/flight/airlines/Turkish-Airlines.png": {
    "type": "image/png",
    "etag": "\"5043-R+ra1t/J8Sjir0PKK52aYQboV7w\"",
    "mtime": "2026-08-24T08:29:56.285Z",
    "size": 20547,
    "path": "../public/imgs/flight/airlines/Turkish-Airlines.png"
  },
  "/imgs/flight/airlines/turkish.png": {
    "type": "image/png",
    "etag": "\"477c-2Wux4LJQQbYlrk4LLn2dbCYkSpc\"",
    "mtime": "2026-08-24T08:29:56.429Z",
    "size": 18300,
    "path": "../public/imgs/flight/airlines/turkish.png"
  },
  "/imgs/flight/airlines/TV.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.903Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/TV.png"
  },
  "/imgs/flight/airlines/TW.png": {
    "type": "image/png",
    "etag": "\"21e0-DZ+82/RmHZyHIR6xpP7Z8QIC8jY\"",
    "mtime": "2026-11-01T06:39:54.904Z",
    "size": 8672,
    "path": "../public/imgs/flight/airlines/TW.png"
  },
  "/imgs/flight/airlines/TX.png": {
    "type": "image/png",
    "etag": "\"ed2-o/jYL243REAtJP2Cdnv+3SEpTYg\"",
    "mtime": "2026-11-01T06:39:54.905Z",
    "size": 3794,
    "path": "../public/imgs/flight/airlines/TX.png"
  },
  "/imgs/flight/airlines/TY.png": {
    "type": "image/png",
    "etag": "\"14e4-fUCzwB1NEhLuLZcAao5gH/hY64Q\"",
    "mtime": "2026-11-01T06:39:54.906Z",
    "size": 5348,
    "path": "../public/imgs/flight/airlines/TY.png"
  },
  "/imgs/flight/airlines/U2.png": {
    "type": "image/png",
    "etag": "\"c07-87asjdEkXqUQspPru9/wTzUySzI\"",
    "mtime": "2026-11-01T06:39:54.907Z",
    "size": 3079,
    "path": "../public/imgs/flight/airlines/U2.png"
  },
  "/imgs/flight/airlines/U3.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.908Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/U3.png"
  },
  "/imgs/flight/airlines/U4.png": {
    "type": "image/png",
    "etag": "\"7b0-vDvAXoznLIeRBg0o+39mEyuLlHc\"",
    "mtime": "2026-11-01T06:39:54.909Z",
    "size": 1968,
    "path": "../public/imgs/flight/airlines/U4.png"
  },
  "/imgs/flight/airlines/U5.png": {
    "type": "image/png",
    "etag": "\"59e-ZEhRmwy05ui/PdB3Fx2rva89+sc\"",
    "mtime": "2026-11-01T06:39:54.909Z",
    "size": 1438,
    "path": "../public/imgs/flight/airlines/U5.png"
  },
  "/imgs/flight/airlines/U6.png": {
    "type": "image/png",
    "etag": "\"1438-6qjRNhYGxu6a8Jg+Z4QnL2Ftqx0\"",
    "mtime": "2026-11-01T06:39:54.910Z",
    "size": 5176,
    "path": "../public/imgs/flight/airlines/U6.png"
  },
  "/imgs/flight/airlines/U7.png": {
    "type": "image/png",
    "etag": "\"3512-NaA+rElbZ6rkkN/J1ngjQoXhd/c\"",
    "mtime": "2026-11-01T06:39:54.911Z",
    "size": 13586,
    "path": "../public/imgs/flight/airlines/U7.png"
  },
  "/imgs/flight/airlines/U8.png": {
    "type": "image/png",
    "etag": "\"dd8-PwTT8PM8BsQ0oxhEyJdE2ro0p9E\"",
    "mtime": "2026-11-01T06:39:54.912Z",
    "size": 3544,
    "path": "../public/imgs/flight/airlines/U8.png"
  },
  "/imgs/flight/airlines/UA.png": {
    "type": "image/png",
    "etag": "\"3358-RQnLGlBjG3Kz+VHATiT3j17/QeU\"",
    "mtime": "2026-11-01T06:39:54.913Z",
    "size": 13144,
    "path": "../public/imgs/flight/airlines/UA.png"
  },
  "/imgs/flight/airlines/UB.png": {
    "type": "image/png",
    "etag": "\"1554-k61ovp7XdRDB5/tPCwi1UpT+p8c\"",
    "mtime": "2026-11-01T06:39:54.914Z",
    "size": 5460,
    "path": "../public/imgs/flight/airlines/UB.png"
  },
  "/imgs/flight/airlines/UD.png": {
    "type": "image/png",
    "etag": "\"1ec0-PcVJaHlh+R6xkmq2+cyclzbdjHE\"",
    "mtime": "2026-11-01T06:39:54.914Z",
    "size": 7872,
    "path": "../public/imgs/flight/airlines/UD.png"
  },
  "/imgs/flight/airlines/UE.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.915Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/UE.png"
  },
  "/imgs/flight/airlines/UF.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.915Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/UF.png"
  },
  "/imgs/flight/airlines/UG.png": {
    "type": "image/png",
    "etag": "\"db8-+aRhF8EeUjJTEx1KnnsldnKW4fg\"",
    "mtime": "2026-11-01T06:39:54.916Z",
    "size": 3512,
    "path": "../public/imgs/flight/airlines/UG.png"
  },
  "/imgs/flight/airlines/UH.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.917Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/UH.png"
  },
  "/imgs/flight/airlines/UL.png": {
    "type": "image/png",
    "etag": "\"1074-of/3CItPGvhdlH/MvfLP+F+nVx8\"",
    "mtime": "2026-11-01T06:39:54.917Z",
    "size": 4212,
    "path": "../public/imgs/flight/airlines/UL.png"
  },
  "/imgs/flight/airlines/UM.png": {
    "type": "image/png",
    "etag": "\"6cc-kuzPjSVdnBqkf7nWMzi4z5vI/Q4\"",
    "mtime": "2026-11-01T06:39:54.918Z",
    "size": 1740,
    "path": "../public/imgs/flight/airlines/UM.png"
  },
  "/imgs/flight/airlines/UN.png": {
    "type": "image/png",
    "etag": "\"19df-WUj3Wxq6FWaOWt0LlADXLk3YxIU\"",
    "mtime": "2026-11-01T06:39:54.919Z",
    "size": 6623,
    "path": "../public/imgs/flight/airlines/UN.png"
  },
  "/imgs/flight/airlines/united.png": {
    "type": "image/png",
    "etag": "\"11d65-BW5ilSTQRQ5H1nMV6P1x3XlVVJQ\"",
    "mtime": "2026-08-24T08:29:56.431Z",
    "size": 73061,
    "path": "../public/imgs/flight/airlines/united.png"
  },
  "/imgs/flight/airlines/UO.png": {
    "type": "image/png",
    "etag": "\"f67-ERKg7p1cHtJdKWGF4ITFK4l7ymQ\"",
    "mtime": "2026-11-01T06:39:54.920Z",
    "size": 3943,
    "path": "../public/imgs/flight/airlines/UO.png"
  },
  "/imgs/flight/airlines/UP.png": {
    "type": "image/png",
    "etag": "\"1cc9-kZJtouLssRPE5/LREUV45wuEC/s\"",
    "mtime": "2026-11-01T06:39:54.920Z",
    "size": 7369,
    "path": "../public/imgs/flight/airlines/UP.png"
  },
  "/imgs/flight/airlines/UQ.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.921Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/UQ.png"
  },
  "/imgs/flight/airlines/US.png": {
    "type": "image/png",
    "etag": "\"25e-Ql6eHk2hC4031vurify81Lhy8/E\"",
    "mtime": "2026-11-01T06:39:54.922Z",
    "size": 606,
    "path": "../public/imgs/flight/airlines/US.png"
  },
  "/imgs/flight/airlines/UT.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.923Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/UT.png"
  },
  "/imgs/flight/airlines/UU.png": {
    "type": "image/png",
    "etag": "\"13c4-zOyichFG2eecSM/5q99vHF6JpaI\"",
    "mtime": "2026-11-01T06:39:54.924Z",
    "size": 5060,
    "path": "../public/imgs/flight/airlines/UU.png"
  },
  "/imgs/flight/airlines/UX.png": {
    "type": "image/png",
    "etag": "\"aa1-1jH731s3cf+UCw9ynHsMGOVcjHo\"",
    "mtime": "2026-11-01T06:39:54.925Z",
    "size": 2721,
    "path": "../public/imgs/flight/airlines/UX.png"
  },
  "/imgs/flight/airlines/UY.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.925Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/UY.png"
  },
  "/imgs/flight/airlines/UZ.png": {
    "type": "image/png",
    "etag": "\"157f-UCX1bU1A9uPdOLvdjqtJ6HEOyy8\"",
    "mtime": "2026-11-01T06:39:54.926Z",
    "size": 5503,
    "path": "../public/imgs/flight/airlines/UZ.png"
  },
  "/imgs/flight/airlines/V0.png": {
    "type": "image/png",
    "etag": "\"a50-Ry4dvM/qy+vt4JiV3re9QYmN42o\"",
    "mtime": "2026-11-01T06:39:54.927Z",
    "size": 2640,
    "path": "../public/imgs/flight/airlines/V0.png"
  },
  "/imgs/flight/airlines/V2.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.927Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/V2.png"
  },
  "/imgs/flight/airlines/V3.png": {
    "type": "image/png",
    "etag": "\"b3c-aQ1VpAOMnndUOyvsR8aAIw40WXc\"",
    "mtime": "2026-11-01T06:39:54.928Z",
    "size": 2876,
    "path": "../public/imgs/flight/airlines/V3.png"
  },
  "/imgs/flight/airlines/V4.png": {
    "type": "image/png",
    "etag": "\"4aef-u/BBiohEiAD5lr+k+RKl9cjbGm0\"",
    "mtime": "2026-11-01T06:39:54.929Z",
    "size": 19183,
    "path": "../public/imgs/flight/airlines/V4.png"
  },
  "/imgs/flight/airlines/V5.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.929Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/V5.png"
  },
  "/imgs/flight/airlines/V7.png": {
    "type": "image/png",
    "etag": "\"35eb-2DONpowXXFw+hwTe+gQADn6ZZxg\"",
    "mtime": "2026-11-01T06:39:54.930Z",
    "size": 13803,
    "path": "../public/imgs/flight/airlines/V7.png"
  },
  "/imgs/flight/airlines/V8.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.931Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/V8.png"
  },
  "/imgs/flight/airlines/VA.png": {
    "type": "image/png",
    "etag": "\"15ca-Z//OplumOY8ookx3TB0Dzre+nbo\"",
    "mtime": "2026-11-01T06:39:54.931Z",
    "size": 5578,
    "path": "../public/imgs/flight/airlines/VA.png"
  },
  "/imgs/flight/airlines/varesh.png": {
    "type": "image/png",
    "etag": "\"87b4-ZNyRbP/7qqJsG+BjA/G8ty5RPJk\"",
    "mtime": "2026-07-13T06:00:39.847Z",
    "size": 34740,
    "path": "../public/imgs/flight/airlines/varesh.png"
  },
  "/imgs/flight/airlines/VB.png": {
    "type": "image/png",
    "etag": "\"a7d-tPILjVD8Nlvk3MwTm2s3yntLmDU\"",
    "mtime": "2026-11-01T06:39:54.932Z",
    "size": 2685,
    "path": "../public/imgs/flight/airlines/VB.png"
  },
  "/imgs/flight/airlines/VC.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.933Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/VC.png"
  },
  "/imgs/flight/airlines/VE.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.933Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/VE.png"
  },
  "/imgs/flight/airlines/VF.png": {
    "type": "image/png",
    "etag": "\"43a8-P2ANqtgWjlVcJ11j7qOswH79oj4\"",
    "mtime": "2026-11-01T06:39:54.934Z",
    "size": 17320,
    "path": "../public/imgs/flight/airlines/VF.png"
  },
  "/imgs/flight/airlines/VG.png": {
    "type": "image/png",
    "etag": "\"c26-dlUxYgJmZzM6qrRCtEfAbVZOjG0\"",
    "mtime": "2026-11-01T06:39:54.935Z",
    "size": 3110,
    "path": "../public/imgs/flight/airlines/VG.png"
  },
  "/imgs/flight/airlines/VH.png": {
    "type": "image/png",
    "etag": "\"15ec-KsEzczZWPf7LuqWAzhF0dSKqO2s\"",
    "mtime": "2026-11-01T06:39:54.936Z",
    "size": 5612,
    "path": "../public/imgs/flight/airlines/VH.png"
  },
  "/imgs/flight/airlines/VK.png": {
    "type": "image/png",
    "etag": "\"1175-IzKCBd9C4t/LJT//Zbdle4hY/1I\"",
    "mtime": "2026-11-01T06:39:54.937Z",
    "size": 4469,
    "path": "../public/imgs/flight/airlines/VK.png"
  },
  "/imgs/flight/airlines/vistara.png": {
    "type": "image/png",
    "etag": "\"11b1b-sB6ykJfS6DmzJsvjszjGHSCMRP4\"",
    "mtime": "2026-08-24T08:29:56.433Z",
    "size": 72475,
    "path": "../public/imgs/flight/airlines/vistara.png"
  },
  "/imgs/flight/airlines/VM.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.937Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/VM.png"
  },
  "/imgs/flight/airlines/VN.png": {
    "type": "image/png",
    "etag": "\"c3d-6osu3hk0kqNBv5qgT+wdhAPW4fA\"",
    "mtime": "2026-11-01T06:39:54.938Z",
    "size": 3133,
    "path": "../public/imgs/flight/airlines/VN.png"
  },
  "/imgs/flight/airlines/VO.png": {
    "type": "image/png",
    "etag": "\"3767-RwaYIcp9bJdf3Pop7srIQydy8KQ\"",
    "mtime": "2026-11-01T06:39:54.939Z",
    "size": 14183,
    "path": "../public/imgs/flight/airlines/VO.png"
  },
  "/imgs/flight/airlines/VQ.png": {
    "type": "image/png",
    "etag": "\"899-wG/GMViIAT/OH2s8TLeY+HOw0So\"",
    "mtime": "2026-11-01T06:39:54.940Z",
    "size": 2201,
    "path": "../public/imgs/flight/airlines/VQ.png"
  },
  "/imgs/flight/airlines/VR.png": {
    "type": "image/png",
    "etag": "\"1c7d-xaX/pRbSN9xbsgUKflqr3GaEPF4\"",
    "mtime": "2026-11-01T06:39:54.941Z",
    "size": 7293,
    "path": "../public/imgs/flight/airlines/VR.png"
  },
  "/imgs/flight/airlines/VS.png": {
    "type": "image/png",
    "etag": "\"37f7-UlY7D1ODLUz//aVJrB+A7fQDUDY\"",
    "mtime": "2026-11-01T06:39:54.942Z",
    "size": 14327,
    "path": "../public/imgs/flight/airlines/VS.png"
  },
  "/imgs/flight/airlines/VV.png": {
    "type": "image/png",
    "etag": "\"435f-uCpROvYb6PpDMUnrLQE4m0hTWFA\"",
    "mtime": "2026-11-01T06:39:54.984Z",
    "size": 17247,
    "path": "../public/imgs/flight/airlines/VV.png"
  },
  "/imgs/flight/airlines/VU.png": {
    "type": "image/png",
    "etag": "\"1f9e-iLEu+Vdoj8nSGeqO8MCAJWcmgaY\"",
    "mtime": "2026-11-01T06:39:54.943Z",
    "size": 8094,
    "path": "../public/imgs/flight/airlines/VU.png"
  },
  "/imgs/flight/airlines/VT.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:54.943Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/VT.png"
  },
  "/imgs/flight/airlines/VW.png": {
    "type": "image/png",
    "etag": "\"582-NqCDHftQocDq/oetXCFL2WkzSpE\"",
    "mtime": "2026-11-01T06:39:54.985Z",
    "size": 1410,
    "path": "../public/imgs/flight/airlines/VW.png"
  },
  "/imgs/flight/airlines/VX.png": {
    "type": "image/png",
    "etag": "\"1ee3-aiAZ5ILSD6zm83vIu4p8cGxeYhA\"",
    "mtime": "2026-11-01T06:39:54.986Z",
    "size": 7907,
    "path": "../public/imgs/flight/airlines/VX.png"
  },
  "/imgs/flight/airlines/VY.png": {
    "type": "image/png",
    "etag": "\"bf8-juVVUwYmqL5OQv23A/9mduYKPRs\"",
    "mtime": "2026-11-01T06:39:54.987Z",
    "size": 3064,
    "path": "../public/imgs/flight/airlines/VY.png"
  },
  "/imgs/flight/airlines/W2.png": {
    "type": "image/png",
    "etag": "\"1b95-UnxmW/pEsP+B0PwmkLRWOPE7+y4\"",
    "mtime": "2026-11-01T06:39:54.989Z",
    "size": 7061,
    "path": "../public/imgs/flight/airlines/W2.png"
  },
  "/imgs/flight/airlines/VZ.png": {
    "type": "image/png",
    "etag": "\"14dc-g/y2lJvDOxU+4/39f5ZbQlw+ReM\"",
    "mtime": "2026-11-01T06:39:54.988Z",
    "size": 5340,
    "path": "../public/imgs/flight/airlines/VZ.png"
  },
  "/imgs/flight/airlines/W3.png": {
    "type": "image/png",
    "etag": "\"141f-Zw5XDzHwDDzL8liOn99PT97WeMo\"",
    "mtime": "2026-11-01T06:39:54.991Z",
    "size": 5151,
    "path": "../public/imgs/flight/airlines/W3.png"
  },
  "/imgs/flight/airlines/W4.png": {
    "type": "image/png",
    "etag": "\"b40-vH7hMyigw0CC9JT23GfKURjLu8I\"",
    "mtime": "2026-11-01T06:39:54.991Z",
    "size": 2880,
    "path": "../public/imgs/flight/airlines/W4.png"
  },
  "/imgs/flight/airlines/W5.png": {
    "type": "image/png",
    "etag": "\"da8-ksIohjLckXPAlHc04PMiViTBBMM\"",
    "mtime": "2026-11-01T06:39:54.992Z",
    "size": 3496,
    "path": "../public/imgs/flight/airlines/W5.png"
  },
  "/imgs/flight/airlines/W7.png": {
    "type": "image/png",
    "etag": "\"39e4-QuvX87xe9TV8KAARyN0JKA4hFqo\"",
    "mtime": "2026-11-01T06:39:54.994Z",
    "size": 14820,
    "path": "../public/imgs/flight/airlines/W7.png"
  },
  "/imgs/flight/airlines/WA.png": {
    "type": "image/png",
    "etag": "\"931-UGMvdTMvT84yK8E7HF2nTi+2juo\"",
    "mtime": "2026-11-01T06:39:54.995Z",
    "size": 2353,
    "path": "../public/imgs/flight/airlines/WA.png"
  },
  "/imgs/flight/airlines/W6.png": {
    "type": "image/png",
    "etag": "\"847-LLyD+1dv33aAN0L9X1R0RkeI+pA\"",
    "mtime": "2026-11-01T06:39:54.993Z",
    "size": 2119,
    "path": "../public/imgs/flight/airlines/W6.png"
  },
  "/imgs/flight/airlines/WB.png": {
    "type": "image/png",
    "etag": "\"16eb-BpcVlkGO3JXd5qqNJ1kZ1h/c8A4\"",
    "mtime": "2026-11-01T06:39:54.996Z",
    "size": 5867,
    "path": "../public/imgs/flight/airlines/WB.png"
  },
  "/imgs/flight/airlines/westjet.png": {
    "type": "image/png",
    "etag": "\"4c42-yOAkUpfMLC9VNvxw0X33B6K2mN4\"",
    "mtime": "2026-08-24T08:29:56.435Z",
    "size": 19522,
    "path": "../public/imgs/flight/airlines/westjet.png"
  },
  "/imgs/flight/airlines/WF.png": {
    "type": "image/png",
    "etag": "\"8b9-y2ONAEHzdpqNHz+JEqGxGAUfl/8\"",
    "mtime": "2026-11-01T06:39:54.998Z",
    "size": 2233,
    "path": "../public/imgs/flight/airlines/WF.png"
  },
  "/imgs/flight/airlines/WH.png": {
    "type": "image/png",
    "etag": "\"be0-5aGnZGTX6OJoSJeErQ3e69frJ7g\"",
    "mtime": "2026-11-01T06:39:54.999Z",
    "size": 3040,
    "path": "../public/imgs/flight/airlines/WH.png"
  },
  "/imgs/flight/airlines/WK.png": {
    "type": "image/png",
    "etag": "\"38e2-+yWdudG5LYPTPkoK2Yhgq14jWRo\"",
    "mtime": "2026-11-01T06:39:54.999Z",
    "size": 14562,
    "path": "../public/imgs/flight/airlines/WK.png"
  },
  "/imgs/flight/airlines/WM.png": {
    "type": "image/png",
    "etag": "\"2fc2-d7iQJdrAPniePQ9cSBNSnt1wX8I\"",
    "mtime": "2026-11-01T06:39:55.000Z",
    "size": 12226,
    "path": "../public/imgs/flight/airlines/WM.png"
  },
  "/imgs/flight/airlines/WN.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:55.001Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/WN.png"
  },
  "/imgs/flight/airlines/WP.png": {
    "type": "image/png",
    "etag": "\"bac-t9cqIYNG2Dny5O1h0EGen8h7VCk\"",
    "mtime": "2026-11-01T06:39:55.002Z",
    "size": 2988,
    "path": "../public/imgs/flight/airlines/WP.png"
  },
  "/imgs/flight/airlines/WC.png": {
    "type": "image/png",
    "etag": "\"fea-gr+tyK9G+fmiLoMYVgapxrVb1HY\"",
    "mtime": "2026-11-01T06:39:54.997Z",
    "size": 4074,
    "path": "../public/imgs/flight/airlines/WC.png"
  },
  "/imgs/flight/airlines/WR.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:55.003Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/WR.png"
  },
  "/imgs/flight/airlines/WS.png": {
    "type": "image/png",
    "etag": "\"f11-zQf5U/0N8aQzr+C3JpaPxyjeIfI\"",
    "mtime": "2026-11-01T06:39:55.009Z",
    "size": 3857,
    "path": "../public/imgs/flight/airlines/WS.png"
  },
  "/imgs/flight/airlines/WT.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:55.010Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/WT.png"
  },
  "/imgs/flight/airlines/WW.png": {
    "type": "image/png",
    "etag": "\"2c20-0uCPP2cZ94DTF2zGYdzO82Chu2s\"",
    "mtime": "2026-11-01T06:39:55.015Z",
    "size": 11296,
    "path": "../public/imgs/flight/airlines/WW.png"
  },
  "/imgs/flight/airlines/WX.png": {
    "type": "image/png",
    "etag": "\"d92-+45LDXPyvdXXnAuQruE8/0tEQn4\"",
    "mtime": "2026-11-01T06:39:55.016Z",
    "size": 3474,
    "path": "../public/imgs/flight/airlines/WX.png"
  },
  "/imgs/flight/airlines/WY.png": {
    "type": "image/png",
    "etag": "\"20e7-SSxZXs+vBnd/LiwWzbZHwNP8/Gc\"",
    "mtime": "2026-11-01T06:39:55.018Z",
    "size": 8423,
    "path": "../public/imgs/flight/airlines/WY.png"
  },
  "/imgs/flight/airlines/X3.png": {
    "type": "image/png",
    "etag": "\"71d-kLTkkXOmXE/lk0NamYSZwI9hWQI\"",
    "mtime": "2026-11-01T06:39:55.019Z",
    "size": 1821,
    "path": "../public/imgs/flight/airlines/X3.png"
  },
  "/imgs/flight/airlines/X7.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:55.019Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/X7.png"
  },
  "/imgs/flight/airlines/X9.png": {
    "type": "image/png",
    "etag": "\"d92-HEBW2Q6hu3ZyOJvsZbAEM6C5yAs\"",
    "mtime": "2026-11-01T06:39:55.020Z",
    "size": 3474,
    "path": "../public/imgs/flight/airlines/X9.png"
  },
  "/imgs/flight/airlines/XC.png": {
    "type": "image/png",
    "etag": "\"bd6-Of5Dsl1kSY3PbmdSGfWws18/tYc\"",
    "mtime": "2026-11-01T06:39:55.022Z",
    "size": 3030,
    "path": "../public/imgs/flight/airlines/XC.png"
  },
  "/imgs/flight/airlines/XF.png": {
    "type": "image/png",
    "etag": "\"142a-ve0s0z89d/MXpwkF+3SGXXNbFM4\"",
    "mtime": "2026-11-01T06:39:55.024Z",
    "size": 5162,
    "path": "../public/imgs/flight/airlines/XF.png"
  },
  "/imgs/flight/airlines/XK.png": {
    "type": "image/png",
    "etag": "\"923-o5iW6v1NEc7m1VspSX++VEaEM10\"",
    "mtime": "2026-11-01T06:39:55.025Z",
    "size": 2339,
    "path": "../public/imgs/flight/airlines/XK.png"
  },
  "/imgs/flight/airlines/XL.png": {
    "type": "image/png",
    "etag": "\"949-wRzHnuSC/JWm9pPxFn/nMQzvAa4\"",
    "mtime": "2026-11-01T06:39:55.026Z",
    "size": 2377,
    "path": "../public/imgs/flight/airlines/XL.png"
  },
  "/imgs/flight/airlines/XM.png": {
    "type": "image/png",
    "etag": "\"2c8d-AuQAtSg5UfLQg3lHm9FzOXbN7Y0\"",
    "mtime": "2026-11-01T06:39:55.027Z",
    "size": 11405,
    "path": "../public/imgs/flight/airlines/XM.png"
  },
  "/imgs/flight/airlines/XP.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:55.027Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/XP.png"
  },
  "/imgs/flight/airlines/XQ.png": {
    "type": "image/png",
    "etag": "\"3a31-jg7SiyBBOizeFOsgI+CfBfIVtSQ\"",
    "mtime": "2026-11-01T06:39:55.028Z",
    "size": 14897,
    "path": "../public/imgs/flight/airlines/XQ.png"
  },
  "/imgs/flight/airlines/XY.png": {
    "type": "image/png",
    "etag": "\"13a8-B1GHlJ4yWW5Vg101nocDmISpKFU\"",
    "mtime": "2026-11-01T06:39:55.029Z",
    "size": 5032,
    "path": "../public/imgs/flight/airlines/XY.png"
  },
  "/imgs/flight/airlines/Y0.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:55.030Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/Y0.png"
  },
  "/imgs/flight/airlines/Y4.png": {
    "type": "image/png",
    "etag": "\"105d-cxGxeWGBPKbLbH1BT+uz5JvtY4g\"",
    "mtime": "2026-11-01T06:39:55.030Z",
    "size": 4189,
    "path": "../public/imgs/flight/airlines/Y4.png"
  },
  "/imgs/flight/airlines/Y5.png": {
    "type": "image/png",
    "etag": "\"1311-G8vbxci7rLukiSbG79eWjoqd95o\"",
    "mtime": "2026-11-01T06:39:55.031Z",
    "size": 4881,
    "path": "../public/imgs/flight/airlines/Y5.png"
  },
  "/imgs/flight/airlines/Y7.png": {
    "type": "image/png",
    "etag": "\"f3e-ev21J4yrtgTeJOxPABdbybk4X3I\"",
    "mtime": "2026-11-01T06:39:55.032Z",
    "size": 3902,
    "path": "../public/imgs/flight/airlines/Y7.png"
  },
  "/imgs/flight/airlines/Y8.png": {
    "type": "image/png",
    "etag": "\"834-VIdpPhtQPFTyYC9r19XZpZGK7/4\"",
    "mtime": "2026-11-01T06:39:55.033Z",
    "size": 2100,
    "path": "../public/imgs/flight/airlines/Y8.png"
  },
  "/imgs/flight/airlines/Y9.png": {
    "type": "image/png",
    "etag": "\"10bf-owX3VLwUhXUNtu13ci9KiQ9hOl8\"",
    "mtime": "2026-11-01T06:39:55.034Z",
    "size": 4287,
    "path": "../public/imgs/flight/airlines/Y9.png"
  },
  "/imgs/flight/airlines/YC.png": {
    "type": "image/png",
    "etag": "\"e52-L7dvAsQiLYlfb8FAyAlXaAhRms4\"",
    "mtime": "2026-11-01T06:39:55.035Z",
    "size": 3666,
    "path": "../public/imgs/flight/airlines/YC.png"
  },
  "/imgs/flight/airlines/yazdair.png": {
    "type": "image/png",
    "etag": "\"fa5e-7HcVKQ5WLnHDJTNBpQ/IINFx4zA\"",
    "mtime": "2026-07-13T06:00:39.848Z",
    "size": 64094,
    "path": "../public/imgs/flight/airlines/yazdair.png"
  },
  "/imgs/flight/airlines/YD.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:55.035Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/YD.png"
  },
  "/imgs/flight/airlines/YK.png": {
    "type": "image/png",
    "etag": "\"43c-K0Mzyvv1zTRv7BGchTZ7GxLZy+g\"",
    "mtime": "2026-11-01T06:39:55.036Z",
    "size": 1084,
    "path": "../public/imgs/flight/airlines/YK.png"
  },
  "/imgs/flight/airlines/YL.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:55.037Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/YL.png"
  },
  "/imgs/flight/airlines/YS.png": {
    "type": "image/png",
    "etag": "\"fba-FnD/50oY5ubWeSBM4ykbNN2yzN0\"",
    "mtime": "2026-11-01T06:39:55.037Z",
    "size": 4026,
    "path": "../public/imgs/flight/airlines/YS.png"
  },
  "/imgs/flight/airlines/YT.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:55.038Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/YT.png"
  },
  "/imgs/flight/airlines/YU.png": {
    "type": "image/png",
    "etag": "\"8ff-Xr8B4HB0/wfjgp2NcHkYs3OaTM4\"",
    "mtime": "2026-11-01T06:39:55.039Z",
    "size": 2303,
    "path": "../public/imgs/flight/airlines/YU.png"
  },
  "/imgs/flight/airlines/YV.png": {
    "type": "image/png",
    "etag": "\"fd1-2dkb51rJomRTsAh2G52Y97ZydKs\"",
    "mtime": "2026-11-01T06:39:55.048Z",
    "size": 4049,
    "path": "../public/imgs/flight/airlines/YV.png"
  },
  "/imgs/flight/airlines/YX.png": {
    "type": "image/png",
    "etag": "\"1bf3-ShYmkfXgONkwQ7EPllzsEqJeKU4\"",
    "mtime": "2026-11-01T06:39:55.050Z",
    "size": 7155,
    "path": "../public/imgs/flight/airlines/YX.png"
  },
  "/imgs/flight/airlines/YW.png": {
    "type": "image/png",
    "etag": "\"e17-R6pk/qsqzdzH8UjzAYuh7HX9KpQ\"",
    "mtime": "2026-11-01T06:39:55.049Z",
    "size": 3607,
    "path": "../public/imgs/flight/airlines/YW.png"
  },
  "/imgs/flight/airlines/Z2.png": {
    "type": "image/png",
    "etag": "\"1b28-Lharq+E7hvu1F+gXmDhR1xQ4chI\"",
    "mtime": "2026-11-01T06:39:55.050Z",
    "size": 6952,
    "path": "../public/imgs/flight/airlines/Z2.png"
  },
  "/imgs/flight/airlines/Z4.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:55.051Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/Z4.png"
  },
  "/imgs/flight/airlines/Z3.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:55.051Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/Z3.png"
  },
  "/imgs/flight/airlines/Z8.png": {
    "type": "image/png",
    "etag": "\"f3b-rrjRcXkyMTZ4bhG0ZYKdviCvkeY\"",
    "mtime": "2026-11-01T06:39:55.054Z",
    "size": 3899,
    "path": "../public/imgs/flight/airlines/Z8.png"
  },
  "/imgs/flight/airlines/Z5.png": {
    "type": "image/png",
    "etag": "\"289b-eGUbmscW3aE1xoUNa0cithzZfBA\"",
    "mtime": "2026-11-01T06:39:55.052Z",
    "size": 10395,
    "path": "../public/imgs/flight/airlines/Z5.png"
  },
  "/imgs/flight/airlines/Z6.png": {
    "type": "image/png",
    "etag": "\"bb2-r2x0jOC53qu90ftOS8KUOMNWBF0\"",
    "mtime": "2026-11-01T06:39:55.053Z",
    "size": 2994,
    "path": "../public/imgs/flight/airlines/Z6.png"
  },
  "/imgs/flight/airlines/ZA.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:55.054Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/ZA.png"
  },
  "/imgs/flight/airlines/zagros.png": {
    "type": "image/png",
    "etag": "\"f41c-I1MB7by82s4c7sZJ7vjcm8NsLes\"",
    "mtime": "2026-07-13T06:00:39.849Z",
    "size": 62492,
    "path": "../public/imgs/flight/airlines/zagros.png"
  },
  "/imgs/flight/airlines/ZE.png": {
    "type": "image/png",
    "etag": "\"2986-YU97aC2Zm5kSHc+G6ZtVxRy2WvI\"",
    "mtime": "2026-11-01T06:39:55.056Z",
    "size": 10630,
    "path": "../public/imgs/flight/airlines/ZE.png"
  },
  "/imgs/flight/airlines/ZB.png": {
    "type": "image/png",
    "etag": "\"804-MrM5/kgjRJdtamHAMN9BrXs5lE4\"",
    "mtime": "2026-11-01T06:39:55.055Z",
    "size": 2052,
    "path": "../public/imgs/flight/airlines/ZB.png"
  },
  "/imgs/flight/airlines/ZH.png": {
    "type": "image/png",
    "etag": "\"b9b-BbTBPvQl/qbAnrkSgjmVPRfO0uk\"",
    "mtime": "2026-11-01T06:39:55.057Z",
    "size": 2971,
    "path": "../public/imgs/flight/airlines/ZH.png"
  },
  "/imgs/flight/airlines/ZI.png": {
    "type": "image/png",
    "etag": "\"2583-OmdtngnCGzBqXEPr1D+KCJaWTGs\"",
    "mtime": "2026-11-01T06:39:55.058Z",
    "size": 9603,
    "path": "../public/imgs/flight/airlines/ZI.png"
  },
  "/imgs/flight/airlines/ZK.png": {
    "type": "image/png",
    "etag": "\"2c08-E1vgb5ck5EVaNvMsMnYh5OycAu4\"",
    "mtime": "2026-11-01T06:39:55.059Z",
    "size": 11272,
    "path": "../public/imgs/flight/airlines/ZK.png"
  },
  "/imgs/flight/airlines/ZV.png": {
    "type": "image/png",
    "etag": "\"bc1-Dgv6p7ZAwbUaz6J6PZ65Oaa+SgM\"",
    "mtime": "2026-11-01T06:39:55.061Z",
    "size": 3009,
    "path": "../public/imgs/flight/airlines/ZV.png"
  },
  "/imgs/flight/airlines/ZL.png": {
    "type": "image/png",
    "etag": "\"c9b-sQSyDXiquahOEebCUR6kU37mZ5g\"",
    "mtime": "2026-11-01T06:39:55.060Z",
    "size": 3227,
    "path": "../public/imgs/flight/airlines/ZL.png"
  },
  "/imgs/flight/airlines/ZY.png": {
    "type": "image/png",
    "etag": "\"1d01-Wi8J6j5w2GuMXqd82U9TIaWZmIE\"",
    "mtime": "2026-11-01T06:39:55.062Z",
    "size": 7425,
    "path": "../public/imgs/flight/airlines/ZY.png"
  },
  "/imgs/flight/airlines/ZU.png": {
    "type": "image/png",
    "etag": "\"590-c8XHbsoSgWUwwJXrfzgrlCBhh/Q\"",
    "mtime": "2026-11-01T06:39:55.060Z",
    "size": 1424,
    "path": "../public/imgs/flight/airlines/ZU.png"
  },
  "/imgs/flight/airlines/لوگوی_امارات.jpg": {
    "type": "image/jpeg",
    "etag": "\"95bd-Dy400Cb8dWaJFrHVYBTx5pfjpoA\"",
    "mtime": "2026-07-13T06:00:39.850Z",
    "size": 38333,
    "path": "../public/imgs/flight/airlines/لوگوی_امارات.jpg"
  },
  "/imgs/flight/airlines/لوگوی_ایر1.png": {
    "type": "image/png",
    "etag": "\"87c7-LM6uKObJoGdWLvt2yUD+Ga0J8/k\"",
    "mtime": "2026-07-13T06:00:39.851Z",
    "size": 34759,
    "path": "../public/imgs/flight/airlines/لوگوی_ایر1.png"
  },
  "/imgs/flight/airlines/لوگوی_قطر.png": {
    "type": "image/png",
    "etag": "\"35fd-yS3Lu8wOFKaLq3UfyBmRSm7rQy0\"",
    "mtime": "2026-07-13T06:00:39.852Z",
    "size": 13821,
    "path": "../public/imgs/flight/airlines/لوگوی_قطر.png"
  },
  "/imgs/tours/DomesticInternationalTours/estanboul.jpg": {
    "type": "image/jpeg",
    "etag": "\"36dad-pTzIpu3U8AD5gIR3fihU8Xei8Qo\"",
    "mtime": "2026-09-05T08:34:31.034Z",
    "size": 224685,
    "path": "../public/imgs/tours/DomesticInternationalTours/estanboul.jpg"
  },
  "/imgs/tours/DomesticInternationalTours/kashan.jpg": {
    "type": "image/jpeg",
    "etag": "\"269d8-9TPuBuwycfB1RJPcQrDQvBTRGR0\"",
    "mtime": "2026-09-05T08:34:31.035Z",
    "size": 158168,
    "path": "../public/imgs/tours/DomesticInternationalTours/kashan.jpg"
  },
  "/imgs/tours/DomesticInternationalTours/mashad.jpg": {
    "type": "image/jpeg",
    "etag": "\"1e290-GxkdvKviKq8t7B7CflIfznwSrK0\"",
    "mtime": "2026-09-05T08:34:31.038Z",
    "size": 123536,
    "path": "../public/imgs/tours/DomesticInternationalTours/mashad.jpg"
  },
  "/imgs/tours/DomesticInternationalTours/shiraz.jpg": {
    "type": "image/jpeg",
    "etag": "\"13d8f-Dk+kospWZWgfg1piDT0353W4neY\"",
    "mtime": "2026-09-05T08:34:31.040Z",
    "size": 81295,
    "path": "../public/imgs/tours/DomesticInternationalTours/shiraz.jpg"
  },
  "/imgs/hotel/Menu/2.jpg": {
    "type": "image/jpeg",
    "etag": "\"3d07-eD5yu63DayIux7mwWF8bQqYRtWU\"",
    "mtime": "2026-11-09T06:58:04.731Z",
    "size": 15623,
    "path": "../public/imgs/hotel/Menu/2.jpg"
  },
  "/imgs/hotel/Menu/3.jpg": {
    "type": "image/jpeg",
    "etag": "\"485d-QvZ2z57n9V2ea2aAkzWX4jyO8ms\"",
    "mtime": "2026-11-09T06:58:04.732Z",
    "size": 18525,
    "path": "../public/imgs/hotel/Menu/3.jpg"
  },
  "/imgs/hotel/Menu/4.jpg": {
    "type": "image/jpeg",
    "etag": "\"3f98-QA1FMtNLz/BKXqGjtWQBL1YxtcM\"",
    "mtime": "2026-11-09T06:58:04.733Z",
    "size": 16280,
    "path": "../public/imgs/hotel/Menu/4.jpg"
  },
  "/imgs/hotel/Menu/5.jpg": {
    "type": "image/jpeg",
    "etag": "\"4556-9hKBkD38CYa+iS5qLwqim/D3BGc\"",
    "mtime": "2026-11-09T06:58:04.733Z",
    "size": 17750,
    "path": "../public/imgs/hotel/Menu/5.jpg"
  },
  "/imgs/hotel/Menu/background.webp": {
    "type": "image/webp",
    "etag": "\"c714-HXt0cvq2Cx9uz+77hpW09SGmha8\"",
    "mtime": "2026-11-09T06:58:04.737Z",
    "size": 50964,
    "path": "../public/imgs/hotel/Menu/background.webp"
  },
  "/imgs/hotel/Menu/bale.png": {
    "type": "image/png",
    "etag": "\"cd03-PuW3Vh/Z1Ip0P//uBAYzB1/F0ok\"",
    "mtime": "2026-11-09T06:58:04.738Z",
    "size": 52483,
    "path": "../public/imgs/hotel/Menu/bale.png"
  },
  "/imgs/hotel/Menu/logo.png": {
    "type": "image/png",
    "etag": "\"15852-W5muTGLpwPMsqxhj9HQQgforz5k\"",
    "mtime": "2026-11-09T06:58:04.739Z",
    "size": 88146,
    "path": "../public/imgs/hotel/Menu/logo.png"
  },
  "/imgs/hotel/Menu/rubika.jpg": {
    "type": "image/jpeg",
    "etag": "\"4b64-jrh2ePMRK2pg/hBDzgKUcQpI8q4\"",
    "mtime": "2026-11-09T06:58:04.740Z",
    "size": 19300,
    "path": "../public/imgs/hotel/Menu/rubika.jpg"
  },
  "/imgs/hotel/Menu/rubika.png": {
    "type": "image/png",
    "etag": "\"15fb3-ynPA3AVJVa70wZ0cSDAGnlhtat4\"",
    "mtime": "2026-11-09T06:58:04.741Z",
    "size": 90035,
    "path": "../public/imgs/hotel/Menu/rubika.png"
  },
  "/imgs/tours/NatureTours/10.jpg": {
    "type": "image/jpeg",
    "etag": "\"6c5f8-s3XQkyCdFfLYaQA8w03NtRRTWpo\"",
    "mtime": "2026-09-05T08:34:31.045Z",
    "size": 443896,
    "path": "../public/imgs/tours/NatureTours/10.jpg"
  },
  "/imgs/tours/NatureTours/10mobile (2).jpg": {
    "type": "image/jpeg",
    "etag": "\"1c171-0sE39zrEY0pY7kujroYyCMuvO2k\"",
    "mtime": "2026-09-05T08:34:31.046Z",
    "size": 115057,
    "path": "../public/imgs/tours/NatureTours/10mobile (2).jpg"
  },
  "/imgs/tours/NatureTours/1mobile (2).jpg": {
    "type": "image/jpeg",
    "etag": "\"161e4-2UAA8y+QCeEHlRJe/Bocg0QX1tM\"",
    "mtime": "2026-09-05T08:34:31.052Z",
    "size": 90596,
    "path": "../public/imgs/tours/NatureTours/1mobile (2).jpg"
  },
  "/imgs/tours/NatureTours/2.jpg": {
    "type": "image/jpeg",
    "etag": "\"54748-Vlzr4bC1CbXec0EjsbZgtpxd91Q\"",
    "mtime": "2026-09-05T08:34:31.054Z",
    "size": 345928,
    "path": "../public/imgs/tours/NatureTours/2.jpg"
  },
  "/imgs/tours/NatureTours/2mobile (2).jpg": {
    "type": "image/jpeg",
    "etag": "\"225b9-5p8hcRABesMKwbdMWHm0/7IXmjg\"",
    "mtime": "2026-09-05T08:34:31.055Z",
    "size": 140729,
    "path": "../public/imgs/tours/NatureTours/2mobile (2).jpg"
  },
  "/imgs/tours/NatureTours/3.jpg": {
    "type": "image/jpeg",
    "etag": "\"6b98b-pZT/s6BlZ/lnU5OtIsMbUHpojGY\"",
    "mtime": "2026-09-05T08:34:31.058Z",
    "size": 440715,
    "path": "../public/imgs/tours/NatureTours/3.jpg"
  },
  "/imgs/tours/NatureTours/3mobile (2).jpg": {
    "type": "image/jpeg",
    "etag": "\"1f8bc-OW9LRWexsMwCQqBCp1wq14yoq5U\"",
    "mtime": "2026-09-05T08:34:31.059Z",
    "size": 129212,
    "path": "../public/imgs/tours/NatureTours/3mobile (2).jpg"
  },
  "/imgs/tours/NatureTours/11.jpg": {
    "type": "image/jpeg",
    "etag": "\"aa9db-QIgx+ZQHkJIeQLv9dnJULIS1YJo\"",
    "mtime": "2026-09-05T08:34:31.049Z",
    "size": 698843,
    "path": "../public/imgs/tours/NatureTours/11.jpg"
  },
  "/imgs/tours/NatureTours/4.jpg": {
    "type": "image/jpeg",
    "etag": "\"4c33c-LS7EnCn76wWSThxOHjrVVyBz+qI\"",
    "mtime": "2026-09-05T08:34:31.061Z",
    "size": 312124,
    "path": "../public/imgs/tours/NatureTours/4.jpg"
  },
  "/imgs/tours/NatureTours/4mobile.jpg": {
    "type": "image/jpeg",
    "etag": "\"22528-/8dK0ND3Zda25bQ80O1bvR96hko\"",
    "mtime": "2026-09-05T08:34:31.062Z",
    "size": 140584,
    "path": "../public/imgs/tours/NatureTours/4mobile.jpg"
  },
  "/imgs/tours/NatureTours/5.jpg": {
    "type": "image/jpeg",
    "etag": "\"3902b-XjdXoCXKOm6Gx09AJE2ldNvaU0o\"",
    "mtime": "2026-09-05T08:34:31.063Z",
    "size": 233515,
    "path": "../public/imgs/tours/NatureTours/5.jpg"
  },
  "/imgs/tours/NatureTours/5mobile.jpg": {
    "type": "image/jpeg",
    "etag": "\"f325-hEb/NClbLYsNbzAj9WvyBAiqwbg\"",
    "mtime": "2026-09-05T08:34:31.064Z",
    "size": 62245,
    "path": "../public/imgs/tours/NatureTours/5mobile.jpg"
  },
  "/imgs/tours/NatureTours/6.jpg": {
    "type": "image/jpeg",
    "etag": "\"36d06-dp8tTO9jzy/UZAgLIaI9oimgGZE\"",
    "mtime": "2026-09-05T08:34:31.066Z",
    "size": 224518,
    "path": "../public/imgs/tours/NatureTours/6.jpg"
  },
  "/imgs/tours/NatureTours/6mobile.jpg": {
    "type": "image/jpeg",
    "etag": "\"157aa-pUoNGrJ3vcD9+QsITjveLahCQes\"",
    "mtime": "2026-09-05T08:34:31.068Z",
    "size": 87978,
    "path": "../public/imgs/tours/NatureTours/6mobile.jpg"
  },
  "/imgs/tours/NatureTours/7.jpg": {
    "type": "image/jpeg",
    "etag": "\"4f0e1-jLJQ35e95byHxhSHH2xvsXOLkbI\"",
    "mtime": "2026-09-05T08:34:31.070Z",
    "size": 323809,
    "path": "../public/imgs/tours/NatureTours/7.jpg"
  },
  "/imgs/tours/NatureTours/7mobile.jpg": {
    "type": "image/jpeg",
    "etag": "\"1fc39-feG5jf6F2H6JSLvbVBOZaMp4ndE\"",
    "mtime": "2026-09-05T08:34:31.071Z",
    "size": 130105,
    "path": "../public/imgs/tours/NatureTours/7mobile.jpg"
  },
  "/imgs/tours/NatureTours/8mobile.jpg": {
    "type": "image/jpeg",
    "etag": "\"237d9-ibTVP6rdFNGWz/QaKscKG30232w\"",
    "mtime": "2026-09-05T08:34:31.075Z",
    "size": 145369,
    "path": "../public/imgs/tours/NatureTours/8mobile.jpg"
  },
  "/imgs/tours/NatureTours/8.jpg": {
    "type": "image/jpeg",
    "etag": "\"51b2b-koVwyMdDvFOdwIiDBmmzELzNzwA\"",
    "mtime": "2026-09-05T08:34:31.073Z",
    "size": 334635,
    "path": "../public/imgs/tours/NatureTours/8.jpg"
  },
  "/imgs/tours/NatureTours/9mobile (2).jpg": {
    "type": "image/jpeg",
    "etag": "\"1f17e-Sf6sDv/G7jPXF+hqxf9fKiduRX8\"",
    "mtime": "2026-09-05T08:34:31.078Z",
    "size": 127358,
    "path": "../public/imgs/tours/NatureTours/9mobile (2).jpg"
  },
  "/imgs/tours/NatureTours/9.jpg": {
    "type": "image/jpeg",
    "etag": "\"54aee-rOq4TabpvIOOQ67aWxjdY4GSUrM\"",
    "mtime": "2026-09-05T08:34:31.077Z",
    "size": 346862,
    "path": "../public/imgs/tours/NatureTours/9.jpg"
  },
  "/imgs/tours/NatureTours/9mobile.jpg": {
    "type": "image/jpeg",
    "etag": "\"20cef-kwRyot/rcDvGS3SuBoru6XB4J3U\"",
    "mtime": "2026-09-05T08:34:31.079Z",
    "size": 134383,
    "path": "../public/imgs/tours/NatureTours/9mobile.jpg"
  },
  "/imgs/tours/NatureTours/baraghan.jpg": {
    "type": "image/jpeg",
    "etag": "\"328da-hMnJuXVvCJB+uSjvYm6ruNFtFB8\"",
    "mtime": "2026-09-05T08:34:31.081Z",
    "size": 207066,
    "path": "../public/imgs/tours/NatureTours/baraghan.jpg"
  },
  "/imgs/tours/NatureTours/beliran.jpg": {
    "type": "image/jpeg",
    "etag": "\"3d4ea-lMgttGtiF/Ws4P0spj77pYlY+w8\"",
    "mtime": "2026-09-05T08:34:31.082Z",
    "size": 251114,
    "path": "../public/imgs/tours/NatureTours/beliran.jpg"
  },
  "/imgs/tours/NatureTours/harande.jpg": {
    "type": "image/jpeg",
    "etag": "\"2da17-oZXFtA7yJV1UO75lVhWeTWmzGsk\"",
    "mtime": "2026-09-05T08:34:31.084Z",
    "size": 186903,
    "path": "../public/imgs/tours/NatureTours/harande.jpg"
  },
  "/imgs/tours/NatureTours/header شهرستانک.jpg": {
    "type": "image/jpeg",
    "etag": "\"62a82-xeDnpJ7q9WsMnmrMdRPzKCkkzaE\"",
    "mtime": "2026-11-01T06:39:55.340Z",
    "size": 404098,
    "path": "../public/imgs/tours/NatureTours/header شهرستانک.jpg"
  },
  "/imgs/tours/NatureTours/sahrestanak.jpg": {
    "type": "image/jpeg",
    "etag": "\"27b5e-U7xXTHcyAEpLyR1mQxvH590l5Yo\"",
    "mtime": "2026-09-05T08:34:31.085Z",
    "size": 162654,
    "path": "../public/imgs/tours/NatureTours/sahrestanak.jpg"
  },
  "/imgs/tours/NatureTours/کاشان مبایل.jpg": {
    "type": "image/jpeg",
    "etag": "\"19af6-5Zg0BLq15xR2J0MgFpV27Vz/jEc\"",
    "mtime": "2026-09-05T08:34:31.086Z",
    "size": 105206,
    "path": "../public/imgs/tours/NatureTours/کاشان مبایل.jpg"
  },
  "/_nuxt/builds/meta/a2268c73-ad23-416c-b458-06b8d2bdbc36.json": {
    "type": "application/json",
    "etag": "\"58-pbLD4WyUIlKXs1cOEpwZThTX/UQ\"",
    "mtime": "2026-11-09T11:13:55.496Z",
    "size": 88,
    "path": "../public/_nuxt/builds/meta/a2268c73-ad23-416c-b458-06b8d2bdbc36.json"
  },
  "/imgs/hotel/Menu/Slider/pro1.jpg": {
    "type": "image/jpeg",
    "etag": "\"71f7-pOIbqjH7dv3jgM2WHu6MdAzexFQ\"",
    "mtime": "2026-11-09T06:58:04.734Z",
    "size": 29175,
    "path": "../public/imgs/hotel/Menu/Slider/pro1.jpg"
  },
  "/imgs/hotel/Menu/1.jpg": {
    "type": "image/jpeg",
    "etag": "\"36b8ee-BFHmLdHI/u3fjCnkmQ82y5WqXG8\"",
    "mtime": "2026-11-09T06:58:04.730Z",
    "size": 3586286,
    "path": "../public/imgs/hotel/Menu/1.jpg"
  },
  "/imgs/hotel/Menu/Slider/pro2.jpg": {
    "type": "image/jpeg",
    "etag": "\"ac9c-YrluBJowpcs703OaAiAJ+m0QxfY\"",
    "mtime": "2026-11-09T06:58:04.735Z",
    "size": 44188,
    "path": "../public/imgs/hotel/Menu/Slider/pro2.jpg"
  },
  "/imgs/hotel/Menu/Slider/pro3.jpg": {
    "type": "image/jpeg",
    "etag": "\"ab30-2xQ9SVG8F9xJNayuT6fNaTPKvRg\"",
    "mtime": "2026-11-09T06:58:04.736Z",
    "size": 43824,
    "path": "../public/imgs/hotel/Menu/Slider/pro3.jpg"
  },
  "/imgs/tours/NatureTours/autumn/10.jpg": {
    "type": "image/jpeg",
    "etag": "\"6c5f8-s3XQkyCdFfLYaQA8w03NtRRTWpo\"",
    "mtime": "2026-11-01T06:39:55.148Z",
    "size": 443896,
    "path": "../public/imgs/tours/NatureTours/autumn/10.jpg"
  },
  "/imgs/tours/NatureTours/autumn/10mobile (2).jpg": {
    "type": "image/jpeg",
    "etag": "\"1c171-0sE39zrEY0pY7kujroYyCMuvO2k\"",
    "mtime": "2026-11-01T06:39:55.150Z",
    "size": 115057,
    "path": "../public/imgs/tours/NatureTours/autumn/10mobile (2).jpg"
  },
  "/imgs/tours/NatureTours/autumn/9.jpg": {
    "type": "image/jpeg",
    "etag": "\"54aee-rOq4TabpvIOOQ67aWxjdY4GSUrM\"",
    "mtime": "2026-11-01T06:39:55.155Z",
    "size": 346862,
    "path": "../public/imgs/tours/NatureTours/autumn/9.jpg"
  },
  "/imgs/tours/NatureTours/autumn/9mobile (2).jpg": {
    "type": "image/jpeg",
    "etag": "\"1f17e-Sf6sDv/G7jPXF+hqxf9fKiduRX8\"",
    "mtime": "2026-11-01T06:39:55.158Z",
    "size": 127358,
    "path": "../public/imgs/tours/NatureTours/autumn/9mobile (2).jpg"
  },
  "/imgs/tours/NatureTours/autumn/9mobile.jpg": {
    "type": "image/jpeg",
    "etag": "\"20cef-kwRyot/rcDvGS3SuBoru6XB4J3U\"",
    "mtime": "2026-11-01T06:39:55.160Z",
    "size": 134383,
    "path": "../public/imgs/tours/NatureTours/autumn/9mobile.jpg"
  },
  "/imgs/tours/NatureTours/autumn/header زنجان.jpg": {
    "type": "image/jpeg",
    "etag": "\"8380a-7tM0ddXs34quSglggJEvyNNjNcs\"",
    "mtime": "2026-11-01T06:39:55.174Z",
    "size": 538634,
    "path": "../public/imgs/tours/NatureTours/autumn/header زنجان.jpg"
  },
  "/imgs/tours/NatureTours/autumn/header بلیران.jpg": {
    "type": "image/jpeg",
    "etag": "\"b8c7b-U7lUpaAe/1zHVOOZYRqV/V8KcaY\"",
    "mtime": "2026-11-01T06:39:55.167Z",
    "size": 756859,
    "path": "../public/imgs/tours/NatureTours/autumn/header بلیران.jpg"
  },
  "/imgs/tours/NatureTours/autumn/headerبرغان.jpg": {
    "type": "image/jpeg",
    "etag": "\"ab701-zgHvoi+Ewhm6ITvNi7+HaUw1od4\"",
    "mtime": "2026-11-01T06:39:55.182Z",
    "size": 702209,
    "path": "../public/imgs/tours/NatureTours/autumn/headerبرغان.jpg"
  },
  "/imgs/tours/NatureTours/autumn/بنر اصلی.jpg": {
    "type": "image/jpeg",
    "etag": "\"76116-FHBxSkSCkIkPCBQLFW904AeJtOI\"",
    "mtime": "2026-11-01T06:39:55.269Z",
    "size": 483606,
    "path": "../public/imgs/tours/NatureTours/autumn/بنر اصلی.jpg"
  },
  "/imgs/tours/NatureTours/autumn/headerشهرستانک.jpg": {
    "type": "image/jpeg",
    "etag": "\"bf6d0-S9zc8ljTHa9ZKsil5neAieOMCus\"",
    "mtime": "2026-11-01T06:39:55.190Z",
    "size": 784080,
    "path": "../public/imgs/tours/NatureTours/autumn/headerشهرستانک.jpg"
  },
  "/imgs/tours/NatureTours/autumn/headerقزوین.jpg": {
    "type": "image/jpeg",
    "etag": "\"a6602-yv7FeoZqlhRUrHNWwOV3zCHq1nw\"",
    "mtime": "2026-11-01T06:39:55.198Z",
    "size": 681474,
    "path": "../public/imgs/tours/NatureTours/autumn/headerقزوین.jpg"
  },
  "/imgs/tours/NatureTours/autumn/headerهرانده.jpg": {
    "type": "image/jpeg",
    "etag": "\"ac679-pinWZJ1YPfiDfPtj4cbApHNSrDk\"",
    "mtime": "2026-11-01T06:39:55.217Z",
    "size": 706169,
    "path": "../public/imgs/tours/NatureTours/autumn/headerهرانده.jpg"
  },
  "/imgs/tours/NatureTours/autumn/main page- برغان.jpg": {
    "type": "image/jpeg",
    "etag": "\"e88a3-TLIpY99U9asIqCW2dz1J2oepeg4\"",
    "mtime": "2026-11-01T06:39:55.226Z",
    "size": 952483,
    "path": "../public/imgs/tours/NatureTours/autumn/main page- برغان.jpg"
  },
  "/imgs/tours/NatureTours/autumn/main page- شهرستانک.jpg": {
    "type": "image/jpeg",
    "etag": "\"8df63-cqAHarXzyWijBoifbzeC47eYHII\"",
    "mtime": "2026-11-01T06:39:55.250Z",
    "size": 581475,
    "path": "../public/imgs/tours/NatureTours/autumn/main page- شهرستانک.jpg"
  },
  "/imgs/tours/NatureTours/autumn/main page- بلیران.jpg": {
    "type": "image/jpeg",
    "etag": "\"de0f4-xVare64mGJUVrcWwiRkheNJiURE\"",
    "mtime": "2026-11-01T06:39:55.235Z",
    "size": 909556,
    "path": "../public/imgs/tours/NatureTours/autumn/main page- بلیران.jpg"
  },
  "/imgs/tours/NatureTours/autumn/main page- زنجان.jpg": {
    "type": "image/jpeg",
    "etag": "\"be431-N2JEVfmyDuL7sTj8CI9gX9DtkjA\"",
    "mtime": "2026-11-01T06:39:55.243Z",
    "size": 779313,
    "path": "../public/imgs/tours/NatureTours/autumn/main page- زنجان.jpg"
  },
  "/imgs/tours/NatureTours/autumn/main page- قزوین.jpg": {
    "type": "image/jpeg",
    "etag": "\"cf9b8-uSIF7/Lwsi9ZG4kNAd2tJJoqiV4\"",
    "mtime": "2026-11-01T06:39:55.258Z",
    "size": 850360,
    "path": "../public/imgs/tours/NatureTours/autumn/main page- قزوین.jpg"
  },
  "/imgs/tours/NatureTours/autumn/main page- هرانده.jpg": {
    "type": "image/jpeg",
    "etag": "\"b8999-0m1jEGo4bTNUw6a1hCEJej05Qho\"",
    "mtime": "2026-11-01T06:39:55.267Z",
    "size": 756121,
    "path": "../public/imgs/tours/NatureTours/autumn/main page- هرانده.jpg"
  },
  "/imgs/tours/NatureTours/autumn/مبایل بیلران.jpg": {
    "type": "image/jpeg",
    "etag": "\"23e3d-uZs3bFBOYVpKT02GB1uwhxn5aFk\"",
    "mtime": "2026-11-01T06:39:55.311Z",
    "size": 147005,
    "path": "../public/imgs/tours/NatureTours/autumn/مبایل بیلران.jpg"
  },
  "/imgs/tours/NatureTours/autumn/مبایل زنجان.jpg": {
    "type": "image/jpeg",
    "etag": "\"2aec8-dInSIUDaPb4unnmXb4c0p4gmlZo\"",
    "mtime": "2026-11-01T06:39:55.314Z",
    "size": 175816,
    "path": "../public/imgs/tours/NatureTours/autumn/مبایل زنجان.jpg"
  },
  "/imgs/tours/NatureTours/autumn/مبایل شهرستانک.jpg": {
    "type": "image/jpeg",
    "etag": "\"1f59c-95WSMW14/jToFByDqTYKYbaH7Dg\"",
    "mtime": "2026-11-01T06:39:55.316Z",
    "size": 128412,
    "path": "../public/imgs/tours/NatureTours/autumn/مبایل شهرستانک.jpg"
  },
  "/imgs/tours/NatureTours/autumn/مبایل قزوین.jpg": {
    "type": "image/jpeg",
    "etag": "\"240aa-MwVqhEdDyon1izOx3rd7uXXEErY\"",
    "mtime": "2026-11-01T06:39:55.319Z",
    "size": 147626,
    "path": "../public/imgs/tours/NatureTours/autumn/مبایل قزوین.jpg"
  },
  "/imgs/tours/NatureTours/autumn/مبایل هرانده.jpg": {
    "type": "image/jpeg",
    "etag": "\"226e3-69Y/2GxMVZZf8+4npOmhYn8AN1s\"",
    "mtime": "2026-11-01T06:39:55.322Z",
    "size": 141027,
    "path": "../public/imgs/tours/NatureTours/autumn/مبایل هرانده.jpg"
  },
  "/imgs/tours/NatureTours/autumn/مبایل-برغان.jpg": {
    "type": "image/jpeg",
    "etag": "\"29e64-RGjQZyT4c2V9YF8mZMnk1LFTz5o\"",
    "mtime": "2026-11-01T06:39:55.337Z",
    "size": 171620,
    "path": "../public/imgs/tours/NatureTours/autumn/مبایل-برغان.jpg"
  },
  "/imgs/tours/NatureTours/spring/1.jpg": {
    "type": "image/jpeg",
    "etag": "\"62a82-xeDnpJ7q9WsMnmrMdRPzKCkkzaE\"",
    "mtime": "2026-11-01T06:39:55.342Z",
    "size": 404098,
    "path": "../public/imgs/tours/NatureTours/spring/1.jpg"
  },
  "/imgs/tours/NatureTours/spring/10.jpg": {
    "type": "image/jpeg",
    "etag": "\"6c5f8-s3XQkyCdFfLYaQA8w03NtRRTWpo\"",
    "mtime": "2026-11-01T06:39:55.345Z",
    "size": 443896,
    "path": "../public/imgs/tours/NatureTours/spring/10.jpg"
  },
  "/imgs/tours/NatureTours/spring/10mobile (2).jpg": {
    "type": "image/jpeg",
    "etag": "\"1c171-0sE39zrEY0pY7kujroYyCMuvO2k\"",
    "mtime": "2026-11-01T06:39:55.346Z",
    "size": 115057,
    "path": "../public/imgs/tours/NatureTours/spring/10mobile (2).jpg"
  },
  "/imgs/tours/NatureTours/spring/1mobile (2).jpg": {
    "type": "image/jpeg",
    "etag": "\"161e4-2UAA8y+QCeEHlRJe/Bocg0QX1tM\"",
    "mtime": "2026-11-01T06:39:55.366Z",
    "size": 90596,
    "path": "../public/imgs/tours/NatureTours/spring/1mobile (2).jpg"
  },
  "/imgs/tours/NatureTours/autumn/مبایل اصلی.jpg": {
    "type": "image/jpeg",
    "etag": "\"19c429-BPVFOWefPfc6+2FG1ENzaLRhm2Y\"",
    "mtime": "2026-11-01T06:39:55.287Z",
    "size": 1688617,
    "path": "../public/imgs/tours/NatureTours/autumn/مبایل اصلی.jpg"
  },
  "/imgs/tours/NatureTours/spring/2.jpg": {
    "type": "image/jpeg",
    "etag": "\"54748-Vlzr4bC1CbXec0EjsbZgtpxd91Q\"",
    "mtime": "2026-11-01T06:39:55.400Z",
    "size": 345928,
    "path": "../public/imgs/tours/NatureTours/spring/2.jpg"
  },
  "/imgs/tours/NatureTours/spring/11.jpg": {
    "type": "image/jpeg",
    "etag": "\"aa9db-QIgx+ZQHkJIeQLv9dnJULIS1YJo\"",
    "mtime": "2026-11-01T06:39:55.364Z",
    "size": 698843,
    "path": "../public/imgs/tours/NatureTours/spring/11.jpg"
  },
  "/imgs/tours/NatureTours/spring/2mobile (2).jpg": {
    "type": "image/jpeg",
    "etag": "\"225b9-5p8hcRABesMKwbdMWHm0/7IXmjg\"",
    "mtime": "2026-11-01T06:39:55.411Z",
    "size": 140729,
    "path": "../public/imgs/tours/NatureTours/spring/2mobile (2).jpg"
  },
  "/imgs/tours/NatureTours/spring/3.jpg": {
    "type": "image/jpeg",
    "etag": "\"6b98b-pZT/s6BlZ/lnU5OtIsMbUHpojGY\"",
    "mtime": "2026-11-01T06:39:55.416Z",
    "size": 440715,
    "path": "../public/imgs/tours/NatureTours/spring/3.jpg"
  },
  "/imgs/tours/NatureTours/spring/3mobile (2).jpg": {
    "type": "image/jpeg",
    "etag": "\"1f8bc-OW9LRWexsMwCQqBCp1wq14yoq5U\"",
    "mtime": "2026-11-01T06:39:55.419Z",
    "size": 129212,
    "path": "../public/imgs/tours/NatureTours/spring/3mobile (2).jpg"
  },
  "/imgs/tours/NatureTours/spring/4mobile.jpg": {
    "type": "image/jpeg",
    "etag": "\"22528-/8dK0ND3Zda25bQ80O1bvR96hko\"",
    "mtime": "2026-11-01T06:39:55.425Z",
    "size": 140584,
    "path": "../public/imgs/tours/NatureTours/spring/4mobile.jpg"
  },
  "/imgs/tours/NatureTours/spring/4.jpg": {
    "type": "image/jpeg",
    "etag": "\"4c33c-LS7EnCn76wWSThxOHjrVVyBz+qI\"",
    "mtime": "2026-11-01T06:39:55.423Z",
    "size": 312124,
    "path": "../public/imgs/tours/NatureTours/spring/4.jpg"
  },
  "/imgs/tours/NatureTours/spring/5.jpg": {
    "type": "image/jpeg",
    "etag": "\"3902b-XjdXoCXKOm6Gx09AJE2ldNvaU0o\"",
    "mtime": "2026-11-01T06:39:55.429Z",
    "size": 233515,
    "path": "../public/imgs/tours/NatureTours/spring/5.jpg"
  },
  "/imgs/tours/NatureTours/spring/5mobile.jpg": {
    "type": "image/jpeg",
    "etag": "\"f325-hEb/NClbLYsNbzAj9WvyBAiqwbg\"",
    "mtime": "2026-11-01T06:39:55.430Z",
    "size": 62245,
    "path": "../public/imgs/tours/NatureTours/spring/5mobile.jpg"
  },
  "/imgs/tours/NatureTours/spring/6mobile.jpg": {
    "type": "image/jpeg",
    "etag": "\"157aa-pUoNGrJ3vcD9+QsITjveLahCQes\"",
    "mtime": "2026-11-01T06:39:55.435Z",
    "size": 87978,
    "path": "../public/imgs/tours/NatureTours/spring/6mobile.jpg"
  },
  "/imgs/tours/NatureTours/spring/6.jpg": {
    "type": "image/jpeg",
    "etag": "\"36d06-dp8tTO9jzy/UZAgLIaI9oimgGZE\"",
    "mtime": "2026-11-01T06:39:55.433Z",
    "size": 224518,
    "path": "../public/imgs/tours/NatureTours/spring/6.jpg"
  },
  "/imgs/tours/NatureTours/spring/7.jpg": {
    "type": "image/jpeg",
    "etag": "\"4f0e1-jLJQ35e95byHxhSHH2xvsXOLkbI\"",
    "mtime": "2026-11-01T06:39:55.442Z",
    "size": 323809,
    "path": "../public/imgs/tours/NatureTours/spring/7.jpg"
  },
  "/imgs/tours/NatureTours/spring/7mobile.jpg": {
    "type": "image/jpeg",
    "etag": "\"1fc39-feG5jf6F2H6JSLvbVBOZaMp4ndE\"",
    "mtime": "2026-11-01T06:39:55.444Z",
    "size": 130105,
    "path": "../public/imgs/tours/NatureTours/spring/7mobile.jpg"
  },
  "/imgs/tours/NatureTours/spring/8.jpg": {
    "type": "image/jpeg",
    "etag": "\"51b2b-koVwyMdDvFOdwIiDBmmzELzNzwA\"",
    "mtime": "2026-11-01T06:39:55.449Z",
    "size": 334635,
    "path": "../public/imgs/tours/NatureTours/spring/8.jpg"
  },
  "/imgs/tours/NatureTours/spring/8mobile.jpg": {
    "type": "image/jpeg",
    "etag": "\"237d9-ibTVP6rdFNGWz/QaKscKG30232w\"",
    "mtime": "2026-11-01T06:39:55.451Z",
    "size": 145369,
    "path": "../public/imgs/tours/NatureTours/spring/8mobile.jpg"
  },
  "/imgs/tours/NatureTours/spring/9.jpg": {
    "type": "image/jpeg",
    "etag": "\"54aee-rOq4TabpvIOOQ67aWxjdY4GSUrM\"",
    "mtime": "2026-11-01T06:39:55.454Z",
    "size": 346862,
    "path": "../public/imgs/tours/NatureTours/spring/9.jpg"
  },
  "/imgs/tours/NatureTours/spring/9mobile (2).jpg": {
    "type": "image/jpeg",
    "etag": "\"1f17e-Sf6sDv/G7jPXF+hqxf9fKiduRX8\"",
    "mtime": "2026-11-01T06:39:55.454Z",
    "size": 127358,
    "path": "../public/imgs/tours/NatureTours/spring/9mobile (2).jpg"
  },
  "/imgs/tours/NatureTours/spring/9mobile.jpg": {
    "type": "image/jpeg",
    "etag": "\"20cef-kwRyot/rcDvGS3SuBoru6XB4J3U\"",
    "mtime": "2026-11-01T06:39:55.455Z",
    "size": 134383,
    "path": "../public/imgs/tours/NatureTours/spring/9mobile.jpg"
  },
  "/imgs/tours/NatureTours/spring/baraghan.jpg": {
    "type": "image/jpeg",
    "etag": "\"328da-hMnJuXVvCJB+uSjvYm6ruNFtFB8\"",
    "mtime": "2026-11-01T06:39:55.459Z",
    "size": 207066,
    "path": "../public/imgs/tours/NatureTours/spring/baraghan.jpg"
  },
  "/imgs/tours/NatureTours/spring/beliran.jpg": {
    "type": "image/jpeg",
    "etag": "\"3d4ea-lMgttGtiF/Ws4P0spj77pYlY+w8\"",
    "mtime": "2026-11-01T06:39:55.462Z",
    "size": 251114,
    "path": "../public/imgs/tours/NatureTours/spring/beliran.jpg"
  },
  "/imgs/tours/NatureTours/spring/harande.jpg": {
    "type": "image/jpeg",
    "etag": "\"2da17-oZXFtA7yJV1UO75lVhWeTWmzGsk\"",
    "mtime": "2026-11-01T06:39:55.465Z",
    "size": 186903,
    "path": "../public/imgs/tours/NatureTours/spring/harande.jpg"
  },
  "/imgs/tours/NatureTours/spring/sahrestanak.jpg": {
    "type": "image/jpeg",
    "etag": "\"27b5e-U7xXTHcyAEpLyR1mQxvH590l5Yo\"",
    "mtime": "2026-11-01T06:39:55.468Z",
    "size": 162654,
    "path": "../public/imgs/tours/NatureTours/spring/sahrestanak.jpg"
  },
  "/imgs/tours/NatureTours/spring/کاشان مبایل.jpg": {
    "type": "image/jpeg",
    "etag": "\"19af6-5Zg0BLq15xR2J0MgFpV27Vz/jEc\"",
    "mtime": "2026-11-01T06:39:55.470Z",
    "size": 105206,
    "path": "../public/imgs/tours/NatureTours/spring/کاشان مبایل.jpg"
  }
};

const _DRIVE_LETTER_START_RE = /^[A-Za-z]:\//;
function normalizeWindowsPath(input = "") {
  if (!input) {
    return input;
  }
  return input.replace(/\\/g, "/").replace(_DRIVE_LETTER_START_RE, (r) => r.toUpperCase());
}
const _IS_ABSOLUTE_RE = /^[/\\](?![/\\])|^[/\\]{2}(?!\.)|^[A-Za-z]:[/\\]/;
const _DRIVE_LETTER_RE = /^[A-Za-z]:$/;
function cwd() {
  if (typeof process !== "undefined" && typeof process.cwd === "function") {
    return process.cwd().replace(/\\/g, "/");
  }
  return "/";
}
const resolve = function(...arguments_) {
  arguments_ = arguments_.map((argument) => normalizeWindowsPath(argument));
  let resolvedPath = "";
  let resolvedAbsolute = false;
  for (let index = arguments_.length - 1; index >= -1 && !resolvedAbsolute; index--) {
    const path = index >= 0 ? arguments_[index] : cwd();
    if (!path || path.length === 0) {
      continue;
    }
    resolvedPath = `${path}/${resolvedPath}`;
    resolvedAbsolute = isAbsolute(path);
  }
  resolvedPath = normalizeString(resolvedPath, !resolvedAbsolute);
  if (resolvedAbsolute && !isAbsolute(resolvedPath)) {
    return `/${resolvedPath}`;
  }
  return resolvedPath.length > 0 ? resolvedPath : ".";
};
function normalizeString(path, allowAboveRoot) {
  let res = "";
  let lastSegmentLength = 0;
  let lastSlash = -1;
  let dots = 0;
  let char = null;
  for (let index = 0; index <= path.length; ++index) {
    if (index < path.length) {
      char = path[index];
    } else if (char === "/") {
      break;
    } else {
      char = "/";
    }
    if (char === "/") {
      if (lastSlash === index - 1 || dots === 1) ; else if (dots === 2) {
        if (res.length < 2 || lastSegmentLength !== 2 || res[res.length - 1] !== "." || res[res.length - 2] !== ".") {
          if (res.length > 2) {
            const lastSlashIndex = res.lastIndexOf("/");
            if (lastSlashIndex === -1) {
              res = "";
              lastSegmentLength = 0;
            } else {
              res = res.slice(0, lastSlashIndex);
              lastSegmentLength = res.length - 1 - res.lastIndexOf("/");
            }
            lastSlash = index;
            dots = 0;
            continue;
          } else if (res.length > 0) {
            res = "";
            lastSegmentLength = 0;
            lastSlash = index;
            dots = 0;
            continue;
          }
        }
        if (allowAboveRoot) {
          res += res.length > 0 ? "/.." : "..";
          lastSegmentLength = 2;
        }
      } else {
        if (res.length > 0) {
          res += `/${path.slice(lastSlash + 1, index)}`;
        } else {
          res = path.slice(lastSlash + 1, index);
        }
        lastSegmentLength = index - lastSlash - 1;
      }
      lastSlash = index;
      dots = 0;
    } else if (char === "." && dots !== -1) {
      ++dots;
    } else {
      dots = -1;
    }
  }
  return res;
}
const isAbsolute = function(p) {
  return _IS_ABSOLUTE_RE.test(p);
};
const dirname = function(p) {
  const segments = normalizeWindowsPath(p).replace(/\/$/, "").split("/").slice(0, -1);
  if (segments.length === 1 && _DRIVE_LETTER_RE.test(segments[0])) {
    segments[0] += "/";
  }
  return segments.join("/") || (isAbsolute(p) ? "/" : ".");
};

function readAsset (id) {
  const serverDir = dirname(fileURLToPath(globalThis._importMeta_.url));
  return promises.readFile(resolve(serverDir, assets[id].path))
}

const publicAssetBases = {"/_nuxt/builds/meta/":{"maxAge":31536000},"/_nuxt/builds/":{"maxAge":1},"/_nuxt/":{"maxAge":31536000}};

function isPublicAssetURL(id = '') {
  if (assets[id]) {
    return true
  }
  for (const base in publicAssetBases) {
    if (id.startsWith(base)) { return true }
  }
  return false
}

function getAsset (id) {
  return assets[id]
}

const METHODS = /* @__PURE__ */ new Set(["HEAD", "GET"]);
const EncodingMap = { gzip: ".gz", br: ".br" };
const _SJVD7i = eventHandler((event) => {
  if (event.method && !METHODS.has(event.method)) {
    return;
  }
  let id = decodePath(
    withLeadingSlash(withoutTrailingSlash(parseURL(event.path).pathname))
  );
  let asset;
  const encodingHeader = String(
    getRequestHeader(event, "accept-encoding") || ""
  );
  const encodings = [
    ...encodingHeader.split(",").map((e) => EncodingMap[e.trim()]).filter(Boolean).sort(),
    ""
  ];
  for (const encoding of encodings) {
    for (const _id of [id + encoding, joinURL(id, "index.html" + encoding)]) {
      const _asset = getAsset(_id);
      if (_asset) {
        asset = _asset;
        id = _id;
        break;
      }
    }
  }
  if (!asset) {
    if (isPublicAssetURL(id)) {
      removeResponseHeader(event, "Cache-Control");
      throw createError$1({ statusCode: 404 });
    }
    return;
  }
  if (asset.encoding !== void 0) {
    appendResponseHeader(event, "Vary", "Accept-Encoding");
  }
  const ifNotMatch = getRequestHeader(event, "if-none-match") === asset.etag;
  if (ifNotMatch) {
    setResponseStatus(event, 304, "Not Modified");
    return "";
  }
  const ifModifiedSinceH = getRequestHeader(event, "if-modified-since");
  const mtimeDate = new Date(asset.mtime);
  if (ifModifiedSinceH && asset.mtime && new Date(ifModifiedSinceH) >= mtimeDate) {
    setResponseStatus(event, 304, "Not Modified");
    return "";
  }
  if (asset.type && !getResponseHeader(event, "Content-Type")) {
    setResponseHeader(event, "Content-Type", asset.type);
  }
  if (asset.etag && !getResponseHeader(event, "ETag")) {
    setResponseHeader(event, "ETag", asset.etag);
  }
  if (asset.mtime && !getResponseHeader(event, "Last-Modified")) {
    setResponseHeader(event, "Last-Modified", mtimeDate.toUTCString());
  }
  if (asset.encoding && !getResponseHeader(event, "Content-Encoding")) {
    setResponseHeader(event, "Content-Encoding", asset.encoding);
  }
  if (asset.size > 0 && !getResponseHeader(event, "Content-Length")) {
    setResponseHeader(event, "Content-Length", asset.size);
  }
  return readAsset(id);
});

const _SxA8c9 = defineEventHandler(() => {});

const _lazy_avbqSW = () => import('../routes/api/flights/default-airports.mjs');
const _lazy_iDcqsM = () => import('../routes/renderer.mjs').then(function (n) { return n.r; });

const handlers = [
  { route: '', handler: _SJVD7i, lazy: false, middleware: true, method: undefined },
  { route: '/api/flights/default-airports', handler: _lazy_avbqSW, lazy: true, middleware: false, method: undefined },
  { route: '/__nuxt_error', handler: _lazy_iDcqsM, lazy: true, middleware: false, method: undefined },
  { route: '/__nuxt_island/**', handler: _SxA8c9, lazy: false, middleware: false, method: undefined },
  { route: '/**', handler: _lazy_iDcqsM, lazy: true, middleware: false, method: undefined }
];

function createNitroApp() {
  const config = useRuntimeConfig();
  const hooks = createHooks();
  const captureError = (error, context = {}) => {
    const promise = hooks.callHookParallel("error", error, context).catch((error_) => {
      console.error("Error while capturing another error", error_);
    });
    if (context.event && isEvent(context.event)) {
      const errors = context.event.context.nitro?.errors;
      if (errors) {
        errors.push({ error, context });
      }
      if (context.event.waitUntil) {
        context.event.waitUntil(promise);
      }
    }
  };
  const h3App = createApp({
    debug: destr(false),
    onError: (error, event) => {
      captureError(error, { event, tags: ["request"] });
      return errorHandler(error, event);
    },
    onRequest: async (event) => {
      event.context.nitro = event.context.nitro || { errors: [] };
      const fetchContext = event.node.req?.__unenv__;
      if (fetchContext?._platform) {
        event.context = {
          _platform: fetchContext?._platform,
          // #3335
          ...fetchContext._platform,
          ...event.context
        };
      }
      if (!event.context.waitUntil && fetchContext?.waitUntil) {
        event.context.waitUntil = fetchContext.waitUntil;
      }
      event.fetch = (req, init) => fetchWithEvent(event, req, init, { fetch: localFetch });
      event.$fetch = (req, init) => fetchWithEvent(event, req, init, {
        fetch: $fetch
      });
      event.waitUntil = (promise) => {
        if (!event.context.nitro._waitUntilPromises) {
          event.context.nitro._waitUntilPromises = [];
        }
        event.context.nitro._waitUntilPromises.push(promise);
        if (event.context.waitUntil) {
          event.context.waitUntil(promise);
        }
      };
      event.captureError = (error, context) => {
        captureError(error, { event, ...context });
      };
      await nitroApp.hooks.callHook("request", event).catch((error) => {
        captureError(error, { event, tags: ["request"] });
      });
    },
    onBeforeResponse: async (event, response) => {
      await nitroApp.hooks.callHook("beforeResponse", event, response).catch((error) => {
        captureError(error, { event, tags: ["request", "response"] });
      });
    },
    onAfterResponse: async (event, response) => {
      await nitroApp.hooks.callHook("afterResponse", event, response).catch((error) => {
        captureError(error, { event, tags: ["request", "response"] });
      });
    }
  });
  const router = createRouter({
    preemptive: true
  });
  const nodeHandler = toNodeListener(h3App);
  const localCall = (aRequest) => b(
    nodeHandler,
    aRequest
  );
  const localFetch = (input, init) => {
    if (!input.toString().startsWith("/")) {
      return globalThis.fetch(input, init);
    }
    return C(
      nodeHandler,
      input,
      init
    ).then((response) => normalizeFetchResponse(response));
  };
  const $fetch = createFetch({
    fetch: localFetch,
    Headers: Headers$1,
    defaults: { baseURL: config.app.baseURL }
  });
  globalThis.$fetch = $fetch;
  h3App.use(createRouteRulesHandler({ localFetch }));
  for (const h of handlers) {
    let handler = h.lazy ? lazyEventHandler(h.handler) : h.handler;
    if (h.middleware || !h.route) {
      const middlewareBase = (config.app.baseURL + (h.route || "/")).replace(
        /\/+/g,
        "/"
      );
      h3App.use(middlewareBase, handler);
    } else {
      const routeRules = getRouteRulesForPath(
        h.route.replace(/:\w+|\*\*/g, "_")
      );
      if (routeRules.cache) {
        handler = cachedEventHandler(handler, {
          group: "nitro/routes",
          ...routeRules.cache
        });
      }
      router.use(h.route, handler, h.method);
    }
  }
  h3App.use(config.app.baseURL, router.handler);
  const app = {
    hooks,
    h3App,
    router,
    localCall,
    localFetch,
    captureError
  };
  return app;
}
function runNitroPlugins(nitroApp2) {
  for (const plugin of plugins) {
    try {
      plugin(nitroApp2);
    } catch (error) {
      nitroApp2.captureError(error, { tags: ["plugin"] });
      throw error;
    }
  }
}
const nitroApp = createNitroApp();
function useNitroApp() {
  return nitroApp;
}
runNitroPlugins(nitroApp);

function defineRenderHandler(render) {
  const runtimeConfig = useRuntimeConfig();
  return eventHandler(async (event) => {
    const nitroApp = useNitroApp();
    const ctx = { event, render, response: void 0 };
    await nitroApp.hooks.callHook("render:before", ctx);
    if (!ctx.response) {
      if (event.path === `${runtimeConfig.app.baseURL}favicon.ico`) {
        setResponseHeader(event, "Content-Type", "image/x-icon");
        return send(
          event,
          "data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7"
        );
      }
      ctx.response = await ctx.render(event);
      if (!ctx.response) {
        const _currentStatus = getResponseStatus(event);
        setResponseStatus(event, _currentStatus === 200 ? 500 : _currentStatus);
        return send(
          event,
          "No response returned from render handler: " + event.path
        );
      }
    }
    await nitroApp.hooks.callHook("render:response", ctx.response, ctx);
    if (ctx.response.headers) {
      setResponseHeaders(event, ctx.response.headers);
    }
    if (ctx.response.statusCode || ctx.response.statusMessage) {
      setResponseStatus(
        event,
        ctx.response.statusCode,
        ctx.response.statusMessage
      );
    }
    return ctx.response.body;
  });
}

const NullObject = /* @__PURE__ */ (() => {
  const C = function() {
  };
  C.prototype = /* @__PURE__ */ Object.create(null);
  return C;
})();
function parse(str, options) {
  if (typeof str !== "string") {
    throw new TypeError("argument str must be a string");
  }
  const obj = new NullObject();
  const opt = options || {};
  const dec = opt.decode || decode;
  let index = 0;
  while (index < str.length) {
    const eqIdx = str.indexOf("=", index);
    if (eqIdx === -1) {
      break;
    }
    let endIdx = str.indexOf(";", index);
    if (endIdx === -1) {
      endIdx = str.length;
    } else if (endIdx < eqIdx) {
      index = str.lastIndexOf(";", eqIdx - 1) + 1;
      continue;
    }
    const key = str.slice(index, eqIdx).trim();
    if (opt?.filter && !opt?.filter(key)) {
      index = endIdx + 1;
      continue;
    }
    if (void 0 === obj[key]) {
      let val = str.slice(eqIdx + 1, endIdx).trim();
      if (val.codePointAt(0) === 34) {
        val = val.slice(1, -1);
      }
      obj[key] = tryDecode(val, dec);
    }
    index = endIdx + 1;
  }
  return obj;
}
function decode(str) {
  return str.includes("%") ? decodeURIComponent(str) : str;
}
function tryDecode(str, decode2) {
  try {
    return decode2(str);
  } catch {
    return str;
  }
}

const debug = (...args) => {
};
function GracefulShutdown(server, opts) {
  opts = opts || {};
  const options = Object.assign(
    {
      signals: "SIGINT SIGTERM",
      timeout: 3e4,
      development: false,
      forceExit: true,
      onShutdown: (signal) => Promise.resolve(signal),
      preShutdown: (signal) => Promise.resolve(signal)
    },
    opts
  );
  let isShuttingDown = false;
  const connections = {};
  let connectionCounter = 0;
  const secureConnections = {};
  let secureConnectionCounter = 0;
  let failed = false;
  let finalRun = false;
  function onceFactory() {
    let called = false;
    return (emitter, events, callback) => {
      function call() {
        if (!called) {
          called = true;
          return Reflect.apply(callback, this, arguments);
        }
      }
      for (const e of events) {
        emitter.on(e, call);
      }
    };
  }
  const signals = options.signals.split(" ").map((s) => s.trim()).filter((s) => s.length > 0);
  const once = onceFactory();
  once(process, signals, (signal) => {
    debug("received shut down signal", signal);
    shutdown(signal).then(() => {
      if (options.forceExit) {
        process.exit(failed ? 1 : 0);
      }
    }).catch((error) => {
      debug("server shut down error occurred", error);
      process.exit(1);
    });
  });
  function isFunction(functionToCheck) {
    const getType = Object.prototype.toString.call(functionToCheck);
    return /^\[object\s([A-Za-z]+)?Function]$/.test(getType);
  }
  function destroy(socket, force = false) {
    if (socket._isIdle && isShuttingDown || force) {
      socket.destroy();
      if (socket.server instanceof http.Server) {
        delete connections[socket._connectionId];
      } else {
        delete secureConnections[socket._connectionId];
      }
    }
  }
  function destroyAllConnections(force = false) {
    debug("Destroy Connections : " + (force ? "forced close" : "close"));
    let counter = 0;
    let secureCounter = 0;
    for (const key of Object.keys(connections)) {
      const socket = connections[key];
      const serverResponse = socket._httpMessage;
      if (serverResponse && !force) {
        if (!serverResponse.headersSent) {
          serverResponse.setHeader("connection", "close");
        }
      } else {
        counter++;
        destroy(socket);
      }
    }
    debug("Connections destroyed : " + counter);
    debug("Connection Counter    : " + connectionCounter);
    for (const key of Object.keys(secureConnections)) {
      const socket = secureConnections[key];
      const serverResponse = socket._httpMessage;
      if (serverResponse && !force) {
        if (!serverResponse.headersSent) {
          serverResponse.setHeader("connection", "close");
        }
      } else {
        secureCounter++;
        destroy(socket);
      }
    }
    debug("Secure Connections destroyed : " + secureCounter);
    debug("Secure Connection Counter    : " + secureConnectionCounter);
  }
  server.on("request", (req, res) => {
    req.socket._isIdle = false;
    if (isShuttingDown && !res.headersSent) {
      res.setHeader("connection", "close");
    }
    res.on("finish", () => {
      req.socket._isIdle = true;
      destroy(req.socket);
    });
  });
  server.on("connection", (socket) => {
    if (isShuttingDown) {
      socket.destroy();
    } else {
      const id = connectionCounter++;
      socket._isIdle = true;
      socket._connectionId = id;
      connections[id] = socket;
      socket.once("close", () => {
        delete connections[socket._connectionId];
      });
    }
  });
  server.on("secureConnection", (socket) => {
    if (isShuttingDown) {
      socket.destroy();
    } else {
      const id = secureConnectionCounter++;
      socket._isIdle = true;
      socket._connectionId = id;
      secureConnections[id] = socket;
      socket.once("close", () => {
        delete secureConnections[socket._connectionId];
      });
    }
  });
  process.on("close", () => {
    debug("closed");
  });
  function shutdown(sig) {
    function cleanupHttp() {
      destroyAllConnections();
      debug("Close http server");
      return new Promise((resolve, reject) => {
        server.close((err) => {
          if (err) {
            return reject(err);
          }
          return resolve(true);
        });
      });
    }
    debug("shutdown signal - " + sig);
    if (options.development) {
      debug("DEV-Mode - immediate forceful shutdown");
      return process.exit(0);
    }
    function finalHandler() {
      if (!finalRun) {
        finalRun = true;
        if (options.finally && isFunction(options.finally)) {
          debug("executing finally()");
          options.finally();
        }
      }
      return Promise.resolve();
    }
    function waitForReadyToShutDown(totalNumInterval) {
      debug(`waitForReadyToShutDown... ${totalNumInterval}`);
      if (totalNumInterval === 0) {
        debug(
          `Could not close connections in time (${options.timeout}ms), will forcefully shut down`
        );
        return Promise.resolve(true);
      }
      const allConnectionsClosed = Object.keys(connections).length === 0 && Object.keys(secureConnections).length === 0;
      if (allConnectionsClosed) {
        debug("All connections closed. Continue to shutting down");
        return Promise.resolve(false);
      }
      debug("Schedule the next waitForReadyToShutdown");
      return new Promise((resolve) => {
        setTimeout(() => {
          resolve(waitForReadyToShutDown(totalNumInterval - 1));
        }, 250);
      });
    }
    if (isShuttingDown) {
      return Promise.resolve();
    }
    debug("shutting down");
    return options.preShutdown(sig).then(() => {
      isShuttingDown = true;
      cleanupHttp();
    }).then(() => {
      const pollIterations = options.timeout ? Math.round(options.timeout / 250) : 0;
      return waitForReadyToShutDown(pollIterations);
    }).then((force) => {
      debug("Do onShutdown now");
      if (force) {
        destroyAllConnections(force);
      }
      return options.onShutdown(sig);
    }).then(finalHandler).catch((error) => {
      const errString = typeof error === "string" ? error : JSON.stringify(error);
      debug(errString);
      failed = true;
      throw errString;
    });
  }
  function shutdownManual() {
    return shutdown("manual");
  }
  return shutdownManual;
}

function getGracefulShutdownConfig() {
  return {
    disabled: !!process.env.NITRO_SHUTDOWN_DISABLED,
    signals: (process.env.NITRO_SHUTDOWN_SIGNALS || "SIGTERM SIGINT").split(" ").map((s) => s.trim()),
    timeout: Number.parseInt(process.env.NITRO_SHUTDOWN_TIMEOUT || "", 10) || 3e4,
    forceExit: !process.env.NITRO_SHUTDOWN_NO_FORCE_EXIT
  };
}
function setupGracefulShutdown(listener, nitroApp) {
  const shutdownConfig = getGracefulShutdownConfig();
  if (shutdownConfig.disabled) {
    return;
  }
  GracefulShutdown(listener, {
    signals: shutdownConfig.signals.join(" "),
    timeout: shutdownConfig.timeout,
    forceExit: shutdownConfig.forceExit,
    onShutdown: async () => {
      await new Promise((resolve) => {
        const timeout = setTimeout(() => {
          console.warn("Graceful shutdown timeout, force exiting...");
          resolve();
        }, shutdownConfig.timeout);
        nitroApp.hooks.callHook("close").catch((error) => {
          console.error(error);
        }).finally(() => {
          clearTimeout(timeout);
          resolve();
        });
      });
    }
  });
}

export { $fetch as $, parseQuery as A, withTrailingSlash as B, withoutTrailingSlash as C, klona as D, parse as E, getRequestHeader as F, isEqual as G, setCookie as H, getCookie as I, deleteCookie as J, trapUnhandledNodeErrors as a, useNitroApp as b, defineEventHandler as c, destr as d, encodePath as e, defineRenderHandler as f, getQuery as g, createError$1 as h, getRouteRules as i, joinRelativeURL as j, getResponseStatusText as k, getResponseStatus as l, decodePath as m, hasProtocol as n, isScriptProtocol as o, parseURL as p, joinURL as q, sanitizeStatusCode as r, setupGracefulShutdown as s, toNodeListener as t, useRuntimeConfig as u, getContext as v, withQuery as w, defu as x, createHooks as y, executeAsync as z };
//# sourceMappingURL=nitro.mjs.map
